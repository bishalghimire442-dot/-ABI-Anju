# ABI v2.32.0 — Pyari semantic response synthesis

## Why this release exists
Earlier chat fallback code returned retrieved memory excerpts almost verbatim. The education branch could also answer a question about Sir's Loksewa preparation with Anju's own education profile. This release addresses those specific defects.

## Changes
- Added an explicit six-step semantic response contract to the Gemini system instruction: classify the question, retrieve relevant facts, distinguish Sir's facts from Anju's, reconcile conflicts, derive the answer, and express it naturally in Anju's voice.
- Explicitly prohibits copying memory excerpts, JSON-like data, raw field names, and source lists into user-facing replies.
- Clarifies that questions about Sir's Loksewa/studies must use Sir's own context, never Anju's education record.
- Local fallback no longer dumps retrieved memory excerpts verbatim.
- Loksewa fallback uses only matching user-context records and avoids asserting unsupported exam-preparation details; when context is insufficient, it asks one natural clarifying question.
- Original Anju Smriti JSON source files remain unchanged.

## Validation
- `node --check server.js` passed.
- `node --check public/app.js` passed.
- `package.json` and all four core memory JSON files parse successfully.
- ZIP integrity checked after packaging.

## Limitations
- This is not a live Gemini/API or Android UI test. Quality still depends on a working Gemini API key and the accuracy/completeness of user-context records supplied by the client.
- If Gemini is unavailable, local fallback is intentionally conservative and may ask a question instead of pretending to infer missing facts.
