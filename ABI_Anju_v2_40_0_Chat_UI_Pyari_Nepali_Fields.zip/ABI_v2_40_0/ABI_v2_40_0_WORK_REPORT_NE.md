# ABI Anju v2.40.0 — निर्माण तथा परीक्षण प्रतिवेदन

## यस प्याकेजमा समावेश/पुष्टि भएका सुधार

1. **सन्दर्भअनुसार छोटो जवाफ** — `है`, `हजुर`, `हो`, `ल`, `अँ`, `हम्म`, `ठीक छ`, `ए`, `ओहो`, `किन?`, `अनि?`, `भनेपछि?`, `साँच्चै?` जस्ता छोटा प्रतिक्रियालाई पछिल्ला संवादसँग जोड्ने स्थानीय व्यवहार र regression परीक्षण।
2. **PDF क्षमता** — प्रति PDF अधिकतम ५० MiB र ४०० पृष्ठ सीमा। ३३८ पृष्ठ/करिब ३१.१ MiB फाइलको लागि सीमा पर्याप्त हुन्छ। OCR मोड रोजेमा अब प्रत्येक पृष्ठमा OCR चल्छ; पुरानो font mapping बिग्रिएको text-layer मा निर्भर हुँदैन। PDF.js/Tesseract तथा नेपाली भाषा assets इन्टरनेटबाट लोड हुन्छन्।
3. **प्रत्येक उत्तरको Pyari समीक्षा** — ०–५ प्रयोगकर्ता मूल्यांकन, समस्या प्रकार र सुधार सुझाव; प्रश्न/उत्तर/सन्दर्भसहित अभिलेख। स्थानीय नियममा आधारित प्रारम्भिक समीक्षा सत्यता वा भावनाको प्रमाणित मापन होइन।
4. **सन्देश सम्पादन** — प्रयोगकर्ताको आफ्नै सन्देश सम्पादन; पुरानो संवाद शाखा अभिलेखमा राखेर नयाँ उत्तर माग्ने।
5. **Recycle Bin** — चयनित सामग्री हटाउँदा पुनःस्थापनाको अवसर; स्थायी हटाउन छुट्टै पुष्टि।
6. **Proactive message library** — १६० फरक नमुना (२५ बिहान, २५ राति, २५ दिउँसो, २० बेलुका, २० पढाइ, २० हेरचाह, २५ रमाइलो/प्रश्न), on/off र pause।
7. **Chatpad** — बढ्न सक्ने multiline composer; Enter पठाउने र Shift+Enter नयाँ लाइन।
8. **Persona** — Sir सम्बोधन, Roman Nepali प्राथमिकता, हरेक Anju उत्तरमा उपयुक्त emoji, “यार” र kiss emoji निषेध, “143” विरलै।
9. **संरचना/संस्करण** — ७ मुख्य विभाग/१८ उपविभाग कायम; ABI निर्देशन विभाग र “सम्झनैपर्ने विषय” लेबल कायम; package र service-worker cache v2.40.0।

## प्रयोगकर्ताले पठाएका PDF को जाँच

- `@ABI.pdf`: ९९ पृष्ठ, 23,436,261 bytes (करिब २२.३ MiB)। ९९ पृष्ठको text extraction खाली आयो; पहिलो पृष्ठ फोटो हो र PDF मुख्यतः तस्बिर/फोटो अभिलेख देखिन्छ। यसलाई text memory भनेर स्वतः पाठका रूपमा आयात गर्न सकिँदैन; मूल PDF जस्ताको तस्तै अलग राखिएको छ।
- `(ABI)~.pdf`: ३३८ पृष्ठ, 32,613,360 bytes (करिब ३१.१ MiB)। `pdftotext` ले पाठ निकाले पनि Kalimati/legacy font mapping का कारण अक्षर बिग्रिएका छन्। चयनित पृष्ठमा Nepali+English Tesseract OCR परीक्षण गर्दा पढ्न मिल्ने नेपाली पाठ आयो; केही अन्य नमुना पृष्ठमा OCR गुणस्तर कमजोर/फोटोप्रधान थियो। त्यसैले ३३८ पृष्ठका सबै पृष्ठ OCR भई शुद्ध छन् भनेर दाबी गरिएको छैन।
- दुवै मूल PDF फाइललाई संशोधन, रूपान्तरण वा ZIP भित्र मिसाइएको छैन। SHA-256:
  - `@ABI.pdf`: `0ee30aacebe5dd847ca9665484fc214b4a111f4a7e75047f6a26c32b739f1dc2`
  - `(ABI)~.pdf`: `24a516c28e42eab320f3f3eec7fe044de8112d5eef0370163eeff7b567de79fe`
- ABI app को PDF पुस्तकालयमा यी PDF थपेपछि “पाठ निकाल्नुहोस्” ले text layer पढ्छ; `(ABI)~.pdf` जस्तो legacy font का लागि “स्क्यान OCR” चलाउनुपर्छ। OCR पछि पाठ जाँचेर मात्र “सम्झनैपर्ने विषय”/स्मृतिमा प्रयोग गर्नुहोस्। PDF र पृष्ठ-पाठ browser IndexedDB मा रहन्छ; स्वतः cloud sync हुँदैन। PDF थपेपछि “पूर्ण स्थानीय backup” निकालेर अलग सुरक्षित राख्नुहोस्।

## चलाइएका परीक्षण

- `npm test`: सबै ५ suites सफल (semantic smoke, recovery guards, ७ विभाग/१८ उपविभाग/voice, 10,152 conversation combinations + 160 proactive examples + short-context, PDF capacity/OCR path)।
- `node --check server.js`, `public/app.js`, `public/sw.js`: सफल।
- HTML ID audit: २३२ ID, duplicate छैन।
- दुवै PDF को वास्तविक page count र ZIP integrity जाँचियो। ३३८-पृष्ठ PDF का केही पृष्ठमा native OCR नमुना परीक्षण गरियो।

## अझै live/end-to-end परीक्षण नभएका पक्ष — पूर्णता दाबी गरिएको छैन

1. Google Drive OAuth, वास्तविक backup/restore/merge live परीक्षण।
2. Gemini को सफल live response; API quota/credentials को हालको अवस्था प्रमाणित छैन।
3. Browser भित्र ३३८ पृष्ठको पूर्ण OCR, सबै पृष्ठको accuracy र memory/performance; OCR assets CDN बाट चाहिन्छ।
4. Browser बन्द हुँदा Web Push delivery र प्रयोगकर्ताले समय/दिन/आवृत्ति आफैँ सेट गर्ने schedule editor। हाल in-app schedule र browser Notification अनुमति हुँदा मात्र सूचना।
5. File Manager मा multi-select/select-all/bulk restore/delete को पूर्ण सुविधा।
6. वास्तविक Android/Desktop keyboard/layout/device परीक्षण।
7. फोटो/भिडियो/voice upload, playback र permission को end-to-end device परीक्षण।
8. Pyari pending → processed → applied → retested workflow को पूर्ण स्वचालन।
9. Runtime dependency install/Express startup/browser automation यस निर्माण वातावरणमा चलाइएको छैन; ZIP मा `node_modules` समावेश छैन।

## प्रकाशन र सुरक्षा

- GitHub commit/push गरिएको छैन।
- Render deploy गरिएको छैन।
- कुनै paid plan/add-on रोजिएको छैन।
- दुई मूल PDF ZIP मा समावेश छैनन्, ताकि ती सार्वजनिक app asset नबनून् र अलग मूल प्रति यथावत् रहून्।
- यसलाई **v2.40.0 Release Candidate** मान्नुहोस्; माथिका live परीक्षण बाँकी हुँदा “सबै Masterplan काम पूर्ण” भनेर दाबी गरिएको छैन।
