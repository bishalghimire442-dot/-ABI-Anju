# ABI v2.27.0 — Mobile scroll, department focus, chat profile, Gemini limits

## Changes
- Mobile chat viewport uses a bounded flex layout with native vertical touch scrolling and safe-area padding.
- Settings workspace returns to normal document scrolling; department list is hidden after a department is opened and restored with “विभागहरू”.
- Chat header now displays Anju's profile image; each Anju bubble includes a small profile image.
- Removed the per-message speaker control.
- Chat rendering is limited to the latest 100 messages for a lighter DOM; full conversation remains in local app state.
- Chat sends are guarded against accidental concurrent submissions.
- LocalStorage writes are debounced and flushed on pagehide to reduce synchronous storage work.
- Gemini local request guard is configurable and defaults to 60/day and 8/minute (up from 20/day and 5/minute). This does NOT increase Google's account quota; Google's API limits remain authoritative. Failed/limited Gemini calls use local Pyari/Anju Smriti fallback.
- Existing Anju Smriti JSON/archive and user files are preserved in this package.

## Important storage note
This app's current browser-side PDF/media library uses IndexedDB/local browser storage. It is not a durable cloud backup. Export/backup separately before clearing browser data or changing devices.

## Validation
Syntax checks are required before deployment. Real Android device scroll, file upload, and Gemini API tests are still required before promoting this build to the live service.
