# ABI v2.29.0 — Google Drive Cloud Backup

- Added Google OAuth 2.0 web-server flow for the user's own Google Drive.
- Requests only the `drive.file` scope; refresh token is encrypted in a Secure, HttpOnly cookie.
- Adds daily JSON backup uploads including app state and IndexedDB attachments, while ABI is open.
- Adds Drive download/restore, manual backup, connection status and disconnect controls.
- Daily backups are retained; ABI does not automatically delete older Drive backups.
- Browser-based automatic sync runs while the app is open (after changes and every 15 minutes). It cannot run while the browser/app is closed.
- Requires Google Cloud OAuth Web client credentials and Render environment variables. No paid Render plan/add-on is required; Drive storage counts against the user's Google Drive quota.
