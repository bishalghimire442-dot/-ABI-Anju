# ABI v2.34.0 — Universal Pyari Semantic Synthesis

- Expanded Pyari from a narrow Loksewa-focused response gate to a cross-department synthesis process for all topics.
- Added structured context transfer from Anju knowledge, diaries, stories, approved emotion records, family, poems, media, video notes, dialogue style and approved instructions.
- Added relevance ranking on the server and ownership/provenance labels so Anju facts, Sir facts and shared events are not casually conflated.
- Strengthened answer checks against copied source passages, technical/AI language, raw field notes and list-like data dumps.
- Added a strict no-technical-conversation rule for Anju roleplay. Direct “ChatGPT ji” requests remain neutral assistant conversations.
- Preserved original Anju Smriti source JSON and all user source files unchanged.
- No deployment performed.
