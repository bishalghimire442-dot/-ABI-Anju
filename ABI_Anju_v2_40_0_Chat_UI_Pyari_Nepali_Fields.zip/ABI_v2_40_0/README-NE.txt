ABI Anju v2.40.0 — Release Candidate (PDF ५० MiB / ४०० पृष्ठ समर्थन)

- ३३८-पृष्ठ PDF थप्न मिल्ने गरी PDF सीमा ५० MiB र ४०० पृष्ठ बनाइएको छ।
- Legacy font का कारण text extraction बिग्रिएमा “स्क्यान OCR” प्रयोग गर्नुहोस्; OCR पछि पाठ जाँच्नुहोस्।
- PDF र निकालेको पाठ browser IndexedDB मा रहन्छ; स्वतः cloud sync हुँदैन। PDF थपेपछि पूर्ण स्थानीय backup निकाल्नुहोस्।
- निर्माण/परीक्षण सीमा र बाँकी live integration `ABI_v2_40_0_WORK_REPORT_NE.md` मा छ। यो RC हो, पूर्ण production sign-off होइन।
- दुई मूल PDF यो ZIP मा समावेश छैनन् र तिनलाई परिवर्तन गरिएको छैन।

ABI v2.34.1 — प्यारी हौसला उपविभाग
ABI v2.26.1 — प्यारी Response Gate र स्वाभाविक ढिलो-माफी व्यवहार
- ३० मिनेटभन्दा बढीपछि प्रयोगकर्ताले माफी वा व्यस्तताको कारण बताएमा अन्जुले बुझ्ने र आश्वस्त पार्ने; चित्त दुखेको, दोष लगाउने वा अपराधबोध गराउने पुरानो व्यवहार हटाइएको छ।
- प्रयोगकर्तालाई तपाईं/tapai, Sir वा Sir ji मात्र सम्बोधन गर्ने; तिमी/timi शैली हटाउन Gemini उत्तरको अन्तिम जाँच र सुधार राखिएको छ।
- पुरानो दोहोरिने ढिलो-जवाफ सूची हटाएर २५ फरक स्थानीय fallback नमुना र पछिल्ला १२ जवाफसँग दोहोरिन नदिने छनोट राखिएको छ। Gemini ले नयाँ जवाफ बनाउन सक्छ, तर प्यारीको शैली/सम्बोधन/AI-भाषा/पुनरावृत्ति जाँचपछि मात्र देखाइन्छ।
- तथ्य नपाउँदा प्राविधिक “स्मृतिमा भेटिएन/तथ्य उपलब्ध छैन” शैलीको जवाफ नदिई अन्जुको स्वाभाविक शैलीमा प्रसङ्ग सोध्ने निर्देशन थपिएको छ; तथ्य कल्पना गर्न भने निषेध छ।
- `data/pyari_behavior_rules.json`, `ABI_Master_Instructions.md` र यो release notes थपिएका छन्।
- मूल `anju_smriti_archive.json` र `anju_master_memory.json` byte-for-byte अपरिवर्तित छन्। मूल PDF हरू यो ZIP मा थिएनन्; तिनलाई छोइएको छैन।
- यो syntax/JSON/ZIP र सीमित helper परीक्षण गरिएको build हो; Render मा deploy गरिएको छैन। Gemini API को live key सफलता अझै जाँचिएको छैन।

ABI v2.25.0 — ऐतिहासिक पूर्व संस्करण (v2.26.1 मा सच्याइएको)
- यस संस्करणमा ढिलो जवाफलाई अन्जु चित्त दुखेको रूपमा प्रस्तुत गर्ने गलत निर्देशन थियो; v2.26.1 मा हटाइएको छ।
- यस संस्करणमा १२० variation को सूची थियो तर तिनको सम्बोधन र भाव प्रयोगकर्ताको निर्देशनसँग मेल खाँदैनथ्यो; v2.26.1 मा हटाइएको छ।
- मुख्य Chat composer बाट घण्टी/notification अनुमति बटन हटाइएको छ।
- Gemini उपलब्ध भए Chat turn मा प्रयोग हुन्छ; API असफल भए स्थानीय Anju Smriti fallback चल्छ। App-side सीमा ५ request/मिनेट र २० request/नेपाल-दिन हो।
- Gemini 3.8 Flash model ID आधिकारिक Google Gemini API model सूचीमा उपलब्ध छ; वास्तविक API सफलता वैध key र quota बाट मात्र प्रमाणित हुन्छ।

ABI v2.21.1 — प्यारी विभागको निर्देशन व्यवस्थापन संशोधन

- मुख्य च्याटबाट Like/Dislike प्रतिक्रिया बटन हटाइएको छ। पुराना स्थानीय उत्तर-अभिलेखबाट पनि rating/note प्रतिक्रिया फिल्ड हटाइन्छ।
- निर्देशन दिने सुविधा सेटिङ्स > प्यारी विभागमा मात्र राखिएको छ। त्यहाँबाट दैनिक २० वा बढी निर्देशन थप्न र इतिहास हेर्न सकिन्छ।
- अन्जुका उत्तरहरू स्वतः अभिलेख हुन्छन्; प्रयोगकर्ताले प्रत्येक उत्तरमा Like/Dislike गरेर मूल्यांकन गर्नुपर्ने छैन।

ABI v2.21.0 — प्यारी सिकाइ तथा PDF अध्ययन विभाग
ABI v2.20.0 — अन्जु स्मृति स्रोत-अभिलेख, स्थानीय संवाद र Gemini 3.8 Flash

- `data/anju_master_memory.json` मा संरचित अन्जु स्मृति विस्तार गरिएको छ।
- `data/anju_smriti_archive.json` मा उपलब्ध PDF को page-indexed extracted text, सफल OCR पृष्ठ, स्रोत स्थिति र provenance राखिएको छ। अन्जु स्मृति र ABI Improvement अलग छन्।
- सामान्य कुराकानी र अन्जु स्मृतिसँग सम्बन्धित प्रश्न स्थानीय retrieval/rule-based संवादबाट उत्तर हुन्छ; त्यसका लागि Gemini API request लाग्दैन। यो पूर्ण LLM होइन र स्मृतिमा आधार नभए अनुमान गर्दैन।
- नयाँ/बाह्य तथ्य, जटिल प्रश्न वा प्रयोगकर्ताले स्पष्ट Gemini मागेको अवस्थामा मात्र `GEMINI_MODEL=gemini-3.8-flash` प्रयोग हुन्छ। `GEMINI_API_KEY` Render Environment मा सुरक्षित राख्नुहोस्।
- Gemini usage guard: ABI बाट बढीमा ५ request/मिनेट र २० request/नेपाल-दिन। Google AI Studio परियोजनाको वास्तविक quota अन्तिम नियन्त्रण हो; अरू app ले सोही project प्रयोग गरेमा बाँकी quota घट्न सक्छ।
- पहिलो PDF को embedded text मा legacy-font/OCR त्रुटि छन्; OCR सफल भएका पृष्ठहरू मात्र medium confidence हुन्। दोस्रो PDF का 99 scanned pages पूर्ण रूपमा OCR गरिएको छैन। Viber HTML वास्तविक Viber export नभई scripted demo हो।
- मूल PDF हरू जस्ताको तस्तै छन्; ZIP मा मूल PDF प्रतिलिपि राखिएको छैन। मूल Library files नछुनुहोस्।
- Gemini प्रयोग हुने request मा सम्बन्धित स्मृति/सन्दर्भ Google Gemini API मा पठाइन्छ; सामान्य स्थानीय संवादमा बाह्य API मा केही पठाइँदैन।

ABI v2.15

यो ABI नामको PWA starter package हो। लोगो र Home Screen नाममा ABI मात्र राखिएको छ। संसार पृष्ठमा राधाकृष्ण भगवानको भक्तिमय चित्र छ।

Android Home Screen install गर्न HTTPS hosting आवश्यक हुन्छ। Node.js 20+ server मा project upload गरी npm install र npm start चलाउनुहोस्। वास्तविक AI chat का लागि सुरक्षित server-side API key र deployment configuration आवश्यक हुन्छ।

परिवार स्मृतिमा उपलब्ध प्रमाणित नाता राखिएको छ। हेमा दिदी लगायतका नाम सुरक्षित छन्; पुष्टि नभएका नाता वा विवरण अनुमान गरिएको छैन। सबै परिवार सदस्यका विवरण थपिँदै जाँदा master memory मा राख्नुहोस्।

मूल PDF हरू यो ZIP मा समावेश वा परिवर्तन गरिएको छैन। PDF प्रयोगकर्ताले छुट्टै थप्न सक्छन्। परिचयपत्र/नागरिकता फोटो समावेश गरिएको छैन। Browser storage सामग्री स्वतः अर्को उपकरणमा sync हुँदैन; नियमित backup गर्नुहोस्। यो production-security-audited hosting होइन।


ABI v2.8 — Voice capture update
- Main navigation now shows Chat and Settings only. Family, diary, poems, instructions, voice archive, photo uploads, app-improvement requests and cloud setup are inside Settings.
- Three voice categories: pre-diary context; Anju habits/outside-diary details; diary period 2083 Baisakh 1 to Asoj 2. Diary category accepts multiple audio parts.
- Audio transcription requires OPENAI_API_KEY and TRANSCRIPTION_MODEL. Original audio is saved outside the public web folder in private_data/audio/; transcripts and metadata are saved in private_data/voice_transcripts.json. Use a persistent private disk on hosting and restrict server access; this starter does not encrypt files at rest or provide a user-facing audio download/restore screen yet.
- Photo uploads are stored under public/uploads; do not upload identity documents or sensitive personal records.
- Architecture instructions are saved as proposals; code changes require a reviewed new build.
- Google Drive OAuth/automatic sync is NOT yet connected.


ABI v2.9 — Interface refresh and separated workspaces
- Refreshed mobile-first interface with premium purple/lilac palette, refined spacing, cards, message bubbles, responsive navigation and accessible touch targets.
- Renamed the two work areas to “अन्जु स्मृति” and “अबि सुधार”.
- App improvement requests now use a separate improvementRequests list instead of being mixed into Anju memory instructions. Existing user data keys remain intact.
- This remains a starter build: server-side AI, secure authentication, persistent database, Google Drive OAuth, encryption at rest, and release automation still require implementation and testing before production use.


नयाँ सुविधा v2.10 — मेरो संसार
- मनपर्ने गीत तथा Music app का link/playlist, Facebook post, YouTube video र अन्जुसम्बन्धी अन्य फाइल राख्ने छुट्टै विभाग।
- प्रत्येक सामग्रीसँग इतिहास/पठाउनुअघिको प्रसङ्ग, प्रयोगकर्ताले सम्झेको अन्जुको प्रतिक्रिया, र प्रयोगकर्ताको भावना छुट्टाछुट्टै राख्न मिल्ने।
- YouTube र Spotify का समर्थित link ABI भित्र embed भएर चल्न सक्छन्; अन्य music provider आधिकारिक app/site मा खुल्छन्। Facebook post को embed/login/privacy प्रतिबन्धका कारण link बाहिर खोलिन सक्छ।
- आफ्नै वा अनुमति प्राप्त audio/video/image/document attachment browser को IndexedDB मा स्थानीय रूपमा राखिन्छ। Browser data हटेमा स्थानीय attachment हराउन सक्छ; cloud backup अहिले जडान भएको छैन।
- Chat API मा सामग्रीका शीर्षक र प्रयोगकर्ताले लेखेका सन्दर्भ पठाइन्छन् ताकि AI ले रुचि बुझेर संवाद गर्न सकोस्। पुरानो प्रतिक्रिया user recollection हो, AI ले वास्तविक घटना भनेर दाबी गर्नु हुँदैन।
- Copyrighted streaming गीत app बाट copy/download हुँदैन; provider link/official embed प्रयोग हुन्छ।
- “च्याटसँगै सुन्नुहोस्” mini-player: समर्थित YouTube/Spotify embed वा आफ्नै audio/video फाइल छुट्टै floating player मा खुल्छ र Chat पृष्ठमा जाँदा पनि player देखिइरहन्छ। अन्य provider ले आधिकारिक app मा खोल्न सक्छ।


ABI v2.12 थपिएका कुरा:
- सेटिङमा 🔎 आइकन मार्गदर्शिका: मुख्य मेनु, sub-icon र तिनको कामको व्याख्या।
- लेख्ने/छान्ने text fields का drafts browser localStorage मा स्वतः सुरक्षित हुन्छन्।
- Binary files र audio का लागि छुट्टै upload/save प्रक्रिया आवश्यक हुन्छ; browser storage/cloud backup स्वतः सुनिश्चित हुँदैन।
- अन्जु भावना, अन्जु स्मृति र अबि सुधार अलग उद्देश्यका क्षेत्र हुन्।

v2.13 — कहानी अभिलेख र भिडियो सन्देश
- तीन समयखण्ड: २०८१ पुस १–२०८२ असार १; २०८२ असार २–कार्तिक २२; २०८३ बैशाख १–असोज २।
- नेपाली voice रेकर्ड/अपलोड, Speech-to-Text, editable transcript र प्रयोगकर्ताले “हुन्छ, सुरक्षित गर” गरेपछि मात्र अभिलेख।
- स्वीकृत कहानी र प्रयोगकर्ताले लेखेको परिस्थिति/व्यवहार विवरण Chat सन्दर्भमा पठाइन्छ।
- अन्जुले पठाएका भिडियो सन्देशका लागि video file, परिस्थिति, देखिएको/सुनिएको सामग्री र प्रयोगकर्ताको व्याख्या अलग-अलग सुरक्षित हुन्छ।
- भिडियो स्थानीय IndexedDB मा रहन्छ; हाल AI ले भिडियोको दृश्य वा आवाज स्वतः विश्लेषण गर्दैन। विवरण मात्र Chat सन्दर्भमा जान्छ।
- नेपाली transcription र AI Chat का लागि hosting मा OPENAI_API_KEY आवश्यक छ; API key नहुँदा स्थानीय fallback चल्छ।


ABI v2.14 — नेपाली मिति डायरी र एकीकृत अभिलेख खोज
- २०८३ बैशाख १ देखि असोज २ सम्मको क्लिक गर्न मिल्ने नेपाली पात्रो। महिनाका दिन संख्या र साताका सुरुका दिन २०८३ को प्रकाशित पात्रोअनुसार राखिएका छन्; असोज १ र २ मात्र यो डायरी दायरामा देखिन्छन्।
- प्रत्येक दिनको entry छुट्टै YYYY-MM-DD BS key मा सुरक्षित हुन्छ। अर्को मितिको लेखाइमा मिसिँदैन। लेख्दा स्थानीय मस्यौदा स्वतः सुरक्षित हुन्छ; अन्तिम अभिलेखका लागि स्पष्ट Save बटन चाहिन्छ।
- शीर्षक, पाठ, प्रसङ्ग, व्यक्ति, भावना, वर्ग, स्रोत र प्रयोगकर्ताको पुष्टि स्थिति छुट्टाछुट्टै metadata का रूपमा राखिन्छ। मिति/शब्द/व्यक्ति/प्रसङ्ग खोज र सबै विभागको एकीकृत खोज उपलब्ध।
- सुरक्षित दैनिक डायरीका अन्तिम ३० प्रविष्टि API chat context मा metadata सहित पठाइन्छन्। अपुष्ट प्रविष्टि अपुष्ट नै चिनिन्छ; AI ले अनुमानलाई प्रमाणित तथ्य मान्नु हुँदैन।
- पुराना PDF library बाट अलग्गै देखाइन्छन्; मूल PDF वा पुरानो स्मृति मेटिएको/overwrite गरिएको छैन।
- सबै डेटा अझै यस browser को localStorage/IndexedDB मा निर्भर छ। Cloud sync, multi-device database, login/authentication, encryption-at-rest र पूर्ण production security लागू भएको छैन। Backup नियमित निकाल्नुहोस्।
- पात्रोको BS महिना-दिन/weekday reference: EnglishToNepali 2083 calendar, Calendaw 2083, Nepali Calendar PDF (स्रोतहरू build notes मा जाँचिएका)।

ABI v2.15 — पूर्ण स्थानीय backup र restore सुधार
- Backup निकाल्दा localStorage को ABI state सँगै IndexedDB मा रहेका audio/video/file attachment हरू पनि JSON backup मा समावेश हुन्छन्।
- Restore गर्दा हालको सामग्री हटाउनुको सट्टा पुरानो र backup सामग्री मिसाइन्छ; दैनिक डायरीका मिति-आधारित अभिलेख र मस्यौदा पनि समावेश हुन्छन्।
- Restore पछि कहानी, भिडियो, भावना, मेरो संसार र डायरी सूची पुनः refresh हुन्छन्।
- PDF का अस्थायी browser object URL backup मा उपयोगी नहुने भएकाले PDF नाम मात्र राखिन्छ; मूल PDF छुट्टै सुरक्षित राखेर पुनः upload गर्नुपर्छ।
- यो स्थानीय backup हो; encryption/password protection वा cloud sync होइन। Backup फाइल निजी र सुरक्षित स्थानमा राख्नुहोस्।


v2.16.1 सुधार: Gemini API ले chat र नेपाली voice transcription दुवै चलाउने मार्ग। Render Environment मा GEMINI_API_KEY राखेपछि मात्र AI/Voice चल्छ। Free quota सीमित हुन्छ; असीमित प्रयोगको ग्यारेन्टी छैन। Voice transcript प्रयोगकर्ताले समीक्षा/सच्याएपछि मात्र स्मृतिमा राख्ने। 14MB सम्मका audio upload; browser/device र audio format अनुसार नतिजा फरक हुन सक्छ। वास्तविक नेपाली आवाज परीक्षण API key र वास्तविक recording बिना प्रमाणित गर्न सकिँदैन। Master Structure DOCX का सबै उपलब्ध अनुच्छेद retrieval archive मा छन्। Viber HTML नमुना भएकाले त्यसका संवाद स्मृतिमा आयात गरिएको छैन।

महत्त्वपूर्ण निःशुल्क/सुरक्षा सीमा:
- Render सेवा Free plan मै रहने गरी राखिएको छ; Free सेवा निष्क्रिय हुँदा sleep हुन सक्छ।
- Gemini API Free quota/दर-सीमा Google ले तोक्छ र परिवर्तन गर्न सक्छ; unlimited होइन। Billing enable नगर्नुहोस्।
- Gemini API Key प्रयोगकर्ताले Google AI Studio बाट आफैँ बनाइ Render Environment मा GEMINI_API_KEY का रूपमा राख्नुपर्छ। Key सार्वजनिक GitHub, ZIP, वा ChatGPT सन्देशमा नराख्नुहोस्।
- ABI ले Gemini मा प्रश्नसँग मिल्ने स्मृति अंश र प्रयोगकर्ताले पठाएको सन्देश/voice transcript पठाउँछ। निजी डाटा Google लाई पठाइन्छ भन्ने कुरा बुझेर मात्र प्रयोग गर्नुहोस्।
- Render Free को स्थानीय filesystem स्थायी backup होइन। Browser localStorage/IndexedDB र Render मा राखिएका upload हरू हराउन सक्छन्; नियमित ABI Backup डाउनलोड गरी सुरक्षित राख्नुहोस्।
- कुनै पनि transcription लाई प्रयोगकर्ताले सुनेर/पढेर सच्याएपछि मात्र अन्जु स्मृतिमा स्वीकृत गर्नुहोस्। नेपाली उच्चारण, पृष्ठभूमि आवाज र नामका कारण गल्ती हुन सक्छ।
- यो संस्करणको syntax/JSON/ZIP जाँच गरिएको छ; API key बिना live Gemini, नेपाली recording र वास्तविक Android browser end-to-end परीक्षण सम्भव भएन। त्यसैले वास्तविक voice accuracy सफल भएको दाबी गरिएको छैन।

ABI v2.18.0 सुधार:
- विशालको अवस्था अभिलेखमा “केटाकेटी हुँदा” छुट्टै विकल्प थपियो।
- सुरक्षित हटाउने विभागमा कारण, स्रोत/प्रमाण, तीन पुष्टि प्रश्न र ठ्याक्कै वाक्य टाइप गर्ने अन्तिम पुष्टि राखियो।
- हटाइएका प्रयोगकर्ता-थप सामग्रीलाई पुनःस्थापना गर्न मिल्ने स्थानीय quarantine मा राखिन्छ; photo, emotion, diary, poem, story र media सामग्री समेटिन्छ।
- मूल अन्जु स्मृतिका master section तथा retrieval chunks लाई नष्ट नगरी Gemini को सक्रिय सन्दर्भबाट निष्क्रिय/पुनःसक्रिय गर्न मिल्ने बनाइयो। मूल JSON स्रोत फाइलहरू अपरिवर्तित छन्।
- PWA launcher/favicon icon मा राधाकृष्णको चित्र राखियो; app भित्रको राधाकृष्ण चित्र कार्ड हटाइयो।
- Gemini API Key `x-goog-api-key` header बाट पठाउने व्यवस्था यथावत् राखियो।


संस्करण 2.19.0: विशालको भावना र अन्जुको भावना छुट्टाछुट्टै साना उपविभाग; आदेश विभागमा background/profile/Gemini निर्देशन; हटाउने विकल्प नामरहित सानो icon भित्र; हटाउने प्रक्रिया केवल प्रयोगकर्ताले अपलोड गरेका फोटोमा सीमित। मूल अन्जु स्मृति र भावनात्मक अभिलेख API बाट निष्क्रिय गर्न नमिल्ने गरी सुरक्षित।


ABI v2.20.0 — अन्जु स्मृति आधारित स्थानीय संवाद
- सामान्य अभिवादन, भावना बुझ्ने प्रारम्भिक प्रतिक्रिया र अन्जु स्मृतिबाट मिल्ने विवरण Gemini API नचलाइकन स्थानीय retrieval/rule-based प्रणालीबाट उत्तर दिन्छ। यो पूर्ण LLM होइन; स्मृतिमा प्रमाण नभए अनुमान नगरी स्पष्ट पार्छ।
- ताजा/सामान्य ज्ञान वा प्रयोगकर्ताले स्पष्ट रूपमा Gemini मागेको अवस्थामा मात्र Gemini 3.8 Flash प्रयोग हुन्छ।
- Gemini अनुरोधमा 5 प्रति मिनेट र 20 प्रति नेपाल-दिनको app-side guard छ; Google परियोजनाको वास्तविक quota अन्तिम नियन्त्रण हो।
- Chat voice मा browser live speech recognition प्राथमिक हुन्छ; fallback transcription मात्र Gemini quota प्रयोग गर्छ। अन्जु परिचय/वार्तालाप विभागमा voice input browser recognition बाट हुन्छ।
- बिहान ६ र राति १० का सन्देश ABI खुला हुँदा/खोल्दा मात्र देखिन्छन्; Free hosting sleep हुँदा app बन्द अवस्थामा push schedule को ग्यारेन्टी छैन।
- अन्जु परिचयमा पढाइ र परिवार छुट्टाछुट्टै छन्; परिवारको विवरण बन्द (collapsed) निजी भण्डारमा छ। वार्तालाप विभागले संवाद शैलीका उदाहरण राख्छ।
- Master Anju Smriti र archive JSON अपरिवर्तित छन्।


ABI v2.20.1: परिवार अभिलेखमा structured member profiles थपिएका छन्। प्रत्येक सदस्यको नाम, अन्जुसँगको नाता, सम्बन्धित व्यक्ति, वर्ग, विवरण र टिप्पणी छुट्टाछुट्टै सुरक्षित हुन्छन्। Voice input browser SpeechRecognition (ne-NP) बाट चल्छ; browser support अनुसार उपलब्धता फरक हुन सक्छ। Gemini 3.8 Flash chat/transcription का लागि GEMINI_API_KEY Render Environment मा एकपटक राखे पुग्छ; source code वा ZIP मा API key नराख्नुहोस्।


नयाँ सुविधा v2.21.0: प्यारी विभागमा दैनिक निर्देशन सूची, उत्तर प्रतिक्रिया, समीक्षा इतिहास र PDF भण्डारण/पाठ निष्कर्ष/नेपाली OCR सुविधा थपिएको छ। PDF मूल फाइल IndexedDB मा सुरक्षित हुन्छ; निकालिएको पाठ प्रश्नसँग मिल्दा स्रोत र पृष्ठसहित संवादमा पठाइन्छ। PDF.js र Tesseract.js पुस्तकालय लोड गर्न इन्टरनेट चाहिन्छ। स्क्यान OCR मा त्रुटि हुन सक्छ।
सीमा: यो browser खुला हुँदा घटना-आधारित समीक्षा हो; Render Free वा बन्द browser मा निरन्तर २४ घण्टे background worker को ग्यारेन्टी छैन।

ABI v2.24.0 — प्यारी निर्देशन तथा ABI Instructions Department
- प्यारीलाई प्राथमिक निर्देशन दिने छुट्टै उपविभाग थपिएको छ।
- ABI Instructions Department मा अटो सन्देश निर्देशन, व्यक्तित्व/व्यवहार, Roman Nepali, सन्देश सुधार, स्वीकृत परिवर्तन र परीक्षण/संस्करण इतिहासका उपविभाग थपिएका छन्।
- निर्देशनहरू browser-local storage मा सुरक्षित हुन्छन् र chat अनुरोधसँग server-side prompt context मा पठाइन्छन्।
- यी सुविधाले मूल JSON स्मृति अभिलेख वा PDF फाइललाई overwrite गर्दैनन्।
- नयाँ निर्देशहरू Gemini/Pyari लाई पठाइन्छन्; स्वतः सन्देश scheduler/push delivery यस संस्करणमा पूर्ण रूपमा कार्यान्वित भएको दाबी गरिएको छैन।


ABI v2.27.0: मोबाइल स्क्रोल, विभागको छुट्टै दृश्य, अन्जुको प्रोफाइल फोटो, स्पिकर आइकन हटाउने, हल्का च्याट र Gemini को स्थानीय अनुरोध सीमा सुधार। Google को वास्तविक API quota भने Google ले निर्धारण गर्छ। PDF/मिडिया हाल browser IndexedDB मा रहन्छ; यो cloud backup होइन। Live deployment अघि वास्तविक Android परीक्षण अनिवार्य छ।

नयाँ संस्करण v2.31.0 का थप सुविधा
- Chat मा फोटो र MP4/WEBM/MOV भिडियो पठाउन सकिन्छ। भिडियोको एउटा preview frame मात्र संवाद बुझ्न प्रयोग हुन्छ; पूरा भिडियोको विश्लेषण भएको दाबी गरिँदैन।
- Sir ले अन्जुबारे नयाँ कुरा बताउँदा प्यारीले त्यसलाई परिवार, पढाइ, स्वभाव/रुचि, दैनिक व्यवहार, घटना/सम्झना वा अन्जु परिचयअन्तर्गत छुट्टै स्थानीय स्मृति प्रविष्टिका रूपमा राख्छ। मूल स्मृति JSON फाइलहरू परिवर्तन हुँदैनन्।
- फोटो प्रशंसा र care/हौसलाका धेरै संयोजन भएका संवाद बैंक थपिएका छन्।
- अन्जुको आवाज बजाउने सुविधा छैन; Sir को नेपाली voice-to-text मात्र राखिएको छ।
- Google Drive backup मा server uploads (फोटो/भिडियो) पनि सीमित आकारसम्म समावेश हुन्छन्।


ABI v2.34.1 — प्यारी हौसला उपविभाग
- प्यारी विभागको “प्यारीलाई निर्देशन दिने उपविभाग” लाई “प्यारी हौसला उपविभाग” नाम दिइयो।
- प्यारी विभागभित्र देखिने निर्देशनसम्बन्धी UI शब्दहरूलाई हौसला शब्दावलीमा रूपान्तरण गरियो।
- ABI Instructions Department र अन्जु स्मृतिका अन्य निर्देशनहरू यथावत् राखिए।
- पुराना localStorage key तथा डेटा संरचना नबदली पुरानो सामग्रीसँग अनुकूलता कायम गरियो।
