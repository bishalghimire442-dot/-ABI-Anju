# ABI v2.38.0

- Reorganized the existing workspace into exactly seven main departments.
- Preserved all 18 existing content panes as nested subdepartments; each subdepartment appears only after its parent department is opened.
- Added browser-native Nepali (`ne-NP`) voice typing controls to text inputs and textareas, including the ABI निर्देशन विभाग and dynamically added fields. Spoken text is inserted at the cursor and fires normal input events so existing save handlers continue to work.
- Preserved existing Anju memory JSON files, app features, and backup/restore logic.
- Free-hosting storage note: Render Free container files are ephemeral. Keep Google Drive OAuth configured and use the app's manual full backup/export regularly. No paid Render disk or plan is required or enabled by this update.

Voice typing depends on browser SpeechRecognition support and microphone permission; Android Chrome is recommended. Voice recognition is handled by the browser SpeechRecognition service; browser/provider privacy behavior may vary.
