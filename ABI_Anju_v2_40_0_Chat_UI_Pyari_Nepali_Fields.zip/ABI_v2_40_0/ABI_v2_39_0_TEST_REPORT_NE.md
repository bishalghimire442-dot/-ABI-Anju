# ABI v2.39.0 परीक्षण प्रतिवेदन

## यो संस्करणमा थपिएका सुधार
- “अन्जु”, “अञ्जु” वा “Anju” मात्रै पठाउँदा पनि स्थानीय संवाद तुरुन्त सुरु हुने व्यवस्था।
- दैनिक बोलचालका १०,१५२ भन्दा बढी संयोजनयुक्त अभिव्यक्ति पहिचान गर्ने phrase map; साथै सूचीमा ठ्याक्कै नभएका सामान्य वाक्यका लागि intent pattern।
- हालखबर, के गर्दै हुनुहुन्छ, खाना, स्थान, पढाइ, माया/सम्झना, आराम, मनस्थिति र सामान्य कुराकानीका फरक स्थानीय जवाफ।
- च्याटको voice typing, voice message, फोटो, भिडियो र फाइलका आइकनलाई सादा outline SVG मा परिवर्तन। पुराना button ID, input ID र event handlers जस्ताको तस्तै राखिएका छन्। Voice recording सुरु/समाप्त हुँदा पनि आइकन पुनःस्थापित हुन्छ।

## चलाइएका परीक्षण
- `node --check server.js` — पास
- `node --check public/app.js` — पास
- `node --check public/sw.js` — पास
- `npm test` — सबै चार test suites पास
  - semantic smoke / existing behavior checks
  - site-data recovery checks
  - seven departments / 18 panes / Nepali voice checks
  - नयाँ Anju casual conversation checks (१०,१५२ generated phrase combinations, one-word greetings, intent examples, composer icon presence)

## प्रत्यक्ष रूपमा अझै परीक्षण नभएका कुरा
- Android मोबाइलका विभिन्न ब्राउजरमा वास्तविक UI rendering र microphone permission
- वास्तविक Gemini API response तथा Google Drive OAuth
- Render मा नयाँ ZIP deploy गरेपछिको live परीक्षण

Gemini API key नभएको अवस्थामा स्थानीय संवादले सामान्य अभिवादन/दैनिक कुराकानी र चिनिएका intent मा जवाफ दिन्छ; बिल्कुल नयाँ तथ्यगत वा जटिल प्रश्नको शुद्ध उत्तरका लागि Gemini API उपलब्ध हुनुपर्छ।
