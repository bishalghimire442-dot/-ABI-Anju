# ABI v2.26.0 — Pyari response gate

- Corrected the late-reply apology scenario: when the user apologizes after more than 30 minutes, Anju reassures and understands them rather than expressing hurt.
- Enforced user address as tapai / Sir / Sir ji; added Roman and Devanagari pronoun cleanup.
- Removed the old repetitive, guilt-inducing late-reply response pool.
- Added varied local fallback responses and recent-reply similarity checks.
- Added Pyari behavior rules as a separate versioned data file.
- Added ABI_Master_Instructions.md as the central instruction source.
- Gemini output is screened for technical/AI wording, wrong address, and repeated answers before display.
- Chat UI now shows a warm Anju-style fallback rather than raw technical errors if the request fails.

## Not yet complete
- Full document/PDF ingestion pipeline across all departments.
- Persistent server-side conversation history and robust cross-device duplicate tracking.
- Complete ABI Instructions Department UI and approval workflow.
- Automated 100+ response quality suite and end-to-end browser tests.
- Live Gemini key/model request verification.


## v2.26.1 test correction
- Removed the prohibited “Aiyoo” expression from the late-apology fallback example.
- Verified the default Gemini model ID `gemini-3.8-flash` against Google AI for Developers documentation.
