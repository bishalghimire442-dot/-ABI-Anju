# ABI Anju v2.40.0 — Final Handoff Build

यो उपलब्ध स्रोत, स्वचालित परीक्षण र कोड-स्तरको निरीक्षणका आधारमा तयार गरिएको अन्तिम हस्तान्तरण प्याकेज हो। यसलाई production-certified वा पूर्ण end-to-end verified release भनेर बुझ्नु हुँदैन।

## समावेश
- सात मुख्य विभाग र १८ उपविभागको संरचना
- सन्दर्भअनुसार छोटो जवाफ बुझ्ने संवाद सुधार तथा १६० विविध proactive उदाहरण
- प्रति-जवाफ प्रतिक्रिया/मूल्यांकन संरचना, सन्देश सम्पादन इतिहास
- PDF सीमा: प्रति फाइल ५० MB र अधिकतम ४०० पृष्ठ
- नेपाली+अंग्रेजी OCR प्रक्रिया र प्रत्येक तीन पृष्ठमा checkpoint; बीचमै रोकिएपछि सुरक्षित पृष्ठबाट पुनः सुरु गर्ने आधार
- Recycle Bin तथा recovery safeguards
- विस्तृत अतिरिक्त परीक्षण प्रतिवेदन

## यस प्याकेजमा पुनः पुष्टि भएका परीक्षण
- `npm test`: पाँचै test groups सफल
- `node --check server.js`: सफल
- `node --check public/app.js`: सफल
- `node --check public/sw.js`: सफल
- ZIP integrity: प्याकेज बनाउँदा छुट्टै जाँच गर्नुपर्ने

## अझै उत्पादनस्तरमा प्रमाणित नभएका विषय
- ३३८ पृष्ठको सम्पूर्ण PDF OCR पूरा गरी प्रत्येक पृष्ठको नतिजा जाँचिएको छैन; नमुना OCR मात्र गरिएको छ।
- Gemini live response र quota पुनः उपलब्ध भएको पुष्टि छैन।
- Google Drive OAuth तथा Backup/Restore end-to-end पुष्टि छैन।
- App बन्द हुँदा Push Notification कार्यान्वयन/परीक्षण पुष्टि छैन।
- Android/Desktop वास्तविक UI परीक्षण, bulk file operations र cross-device persistence पूर्ण पुष्टि छैन।
- Pyari feedback को `pending → processed → applied → retested` पूर्ण जीवनचक्र प्रमाणित छैन।
- Production deployment गरिएको छैन। GitHub push वा Render deploy गरिएको छैन।

## महत्वपूर्ण संरक्षण
- मूल `(ABI)~.pdf` र `@ABI.pdf` यस ZIP मा समावेश छैनन् र परिवर्तन गरिएका छैनन्। तिनलाई छुट्टै सुरक्षित राख्नुहोस्।
- PDF/OCR डाटा हाल browser IndexedDB मा रहन्छ; आफैँ Google Drive मा sync हुन्छ भन्ने ग्यारेन्टी छैन।
- Hosting/Deployment मा कुनै paid plan/add-on चयन गरिएको छैन।

## Runtime
- Node.js >= 20
- `npm install` (эсвэл `npm ci`, lockfile उपलब्ध भएमा)
- `npm test`
- `npm start`

यो handoff build हो; माथि उल्लेखित बाँकी परीक्षण र सेवा जडान पूरा नभएसम्म production-ready भनी घोषणा गरिएको छैन।
