# ABI Anju v2.40.0 RC2 — अतिरिक्त परीक्षण प्रतिवेदन

मिति: २०२६-११-१८
परीक्षण गरिएको build: `ABI_Anju_v2_40_0_RC2_338page_PDF_Resume.zip`

## १. पास भएका परीक्षण

- `npm test`: पाँचै परीक्षण सुइट पास।
- Semantic smoke tests: पास (६ मुख्य परीक्षण, relevance, department coverage र guard checks)।
- Site-data recovery tests: पास (७ recovery/backup guard अवस्थाहरू)।
- Department/voice tests: पास (७ मुख्य विभाग, १८ mapped panes)।
- Anju conversation tests: पास (१०,१५२ phrase combinations, १६० proactive उदाहरण र contextual short-reply checks)।
- PDF capacity tests: पास (५० MB सीमा, ४०० पृष्ठ सीमा, OCR मार्ग, resumable checkpoints र cleanup)।
- `node --check server.js`, `public/app.js`, `public/sw.js`: पास।
- ZIP integrity (`unzip -t`): पास।

## २. वास्तविक फाइल/PDF नमुना परीक्षण

- मूल `(ABI)~.pdf`: ३३८ पृष्ठ, A4, ३२,६१३,३६० bytes।
- मूल `@ABI.pdf`: ९९ पृष्ठ, A4, २३,४३६,२६१ bytes (metadata पूर्व जाँचबाट पुष्टि)।
- ३३८-पृष्ठ PDF का पहिलो ३ पृष्ठ OCR नमुना: पृष्ठ २ र ३ मा नेपाली पाठ प्राप्त; पृष्ठ १ मा पढ्न मिल्ने पाठ प्राप्त भएन।
- सम्पूर्ण ३३८ पृष्ठ OCR गरिएको छैन।
- मूल PDF हरू यस परीक्षणमा परिवर्तन गरिएको छैन।

## ३. कोडमा भेटिएका तर end-to-end प्रमाणित नभएका सुविधा

- User message edit, edit history र edited label।
- Recycle Bin restore/permanent-delete flow।
- Pyari answer rating र feedback record।
- IndexedDB PDF storage र OCR checkpoint/resume।
- Google Drive OAuth, backup, download र restore API routes।
- Voice message upload/playback र transcription API routes।

यी सुविधा कोडमा भेटिनु मात्र वास्तविक ब्राउजर/सेवा परीक्षण सफल भएको प्रमाण होइन।

## ४. बाँकी/अपूर्ण वा अवरुद्ध परीक्षण

- Server/browser end-to-end परीक्षण: रोकिएको। `express` र `multer` निर्भरता उपलब्ध थिएन; `npm install --ignore-scripts --no-audit --no-fund` समयसीमाभित्र पूरा भएन।
- Chromium headless static page परीक्षण: वातावरणमा समयसीमा नाघ्यो; UI rendering/console/network परीक्षण पूरा भएन।
- Android/Desktop वास्तविक UI, keyboard/viewport, media permissions: परीक्षण नभएको।
- Gemini live response: API quota/credential अवस्था कारण यस परीक्षणमा पुष्टि नभएको।
- Google Drive OAuth र वास्तविक backup/restore: पुष्टि नभएको।
- Full 338-page OCR: नगरेको; केवल ३ पृष्ठको नमुना।
- Push notifications when app is closed: Push API/Notification permission implementation भेटिएन; सुविधा अपूर्ण।
- File Manager multi-select/select-all/bulk actions: स्पष्ट कार्यान्वयन भेटिएन; सुविधा अपूर्ण।
- Pyari lifecycle `pending → processed → applied → retested`: पूर्ण lifecycle प्रमाणित/कार्यान्वयन भेटिएन।

## ५. मूल PDF र RC2 SHA-256

- `(ABI)~.pdf`: `24a516c28e42eab320f3f3eec7fe044de8112d5eef0370163eeff7b567de79fe`
- `@ABI.pdf`: `0ee30aacebe5dd847ca9665484fc214b4a111f4a7e75047f6a26c32b739f1dc2`
- RC2 ZIP: `7e31dbaf7804313194e9459c1abbc3fee1c1efc2b6151308540603ff1258ba49`

## निष्कर्ष

RC2 का automated regression/build-level परीक्षण पास छ। तर यो **production-ready पूर्ण स्वीकृति होइन**। Server/browser runtime, वास्तविक Drive/Gemini integration, सम्पूर्ण OCR, मोबाइल/डेस्कटप UI र माथि उल्लेखित अपूर्ण सुविधाहरू पूरा/परीक्षण नभएसम्म RC2 लाई Release Candidate कै रूपमा राख्नुपर्छ। कुनै GitHub push वा Render deployment गरिएको छैन; कुनै paid सेवा/plan प्रयोग गरिएको छैन।
