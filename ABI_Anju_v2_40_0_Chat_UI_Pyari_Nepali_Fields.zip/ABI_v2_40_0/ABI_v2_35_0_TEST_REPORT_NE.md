# ABI v2.35.0 — परीक्षण प्रतिवेदन

## कोड जाँच
- `node --check server.js` — सफल
- `node --check public/app.js` — सफल
- `npm test` — semantic smoke tests र site-data recovery guard tests सफल
- ZIP integrity — प्याकेज तयार भएपछि जाँच गरिनेछ

## नयाँ सुरक्षा व्यवहार
1. ब्राउजरको स्थानीय state नभेटिएमा ABI ले यसलाई सम्भावित site-data deletion/fresh browser अवस्था मान्छ।
2. Google Drive जोडिएको छ भने पुरानो Backup डाउनलोड/Restore गर्ने प्रयास पहिले हुन्छ।
3. Restore पूरा नभएसम्म खाली state Drive मा Upload हुन दिइँदैन।
4. Chrome बाट site data हटाउँदा OAuth cookie र ABI login cookie पनि मेटिन सक्छन्; त्यस अवस्थामा फेरि login गरी Google Drive पुनः जोड्नुपर्छ। Drive भित्रका backup files भने Chrome site data delete गर्दा मेटिँदैनन्।
5. Restore ले पुराना सामग्री हटाउने होइन, merge गर्ने पुरानै व्यवहार कायम राख्छ।

## महत्त्वपूर्ण सीमा
- यो Chrome को Delete data बटनलाई रोक्ने उपाय होइन; backup बाट पुनः प्राप्त गर्ने सुरक्षा हो।
- Google Drive जोडिएको हुनुपर्छ र पछिल्लो परिवर्तन सफलतापूर्वक Backup भएको हुनुपर्छ। ABI बन्द भएको वा नेटवर्क/API असफल भएको अवधिका नयाँ परिवर्तन Drive मा नपुगेका हुन सक्छन्।
- Render Free filesystem स्थायी storage होइन। यस संस्करणले कुनै paid Render सेवा वा add-on थप्दैन।
- वास्तविक Android Chrome मा site-data deletion पछिको end-to-end recovery र वास्तविक Google OAuth/Drive restore परीक्षण प्रयोगकर्ताको खातामा Deploy गरेपछि मात्र गर्न सकिन्छ।
