# ABI v2.28.0

- Added server-validated app login using ABI_APP_PASSWORD environment variable and signed 12-hour HttpOnly session cookie.
- Added server-validated deletion confirmation using separate ABI_DELETE_PASSWORD environment variable.
- Added a visible सामग्री व्यवस्थापन department; deletion center supports user-added gallery photos, poems, instructions, diary entries, stories, video messages, emotion entries, PDF entries, chat messages, media items, family profiles, and Pyari instructions; every removal retains reason/evidence/final-confirmation checks plus the separate deletion password.
- Added five-minute local recovery snapshots for app state. Existing full export/restore continues to include IndexedDB attachments.
- App password and deletion password are not embedded in source; configure them only in Render environment variables.

## Backup limitation
Automatic recovery snapshots are local to the same browser/device. Full PDF/media backup still requires using the existing full backup export and saving the downloaded file somewhere independent. Render Free filesystem is ephemeral; this release does not claim automatic off-device/cloud backup.
