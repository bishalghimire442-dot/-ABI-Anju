# ABI v2.37.0 — परीक्षण प्रतिवेदन

## लागू गरिएका सुधार
- सबै प्रयोगकर्ताले तोकेका विभागका नाम/विषयहरू कायम राखिएका छन्; सामग्री व्यवस्थापन र खोजका मेनु लेबल स्पष्ट पारिएका छन्।
- सबै विभागका सम्बन्धित डायरी, कहानी, कविता, भावना, परिवार, मेरो संसार, Voice-सन्दर्भ, निर्देशन र PDF सामग्रीलाई अन्जुको स्वाभाविक संवादमा रूपान्तरण गर्ने prompt नियम बलियो बनाइएको छ।
- सामान्य संवादमा PDF/फाइल/स्रोत/अभिलेखको नाम नबताउने नियम थपिएको छ; स्रोत सोधिएमा मात्र बताउने व्यवहार निर्देशन गरिएको छ।
- PDF का लागि PDF नाम, “कुन सन्दर्भको PDF हो?”, “सम्झनैपर्ने विषय”, “सम्बन्धित मिति / विषय” र ऐच्छिक टिप्पणीका metadata fields थपिएका छन्।
- PDF metadata सहितका सम्बन्धित पृष्ठ-अंश chat request हुँदै server prompt सम्म पुग्ने wiring गरिएको छ।
- Mood छान्दा प्रोफाइल तस्वीर परिवर्तन नहुने बनाइएको छ। प्रोफाइल तस्वीर छुट्टै upload/restore बाट मात्र बदलिन्छ।
- मूल archive JSON, diary, poems, photos र अन्य project data फाइलहरू मेटाइएको वा पुनर्लेखन गरिएको छैन।

## परीक्षण नतिजा
- `npm test`: सफल (6 question-target tests, department/context coverage/source-silence guards, र 7 site-data recovery tests)
- `node --check public/app.js`: सफल
- `node --check server.js`: सफल
- `node --check public/sw.js`: सफल

## स्पष्ट सीमाहरू
- Browser मा पहिले नै रहेका PDF bytes/IndexedDB सामग्री यो ZIP ले आफैँ server मा स्थानान्तरण गर्दैन। तिनलाई छुट्टै ABI Backup/Restore बाट सुरक्षित राख्नुपर्छ।
- दुई मूल PDF स्रोतहरू Library मा जस्ताको तस्तै छन्; यस release ले तिनलाई सम्पादन वा पुनःcompress गरेको छैन।
- यो static/source-level परीक्षण हो; live Render deployment, browser interaction, Google Drive OAuth र बाह्य AI provider को live परीक्षण गरिएको छैन।
- ZIP तयार गरिएको छ; deployment/commit गरिएको छैन।
