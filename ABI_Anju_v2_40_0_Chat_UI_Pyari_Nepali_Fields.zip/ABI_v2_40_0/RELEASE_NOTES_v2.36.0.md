# ABI v2.36.0

- प्रवेश पेजबाट अनुरोध गरिएको व्याख्यात्मक वाक्य हटाइयो; पासवर्ड सुरक्षा यथावत्।
- च्याट composer लाई full-screen chat layout मा तल स्थिर र सधैँ पहुँचयोग्य बनाइयो।
- च्याटमा voice message र सामान्य कागजात attachment पठाउने सुविधा थपियो।
- सर्भरका upload फाइलहरूको सूची, खोज, PDF पहुँच र पूर्ण backup export/restore सहित फाइल तथा अभिलेख व्यवस्थापन विस्तार गरियो।
- Google Drive OAuth का लागि Web application client र exact callback URI सम्बन्धी निदान सूचना थपियो।
- Service worker cache version bump गरी पुरानो CSS/JS cache हट्ने बनाइयो।
- मूल अन्जु स्मृति, PDF स्रोत र पुराना अभिलेख नहटाई merge-only restore कायम।

Google OAuth `invalid_client` लाई कोडले मात्र ठीक गर्न सकिँदैन; Google Cloud Console मा मान्य Web application OAuth Client ID/Secret आवश्यक हुन्छ।
