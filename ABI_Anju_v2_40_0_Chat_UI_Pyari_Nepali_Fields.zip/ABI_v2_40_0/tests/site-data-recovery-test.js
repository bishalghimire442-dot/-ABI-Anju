const fs = require('fs');
const app = fs.readFileSync('public/app.js', 'utf8');
const checks = [
  ['detects missing browser state before creating defaults', /const ABI_HAD_LOCAL_STATE=Boolean\(state&&typeof state==='object'\)/.test(app)],
  ['marks Drive recovery as pending when local data is absent', /let cloudRestorePending=!ABI_HAD_LOCAL_STATE/.test(app)],
  ['blocks cloud backup while recovery is pending', /if\(!cloudConnected\|\|cloudSyncRunning\|\|cloudRestorePending\)return false/.test(app)],
  ['blocks delayed backup while recovery is pending', /if\(!cloudConnected\|\|cloudRestorePending\|\|cloudBackupTimer\)return/.test(app)],
  ['attempts Drive restore before first new backup', app.indexOf("fetch('/api/drive/download')") < app.indexOf('runCloudBackup(false);setInterval(()=>runCloudBackup(false)')],
  ['does not auto-upload an empty state when Drive is not reconnected', /if\(!cloudConnected\)\{if\(cloudRestorePending\)/.test(app)],
  ['restore returns success state and clears recovery guard', /cloudRestorePending=false;return true/.test(app)]
];
for (const [name, ok] of checks) console.log(`${ok ? 'PASS' : 'FAIL'} ${name}`);
if (checks.some(([, ok]) => !ok)) process.exit(1);
