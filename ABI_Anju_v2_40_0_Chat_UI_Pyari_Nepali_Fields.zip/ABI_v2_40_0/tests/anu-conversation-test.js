const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const server = fs.readFileSync(path.join(root, 'server.js'), 'utf8');
const start = server.indexOf('// ABI v2.40.0: context-aware natural Anju-to-Sir everyday dialogue recognition.');
const end = server.indexOf('\nfunction buildLocalAnjuReply(ctx)', start);
assert.ok(start >= 0 && end > start, 'conversation phrase registry and detector must exist');
const buildStart = server.indexOf('function buildLocalAnjuReply(ctx)', end);
const buildEnd = server.indexOf('\nfunction ', buildStart + 10);
assert.ok(buildStart >= 0 && buildEnd > buildStart, 'local Anju reply function must exist');
const source = server.slice(start, end) + '\n' + server.slice(buildStart, buildEnd) + '\nthis.api={ANJU_CASUAL_PHRASE_MAP,detectAnjuCasualIntent,buildAnjuCasualReply,buildContextualShortReply,buildLocalAnjuReply};';
const sandbox = {};
vm.runInNewContext(source, sandbox);
assert.ok(sandbox.api.ANJU_CASUAL_PHRASE_MAP.size > 1000, 'must generate over 1,000 phrase combinations');
for (const [message, intent] of [
  ['अन्जु', 'hello'], ['अञ्जु', 'hello'], ['Anju', 'hello'],
  ['हजुर अन्जु, के गर्दै हुनुहुन्छ?', 'activity'],
  ['अन्जु खाना खानुभयो?', 'food'], ['अन्जु कहाँ हुनुहुन्छ?', 'location'],
  ['अन्जु सन्चै हुनुहुन्छ?', 'wellbeing'], ['अन्जु पढाइ कस्तो हुँदैछ?', 'study'],
  ['अन्जु मलाई सम्झिनुभयो?', 'affection'], ['अन्जु मन कस्तो छ?', 'mood']
]) assert.equal(sandbox.api.detectAnjuCasualIntent(message), intent, message);
const first = sandbox.api.buildAnjuCasualReply('hello', []);
assert.ok(first && first.length > 12);
for (const greeting of ['अन्जु','अञ्जु','Anju']) {
  const answer = sandbox.api.buildLocalAnjuReply({message:greeting,conversationHistory:[]});
  assert.ok(answer && /Sir|sir/i.test(answer), `one-word greeting must trigger Anju conversation: ${greeting}`);
}

const preserveContext=[{role:'assistant',text:'यसरी नै पुराना कुरा सुरक्षित राखेर अगाडि बढौँ है Sir।'}];
const studyContext=[{role:'assistant',text:'आज पढाइलाई अलि समय दिनुहुन्छ Sir?'}];
const surpriseContext=[{role:'assistant',text:'आज एउटा नयाँ कुरा थाहा पाएँ Sir।'}];
const preserveReply=sandbox.api.buildContextualShortReply('है',preserveContext);
assert.equal(sandbox.api.buildLocalAnjuReply({message:'है',conversationHistory:preserveContext}),preserveReply,'local fallback must apply the context-aware short reply engine');
const studyReply=sandbox.api.buildContextualShortReply('है',studyContext);
const surpriseReply=sandbox.api.buildContextualShortReply('है?',surpriseContext);
assert.match(preserveReply,/surakshit|सुरक्षित/i,'agreement after preservation topic must continue that topic');
assert.match(studyReply,/padhna|पढ्न/i,'agreement after study question must continue study topic');
assert.notEqual(preserveReply,studyReply,'same short reply must vary with preceding context');
assert.match(surpriseReply,/agiko kura|anautho|अगिको कुरा|अनोठो|अनौठो|अचम्म/,'question-mark short reply must be interpreted as surprise');
for (const word of ['है','हजुर','हो','ल','अँ','हम्म','ठीक छ','ए','ओहो','किन?','अनि?','भनेपछि?','साँच्चै?']) {
  assert.ok(sandbox.api.buildContextualShortReply(word,preserveContext),`short reply should be context interpreted: ${word}`);
}

const appJs=fs.readFileSync(path.join(root,'public','app.js'),'utf8');
const libStart=appJs.indexOf('const ANJU_PROACTIVE_LIBRARY=(()=>{');
const libEnd=appJs.indexOf('\nfunction runAnjuSchedule()',libStart);
assert.ok(libStart>=0&&libEnd>libStart,'proactive library must exist');
const proactiveSandbox={};
vm.runInNewContext(appJs.slice(libStart,libEnd)+'\nthis.items=ANJU_PROACTIVE_LIBRARY;',proactiveSandbox);
assert.equal(proactiveSandbox.items.length,160,'proactive library must contain at least 160 examples');
assert.equal(new Set(proactiveSandbox.items.map(x=>x.text)).size,160,'proactive examples must be varied, not duplicate rotations');
const html = fs.readFileSync(path.join(root, 'public', 'index.html'), 'utf8');
for (const id of ['chatVoiceBtn','chatVoiceMessageBtn','chatPhotoBtn','chatVideoBtn','chatFileBtn']) assert.match(html, new RegExp('id="'+id+'"'));
assert.match(html, /<svg viewBox="0 0 24 24"/);
const css = fs.readFileSync(path.join(root, 'public', 'style.css'), 'utf8');
assert.match(css, /v2\.40\.0: quiet, consistent outline icons/);
assert.match(server, /function buildContextualShortReply/);
assert.match(server, /कम्तीमा एउटा प्रसङ्गअनुकूल emoji अनिवार्य/);
assert.match(server, /“यार” र kiss emoji/);
assert.match(fs.readFileSync(path.join(root, 'public', 'app.js'), 'utf8'), /pdf\.numPages>ABI_PDF_MAX_PAGES/);
assert.match(fs.readFileSync(path.join(root, 'public', 'app.js'), 'utf8'), /उत्तर समीक्षा/);
assert.match(fs.readFileSync(path.join(root, 'public', 'app.js'), 'utf8'), /function drawRecycleBin/);
assert.match(fs.readFileSync(path.join(root, 'public', 'app.js'), 'utf8'), /const counts=\{morning:25,night:25,day:25,evening:20,study:20,care:20,fun:25\}/);
assert.match(html, /id="proactiveEnabled"/);
assert.match(html, /id="recycleBinList"/);
assert.match(html, /<textarea id="messageInput"/);
assert.doesNotMatch(html, /अन्जुलाई केही लेख्नुहोस्/);
console.log(`ABI v2.40.0 Anju conversation tests passed (${sandbox.api.ANJU_CASUAL_PHRASE_MAP.size.toLocaleString()} generated phrase combinations + 160 unique proactive examples + contextual short-reply checks).`);
