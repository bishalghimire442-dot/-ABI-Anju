# ABI v2.30.0 — स्वाभाविक अन्जु संवाद र फोटो-सहित Chat

- अन्जुको संवाद निर्देशन थप कडा: आन्तरिक स्रोत/AI/प्राविधिक शब्द प्रयोग नगर्ने।
- जानकारी नपुगेमा अन्जुको स्वाभाविक शैलीमा Sir सँग सोध्ने।
- नयाँ जानकारी पाएपछि अन्जुको भावअनुसार प्रतिक्रिया दिन निर्देशन।
- Chat मा JPEG/PNG/WEBP फोटो पठाउने सुविधा; Gemini उपलब्ध हुँदा फोटोसहित सन्देश बुझ्ने।
- फोटो सन्देश स्थानीय chat history मा रहन्छ र मौजुदा backup state सँग समावेश हुन्छ।
- मोबाइल chat scrolling सुधार।

नोट: फोटोको दृश्य विश्लेषण Gemini API उपलब्ध र सही रूपमा configured हुँदा मात्र हुन्छ। नेपाली voice-to-text हालको browser recognition तथा server transcription fallback मै आधारित छ। वास्तविक Android उपकरणमा microphone, camera/photo picker र long-scroll परीक्षण आवश्यक छ।
