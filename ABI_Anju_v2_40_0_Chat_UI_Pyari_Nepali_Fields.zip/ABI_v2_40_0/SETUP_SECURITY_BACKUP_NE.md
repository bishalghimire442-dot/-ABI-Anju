# ABI v2.28.0 — सुरक्षा र Backup सेटअप

## Render Environment मा राख्नुपर्ने मान

यी मान GitHub source, ZIP वा सार्वजनिक `.env` फाइलमा नराख्नुहोस्। Render Dashboard → ABI service → Environment मा मात्र राख्नुहोस्:

- `ABI_APP_PASSWORD` — ABI खोल्ने पासवर्ड
- `ABI_DELETE_PASSWORD` — सामग्री हटाउनुअघि मागिने छुट्टै पासवर्ड

दुवै मान सेट गरेपछि service redeploy/restart आवश्यक हुन्छ। App login session १२ घण्टामा सकिन्छ र HttpOnly/Secure cookie प्रयोग गर्छ।

## Backup व्यवहार

- App state परिवर्तन हुँदा प्रत्येक ५ मिनेटमा सीमित आकारको स्थानीय recovery snapshot राखिन्छ। मुख्य browser state बिग्रिए/हराएमा उपलब्ध snapshot बाट पुनःलोड गर्ने प्रयास हुन्छ।
- अन्जु स्मृति, diary, chat, photos र IndexedDB का PDF/audio/video/file सहितको पूर्ण backup का लागि `अन्जु स्मृति` विभागको `पूर्ण स्थानीय backup निकाल्नुहोस्` प्रयोग गर्नुहोस्।
- डाउनलोड भएको backup लाई फोनबाहिर अर्को सुरक्षित ठाउँमा पनि राख्नुहोस्।
- स्थानीय recovery snapshot सोही browser/device मा मात्र हुन्छ। Google Drive वा अन्य cloud मा स्वचालित प्रतिलिपि यस release मा जडान गरिएको छैन। Render Free filesystem लाई स्थायी backup मान्नु हुँदैन।

## सामग्री हटाउने

`सामग्री व्यवस्थापन` विभागबाट प्रयोगकर्ताले थपेका स्थानीय फोटो, कविता, निर्देशन, डायरी, कहानी, भिडियो सन्देश, भावना, PDF, chat, media, family profile र Pyari निर्देशन हटाउन सकिन्छ। कारण/प्रमाण/अन्तिम पुष्टि र छुट्टै deletion password आवश्यक हुन्छ। मूल Anju Smriti JSON र package का source PDF यस विभागबाट हट्दैनन्।

## Mobile scroll

v2.27.0-ээс आएका workspace vertical scrolling, touch scrolling, safe-area spacing र chat scroll layout कायम राखिएको.
