# ABI v2.33.2 — Icon-only typing indicator

- Removed the visible “अन्जु लेख्दै…” label from the chat typing indicator.
- Removed explanatory text beside the indicator; only Anju's profile picture and the three animated dots remain.
- Kept the indicator tied to the live chat request; it disappears when the reply or error response is received.
- No Anju Smriti source JSON files were changed.
- This is a UI-only refinement over v2.33.1; deployment has not been performed.
