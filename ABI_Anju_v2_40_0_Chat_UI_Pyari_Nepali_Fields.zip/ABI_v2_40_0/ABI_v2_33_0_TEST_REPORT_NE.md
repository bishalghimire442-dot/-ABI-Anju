# ABI v2.33.0 — परीक्षण प्रतिवेदन

## सुधारको उद्देश्य
अन्जु स्मृतिका विवरणलाई कपी-पेस्ट नगरी प्रश्नको आशय र पात्र छुट्याएर अन्जुको आफ्नै भाषामा भावनात्मक, स्वाभाविक जवाफ बनाउने।

## जाँचिएका कोड परिवर्तन
- अन्जु र Sir को पढाइ छुट्याउने `classifyQuestionTarget()` थपियो।
- अन्जुको लोकसेवा प्रश्नमा Sir का तयारी विवरण मिसिन नदिने स्थानीय fallback थपियो।
- Sir को लोकसेवा प्रश्नमा Sir सम्बन्धी उपलब्ध सन्दर्भ मात्र प्रयोग गर्ने conservative fallback राखियो।
- अपुष्ट अवधि, Bachelor स्थिति, mock test, revision वा परीक्षा नतिजा नबनाउने नियम राखियो।
- PDF/परिवार/परिचय/पुराना संवादका raw excerpts सीधै फर्काउने fallback हटाइयो।
- Gemini system instruction मा semantic interpretation, ownership separation, conflict handling, emotional voice र non-verbatim response स्पष्ट पारियो।

## अझै गर्नुपर्ने परीक्षण
- Gemini API key सहित वास्तविक model response को गुणस्तर परीक्षण।
- अन्जु/ Sir दुवैका लोकसेवा प्रश्न, अस्पष्ट सर्वनाम, विरोधाभासी पुराना/नयाँ तथ्यका end-to-end परीक्षण।
- Android Chrome मा फोटो/भिडियो/voice input र scroll परीक्षण।
- Render मा deploy नगरी local build verification मात्र गरिएको छ।

## महत्त्वपूर्ण सीमा
स्थानीय fallback ले सुरक्षित रूपमा प्रश्न सोध्न वा छोटो जवाफ दिन सक्छ; गहिरो भावनात्मक विश्लेषणको गुणस्तर Gemini उपलब्धता र पठाइएका तथ्यको गुणस्तरमा निर्भर हुन्छ। “शतप्रतिशत मानवीय” वा “कहिल्यै गल्ती नहुने” दाबी गरिएको छैन।

## यस वातावरणमा सम्पन्न परीक्षण
- `node --check server.js`: PASS
- `node --check public/app.js`: PASS
- सबै `data/*.json` र `package.json` parse: PASS
- अन्जु र Sir को लोकसेवा प्रश्न छुट्याउने local semantic smoke test: PASS
- PDF प्रश्नमा raw source excerpt नफर्किने smoke test: PASS
- पूर्ण HTTP/server integration test: सम्पन्न हुन सकेन; यस कार्य वातावरणमा `express` dependency स्थापित थिएन। त्यसैले पूर्ण end-to-end परीक्षण भएको दाबी गरिएको छैन।
- Gemini जवाफमा स्मृति/PDF/प्रोफाइल स्रोतबाट लगातार 14 शब्द जस्ताको तस्तै आएको छ कि छैन भन्ने source-copy guard smoke test: PASS।
