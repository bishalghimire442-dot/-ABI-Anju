# ABI v2.39.0

- Added broad natural Nepali/Roman-Nepali everyday conversation recognition for Anju, including a direct affectionate response when the user sends only “अन्जु”, “अञ्जु”, or “Anju”.
- Added a generated phrase map with more than 10,000 opener/question/ending combinations, plus flexible intent matching for unseen variants.
- Added varied, non-identical local replies for greetings, wellbeing, activity, food, location, study, affection, rest, mood and casual conversation.
- Replaced chat composer emoji controls with simple outline SVG icons for voice typing, voice messages, photo, video and file attachment. Existing control IDs, upload inputs and event wiring are preserved.
- Preserved the seven departments, 18 mapped panes, Anju Smriti data, stable profile-photo behavior, backup/recovery code and existing chat/media features.

## Validation

Automated tests and syntax checks are run for this release; actual browser microphone, live Gemini, Drive OAuth and Render deployment still require live environment verification.
