# ABI v2.36.0 परीक्षण प्रतिवेदन

## सफल परीक्षण
- `node --check server.js`
- `node --check public/app.js`
- `node --check public/sw.js`
- `npm test` — semantic smoke tests र site-data recovery tests सफल
- HTML संरचना जाँच: च्याट composer, voice message, file upload, file manager र Cloud section उपस्थित
- Login पेजबाट अनुरोध गरिएको वाक्य हटेको पुष्टि

## समावेश सुधार
- Full-screen chat composer लाई sticky र सधैँ पहुँचयोग्य बनाउने CSS तथा service-worker cache version update
- वास्तविक voice-message recording/upload/playback र Gemini configured हुँदा audio inline input
- Chat मा PDF/DOCX/XLSX/PPTX/TXT/CSV/ZIP file attachment
- फाइल सूची, खोज, खोल्ने/डाउनलोड गर्ने, पूर्ण backup export र merge-only restore
- Google OAuth को वास्तविक redirect URI देखाउने र invalid-client निदान निर्देशन

## बाँकी बाह्य कन्फिगरेसन
Google Drive `401 invalid_client` पूर्ण रूपमा हटाउन Google Cloud Console बाट मान्य Web application OAuth Client ID/Secret आवश्यक छ। कोडले गलत वा मेटिएको Google credential आफैँ सिर्जना गर्न सक्दैन। Redirect URI: `https://abi-anju.onrender.com/api/drive/callback` (वा app मा देखिने configured URI)।

## संरक्षण
मूल `anju_master_memory.json`, `anju_smriti_archive.json`, सबै पुराना release स्रोत, फोटो र PDF सामग्री यथावत् राखिएका छन्।
