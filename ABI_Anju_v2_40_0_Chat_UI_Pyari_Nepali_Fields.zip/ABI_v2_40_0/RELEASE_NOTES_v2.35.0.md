# ABI v2.35.0 — Browser Site-Data Recovery Guard

- Detects when ABI opens without its previous browser-local state.
- If Google Drive is connected, attempts to restore the latest ABI backup before allowing any new cloud backup.
- Prevents an empty fresh browser state from overwriting the existing Drive backup while recovery is pending.
- If site data deletion removed the Drive OAuth cookie, asks the user to sign in again and reconnect Google Drive; Drive backup files themselves remain in Google Drive.
- Preserves merge-based restore for app state, uploaded photos, server-side uploads/voice archive and IndexedDB attachments.
- Does not claim Chrome's "Delete data and reset permissions" action can be blocked; recovery depends on a completed Drive backup.

## Limitations

- Cloud backup runs while ABI is open and Google Drive is connected; it is not continuous background sync.
- Changes made after the last successful backup may not be recoverable.
- Render Free filesystem is ephemeral; this release does not add paid Render services or persistent disks.
