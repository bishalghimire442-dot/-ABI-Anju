# ABI v2.34.0 — परीक्षण प्रतिवेदन

## गरिएको जाँच
- `node --check server.js` र `node --check public/app.js` सफल।
- `package.json` तथा मूल चार JSON फाइल parse जाँच सफल।
- `npm test` सफल: Anju/Sir target separation (६ प्रश्न), cross-department relevance ranking, सबै विभागको context coverage, technical-language guard र cache-version checks सफल।
- cross-department context builder मा परिवार, कविता, डायरी, कथा, भावना, मिडिया, भिडियो, अन्जु परिचय र स्वीकृत निर्देशन समेटिएको static coverage जाँच सफल।
- server-side relevant-context ranking र source-leak validator जडान जाँच सफल।
- अन्जु/Sir को तथ्य छुट्याउने र अन्जुको संवादमा प्राविधिक भाषा निषेध गर्ने नियम prompt तथा validation दुवै तहमा थपिएको।
- ZIP integrity जाँच सफल।

## सीमाहरू (स्पष्ट)
- यस container मा npm dependencies स्थापना/पूर्ण HTTP integration परीक्षण गरिएको छैन।
- Gemini API key र live API call उपलब्ध नभएकाले वास्तविक multi-turn semantic quality, भावना र सबै विभागका प्रश्नहरूको live test गरिएको छैन।
- Local fallback ले जटिल हजारौँ विषयमा मानव-जस्तो fluent reasoning को ग्यारेन्टी गर्दैन; यसले कच्चा अभिलेख नटाँसी सुरक्षित clarification दिन्छ।
- Android Chrome मा typing indicator, upload र scroll को अन्तिम प्रत्यक्ष परीक्षण बाँकी छ।
- Render deployment गरिएको छैन।

## स्रोत संरक्षण
- `anju_smriti_archive.json`, `anju_master_memory.json`, `anju_archive_schema.json`, `pyari_behavior_rules.json` लाई सम्पादन गरिएको छैन।
