# ABI Google Drive Cloud Backup setup (Nepali)

## 1. Google Cloud मा OAuth बनाउने
1. Google Cloud Console मा ABI का लागि एउटा project खोल्नुहोस्/बनाउनुहोस्।
2. Google Drive API enable गर्नुहोस्।
3. Google Auth Platform मा Branding/Consent screen पूरा गर्नुहोस्। परीक्षणका लागि Publishing status Testing राख्दा आफ्नो Google account लाई Test users मा थप्नुहोस्। Testing अवस्थामा Google refresh token सात दिनपछि म्याद सकिन सक्छ; लामो समयको प्रयोगका लागि consent screen लाई आवश्यक Google प्रक्रिया अनुसार Production मा प्रकाशित गर्नुहोस्।
4. OAuth Client ID बनाउँदा Application type: Web application छान्नुहोस्।
5. Authorized redirect URI मा ठ्याक्कै यो राख्नुहोस्: `https://abi-anju.onrender.com/api/drive/callback`
6. Client ID र Client Secret सुरक्षित राख्नुहोस्। Google account password वा Client Secret कसैलाई नपठाउनुहोस्।

## 2. Render Environment Variables
Render Dashboard → ABI-Anju → Environment मा यी थप्नुहोस्:
- `ABI_DRIVE_CLIENT_ID` = Google बाट पाएको Client ID
- `ABI_DRIVE_CLIENT_SECRET` = Google बाट पाएको Client Secret
- `ABI_DRIVE_COOKIE_SECRET` = कम्तीमा 32 random bytes बराबरको लामो गोप्य value (उदाहरणका लागि password manager बाट generate गर्नुहोस्)
- `ABI_DRIVE_REDIRECT_URI` = `https://abi-anju.onrender.com/api/drive/callback`
Save Changes गरेपछि deploy सकिन दिनुहोस्। Free plan नै राख्नुहोस्।

## 3. ABI बाट अनुमति दिने
1. ABI मा login गर्नुहोस्।
2. Settings → Cloud Backup → Google Drive सुरक्षित रूपमा जडान गर्नुहोस् थिच्नुहोस्।
3. सही Google account छानेर ABI ले आफ्नो सिर्जना गरेका backup files मात्र बनाउन/अपडेट गर्न पाउने अनुमति दिनुहोस्।
4. फर्केर ABI को Cloud Backup विभागमा status जाँच्नुहोस् र “अहिले नै Backup गर्नुहोस्” थिचेर परीक्षण गर्नुहोस्।

## 4. कसरी चल्छ
- ABI खुला हुँदा सामग्री परिवर्तनपछि करिब 2 मिनेटमा Backup schedule हुन्छ र प्रत्येक 15 मिनेटमा फेरि sync हुन्छ।
- हरेक दिन एउटा JSON Backup बनाइन्छ/अपडेट हुन्छ। पुराना दैनिक Backup स्वतः मेटिँदैनन्।
- Backup मा ABI browser state र IndexedDB attachment (PDF/photo/audio/video/file) समावेश हुन्छन्। धेरै ठूलो Backup भए Render request limit वा Google Drive quota ले असफल हुन सक्छ।
- App/browser बन्द हुँदा browser-based sync चल्दैन। ABI फेरि खोल्दा sync फेरि चल्छ। पूर्ण background sync का लागि छुट्टै scheduler र स्थायी token storage चाहिन्छ; त्यसलाई थप पूर्वाधार र सुरक्षा समीक्षा बिना सक्षम गरिएको छैन।
- OAuth refresh token Secure, HttpOnly cookie मा AES-GCM encrypted हुन्छ; ABI Drive scope `drive.file` मात्र हो।

## 5. Restore
Cloud Backup विभागको “Drive बाट पछिल्लो Backup फर्काउनुहोस्” बटनले पछिल्लो दैनिक Backup डाउनलोड गरी हालको सामग्रीसँग merge गर्छ। पुराना सामग्री स्वतः मेटिँदैनन्। Restore अघि चाहनुहुन्छ भने स्थानीय Export पनि निकाल्नुहोस्।
