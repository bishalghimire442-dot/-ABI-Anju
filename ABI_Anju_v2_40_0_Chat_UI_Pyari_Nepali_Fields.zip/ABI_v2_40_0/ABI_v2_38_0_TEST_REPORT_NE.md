# ABI v2.38.0 परीक्षण प्रतिवेदन

## स्रोत-स्तर परीक्षण
- `node --check public/app.js` — सफल
- `node --check server.js` — सफल
- `node --check public/sw.js` — सफल
- `npm test` — सफल: semantic smoke/guard tests र ७ site-data recovery tests

## समावेश गरिएको संरचना
- ७ मुख्य विभाग; १८ पुराना content panes सात समूहमा उपविभागका रूपमा म्याप गरिएका छन्।
- विभाग नखोली उपविभाग नदेखिने; उपविभाग खोलेपछि मात्र सम्बन्धित सामग्री pane खुल्ने।
- सबै editable text inputs र textareas मा browser-native Nepali (`ne-NP`) voice typing control थपिएको छ। ABI निर्देशन विभागका सबै textarea पनि यसमा पर्छन्। नयाँ रूपमा बनेका text fields मा पनि MutationObserver मार्फत बटन थपिन्छ।

## परीक्षणको सीमा
- वास्तविक Android Chrome microphone परीक्षण, speech recognition provider व्यवहार, Google Drive OAuth र Render production UI/browser परीक्षण गरिएको छैन। Voice typing का लागि browser support र microphone permission चाहिन्छ।
- Render Free को container filesystem स्थायी भण्डारण होइन। Google Drive OAuth sync र नियमित manual full backup/export प्रयोग गर्नुहोस्। यस संस्करणले कुनै paid Render plan वा disk थपेको छैन।
