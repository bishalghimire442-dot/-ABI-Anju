# ABI Anju v2.40.0 — GitHub staging upload

यो प्याकेज पुरानो Repository फाइलहरू नमेटाई नयाँ `ABI_v2_40_0/` folder थप्न तयार गरिएको हो।

## GitHub मा राख्ने तरिका
1. Repository खोल्नुहोस्: https://github.com/bishalghimire442-dot/-ABI-Anju
2. `main` मा सिधै परिवर्तन नगर्नुहोस्। नयाँ branch `abi-v2-40-0-staging` सिर्जना गर्नुहोस्।
3. यस ZIP भित्रका `ABI_v2_40_0/` folder का सबै contents र root `Dockerfile` लाई repository को root मा upload गर्नुहोस्।
4. `Dockerfile` पहिलेदेखि छ। त्यसैले पुरानो main branch मा Replace नगर्नुहोस्; staging branch मा मात्र नयाँ Dockerfile राख्नुहोस्।
5. Commit गरेपछि Render मा Deploy नगरी पहिले staging branch को files र Dockerfile जाँच गर्नुहोस्।

## Render setting
- Dockerfile Path: `./Dockerfile`
- Build Context: repository root
- Runtime uses `ABI_v2_40_0/` only.
- Keep existing free plan; do not enable paid add-ons.

## Important
- Existing v2.39 ZIP and all old files are intentionally not included for deletion or replacement.
- Original Anju PDFs are not included or modified.
- This is a staging source bundle, not proof of a successful Render deployment or end-to-end production certification.
