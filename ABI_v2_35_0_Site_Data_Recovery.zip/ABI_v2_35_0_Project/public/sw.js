const CACHE='abi-v2.34.2-static';
self.addEventListener('install',event=>event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll(['/style.css','/app.js','/manifest.webmanifest','/photos/love-chat-bg.png']))));
self.addEventListener('activate',event=>event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(key=>key!==CACHE).map(key=>caches.delete(key))))));
self.addEventListener('fetch',event=>{
  if(event.request.method!=='GET')return;
  const url=new URL(event.request.url);
  // Never cache HTML, API responses, login pages, or user uploads: server-side auth must always run.
  if(url.origin!==self.location.origin||url.pathname==='/'||url.pathname.endsWith('.html')||url.pathname.startsWith('/api/')||url.pathname.startsWith('/uploads/')||url.pathname==='/login'){
    event.respondWith(fetch(event.request));return;
  }
  event.respondWith(caches.match(event.request).then(cached=>cached||fetch(event.request).then(response=>{
    if(response.ok){const copy=response.clone();caches.open(CACHE).then(cache=>cache.put(event.request,copy));}
    return response;
  })));
});
