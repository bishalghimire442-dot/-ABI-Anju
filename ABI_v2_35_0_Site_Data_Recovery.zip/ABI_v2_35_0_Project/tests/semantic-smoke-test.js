const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const server = fs.readFileSync(path.join(root, 'server.js'), 'utf8');
const client = fs.readFileSync(path.join(root, 'public', 'app.js'), 'utf8');

function extractFunction(name, nextName) {
  const start = server.indexOf(`function ${name}(`);
  assert.notEqual(start, -1, `missing function ${name}`);
  const end = server.indexOf(`\nfunction ${nextName}(`, start);
  return server.slice(start, end === -1 ? server.length : end);
}
const exposed = {};
const helpers = [
  extractFunction('classifyQuestionTarget', 'replyLeaksSourceText'),
  extractFunction('rankDepartmentContext', 'buildLocalAnjuReply'),
  'this.api = { classifyQuestionTarget, rankDepartmentContext };'
].join('\n');
vm.runInNewContext(helpers, exposed);

const targetCases = [
  ['अन्जु तिम्रो लोकसेवा तयारी कस्तो चल्दैछ?', 'anju'],
  ['मेरो लोकसेवा तयारी कस्तो छ?', 'user'],
  ['अन्जु, तिम्रो परिवारको कुरा सुनाऊ न', 'anju'],
  ['मेरो परिवारको बारेमा के थाहा छ?', 'user'],
  ['तपाईंको बानी कस्तो छ अन्जु?', 'anju'],
  ['मलाई मेरो पढाइमा के सुधार गर्नुपर्ला?', 'user']
];
for (const [question, expected] of targetCases) {
  assert.equal(exposed.api.classifyQuestionTarget(question), expected, question);
}

const ranked = exposed.api.rankDepartmentContext('सङ्गीता को हुन्?', [
  { department: 'कविता', title: 'प्रेम कविता', owner: 'अस्पष्ट', text: 'माया र मनका शब्द' },
  { department: 'परिवार तथा नाता', title: 'सङ्गीता', owner: 'अन्जुको परिवार', text: 'जनक दाइकी छोरी' }
]);
assert.equal(ranked[0].title, 'सङ्गीता');

for (const marker of [
  'buildDepartmentContextForChat', 'दैनिक डायरी', 'समयक्रम कहानी', 'अन्जु भावना',
  'Sir को भावना र अन्जुको प्रतिक्रिया', 'भिडियो सन्देश', 'मेरो संसार', 'कविता',
  'परिवार तथा नाता', 'प्यारी हौसला', 'ABI Instructions Department', 'अन्जु परिचय', 'वार्तालाप शैली'
]) assert.ok(client.includes(marker), `missing department context: ${marker}`);
assert.match(server, /प्राविधिक\/AI\/सर्भर\/API\/डेटाबेस/);
assert.match(server, /replyLeaksSourceText\(reply, \[sourceContext, rankedDepartmentContext, memoryInstructions/);
assert.match(fs.readFileSync(path.join(root, 'public', 'sw.js'), 'utf8'), /abi-v2\.34\.2-static/);
const html = fs.readFileSync(path.join(root, 'public', 'index.html'), 'utf8');
assert.match(html, /प्यारी हौसला उपविभाग/);
assert.match(html, /हौसला सुरक्षित गर्नुहोस्/);
assert.match(html, /ABI Instructions Department/);
const pyariPane = html.slice(html.indexOf('<section id="pyari"'), html.indexOf('<section id="abiInstructions"'));
assert.ok(!pyariPane.includes('निर्देशन'), 'Pyari pane must use हौसला terminology only');
assert.match(pyariPane, /प्यारी हौसला उपविभाग/);
assert.match(html, /अटो सन्देश निर्देशन/);
assert.match(client, /प्यारी विभागको निर्देशन/);
assert.doesNotMatch(client, /प्यारी विभागको हौसला/);
console.log(`ABI v2.34.2 semantic smoke tests passed (${targetCases.length} target tests + relevance + department coverage + guard checks).`);
