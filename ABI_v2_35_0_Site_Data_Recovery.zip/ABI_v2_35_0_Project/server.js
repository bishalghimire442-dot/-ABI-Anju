const express = require('express');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const multer = require('multer');
const app = express();
// Read runtime secrets safely; never expose their values in health responses or logs.
function envValue(name) {
  const value = process.env[name];
  return typeof value === 'string' ? value.trim() : '';
}
const memory = JSON.parse(fs.readFileSync(path.join(__dirname, 'data', 'anju_master_memory.json'), 'utf8'));
const smritiArchive = JSON.parse(fs.readFileSync(path.join(__dirname, 'data', 'anju_smriti_archive.json'), 'utf8'));
const pyariBehaviorRules = JSON.parse(fs.readFileSync(path.join(__dirname, 'data', 'pyari_behavior_rules.json'), 'utf8'));
function detectBishalEmotion(message, history = []) {
  let q = String(message || '').toLocaleLowerCase('ne');
  const groups = [
    { mood: 'रिस', words: ['रिस', 'झोक', 'क्रोधित', 'angry', 'mad', 'annoyed', 'irritat', 'झर्को', 'चिढ'] },
    { mood: 'खुसी', words: ['खुसी', 'रमाइलो', 'आनन्द', 'उत्साहित', 'happy', 'excited', 'great news', 'वाह', 'दङ्ग'] },
    { mood: 'दुःख', words: ['दुःख', 'दुखि', 'निराश', 'एक्लो', 'रुन', 'मन भारी', 'sad', 'upset', 'hurt', 'पीडा', 'आँसु'] },
    { mood: 'धेरै सोचाइ', words: ['overthink', 'धेरै सोच', 'सोचेर', 'चिन्ता', 'तनाव', 'आत्त', 'डर लाग', 'के होला', 'anxious', 'worry', 'निद्रा लागेन'] },
    { mood: 'बाल्यकाल', words: ['केटाकेटी हुँदा', 'बाल्यकाल', 'सानो हुँदा', 'बाल्यकालको', 'childhood', 'बचपन'] }
  ];
  let scores = groups.map(g => ({ mood:g.mood, score:g.words.reduce((n,w)=>n+(q.includes(w)?(w.length>4?2:1):0),0) })).sort((a,b)=>b.score-a.score);
  if (!scores[0]?.score) { const prior=[...history].reverse().find(x=>x.role==='user' && x.text); if(prior){q=String(prior.text).toLocaleLowerCase('ne');scores=groups.map(g=>({mood:g.mood,score:g.words.reduce((n,w)=>n+(q.includes(w)?(w.length>4?2:1):0),0)})).sort((a,b)=>b.score-a.score);} }
  return scores[0]?.score ? { mood:scores[0].mood, confidence:scores[0].score>=3?'मध्यम':'कम' } : { mood:'अस्पष्ट', confidence:'कम' };
}
function memoryChunkId(c) {
  const stable = [c?.source||'', c?.page??'', c?.section||'', c?.text||''].join('|');
  return 'chunk:' + crypto.createHash('sha256').update(stable).digest('hex').slice(0,20);
}
function selectMemoryChunks(query, mood, excludedIds = []) {
  const q = String(query || '').toLocaleLowerCase('ne');
  const moodTerms = ({'रिस':['रिस','असहमति','शान्त','झर्को'],'खुसी':['खुसी','हाँसो','रमाइलो','उत्साह'],'दुःख':['दुःख','आत्मीयता','सान्त्वना','माया'],'धेरै सोचाइ':['चिन्ता','सोच','पढाइ','सम्झना'],'बाल्यकाल':['बाल्यकाल','सानो','केटाकेटी','परिवार','स्कुल']})[mood] || [];
  const terms = [...new Set([...(q.match(/[\p{L}\p{N}]{2,}/gu)||[]),...moodTerms])].filter(x=>x.length>1);
  if (!terms.length) return [];
  const excluded = new Set(Array.isArray(excludedIds) ? excludedIds : []);
  const ranked = (smritiArchive.retrieval_chunks || []).map((c,index)=>({c,index,id:memoryChunkId(c)})).filter(x=>!excluded.has(x.id)).map(({c,index,id})=>{
    const t=String(c.text||'').toLocaleLowerCase('ne');
    const score=terms.reduce((n,term)=>n+(t.includes(term)?(t.split(term).length-1)*(moodTerms.includes(term)?3:2):0),0);
    return {c,score,index,id};
  }).filter(x=>x.score>0).sort((a,b)=>b.score-a.score||a.index-b.index);
  return ranked.slice(0,9).map(x=>({id:x.id,source:x.c.source,page:x.c.page??null,section:x.c.section||null,confidence:x.c.confidence,text:String(x.c.text).slice(0,1500)}));
}

const privateDir = path.join(__dirname, 'private_data');
const uploadDir = path.join(__dirname, 'public', 'uploads');
const audioDir = path.join(privateDir, 'audio');
fs.mkdirSync(privateDir, { recursive: true }); fs.mkdirSync(uploadDir, { recursive: true }); fs.mkdirSync(audioDir, { recursive: true });
const voiceLog = path.join(privateDir, 'voice_transcripts.json');
if (!fs.existsSync(voiceLog)) fs.writeFileSync(voiceLog, '[]');
const apiUsageFile = path.join(privateDir, 'gemini_daily_usage.json');
function nepalDayKey(){return new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Kathmandu',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date())}
function readGeminiUsage(){try{const v=JSON.parse(fs.readFileSync(apiUsageFile,'utf8'));return v.date===nepalDayKey()?{date:v.date,count:Number(v.count)||0,timestamps:Array.isArray(v.timestamps)?v.timestamps:[]}:{date:nepalDayKey(),count:0,timestamps:[]}}catch{return {date:nepalDayKey(),count:0,timestamps:[]}}}
function reserveGeminiRequest(){const usage=readGeminiUsage(),now=Date.now();usage.timestamps=usage.timestamps.filter(t=>Number.isFinite(t)&&now-t<60000);const dailyLimit=Math.max(1,Number(envValue('GEMINI_DAILY_LIMIT'))||60);
const minuteLimit=Math.max(1,Number(envValue('GEMINI_PER_MINUTE_LIMIT'))||8);
if(usage.count>=dailyLimit||usage.timestamps.length>=minuteLimit)return false;usage.count+=1;usage.timestamps.push(now);try{fs.writeFileSync(apiUsageFile,JSON.stringify(usage),{mode:0o600})}catch{return false}return true}

const audioUpload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 14 * 1024 * 1024 }, fileFilter: (_, f, cb) => cb(null, /^audio\/(webm|ogg|mpeg|mp4|wav|x-wav|aac|mp3|3gpp|flac)(?:;.*)?$/i.test(f.mimetype)) });
const photoUpload = multer({ storage: multer.diskStorage({ destination: uploadDir, filename: (_, f, cb) => cb(null, crypto.randomUUID() + path.extname(f.originalname).slice(0, 8)) }), limits: { fileSize: 8 * 1024 * 1024 }, fileFilter: (_, f, cb) => cb(null, /^image\/(jpeg|png|webp|gif)$/.test(f.mimetype)) });
const videoUpload = multer({ storage: multer.diskStorage({ destination: uploadDir, filename: (_, f, cb) => cb(null, crypto.randomUUID() + path.extname(f.originalname).slice(0, 8)) }), limits: { fileSize: 35 * 1024 * 1024 }, fileFilter: (_, f, cb) => cb(null, /^video\/(mp4|webm|quicktime)$/.test(f.mimetype)) });
app.use(express.json({ limit: '12mb' }));
// Passwords are supplied only through hosting environment variables, never committed to source.
function passwordMatches(input, expected) {
  if (!expected || typeof input !== 'string') return false;
  const a = crypto.scryptSync(input, 'ABI-password-check-v1', 32);
  const b = crypto.scryptSync(expected, 'ABI-password-check-v1', 32);
  return crypto.timingSafeEqual(a, b);
}
function sessionToken() {
  const secret = envValue('ABI_APP_PASSWORD');
  const expires = Date.now() + 12 * 60 * 60 * 1000;
  const payload = String(expires);
  const sig = crypto.createHmac('sha256', secret).update(payload).digest('hex');
  return `${payload}.${sig}`;
}
function validSession(req) {
  const token = String(req.headers.cookie || '').split(';').map(x=>x.trim()).find(x=>x.startsWith('abi_session='))?.slice(12);
  if (!token) return false;
  const [expires, sig] = token.split('.');
  if (!/^\d+$/.test(expires || '') || Number(expires) < Date.now() || !sig) return false;
  const expected = crypto.createHmac('sha256', envValue('ABI_APP_PASSWORD')).update(expires).digest('hex');
  const a=Buffer.from(sig), b=Buffer.from(expected);
  return a.length===b.length && crypto.timingSafeEqual(a,b);
}
app.get('/login', (_,res)=>res.sendFile(path.join(__dirname,'public','login.html')));
app.post('/api/auth/login', (req,res)=>{
  const configured=envValue('ABI_APP_PASSWORD');
  if(!configured) return res.status(503).json({error:'ABI_APP_PASSWORD hosting environment मा सेट गरिएको छैन।'});
  if(!passwordMatches(req.body?.password,configured)) return res.status(401).json({error:'पासवर्ड मिलेन।'});
  res.setHeader('Set-Cookie',`abi_session=${sessionToken()}; HttpOnly; Secure; SameSite=Lax; Path=/; Max-Age=43200`);
  res.json({ok:true});
});
app.post('/api/auth/logout',(req,res)=>{res.setHeader('Set-Cookie','abi_session=; HttpOnly; Secure; SameSite=Lax; Path=/; Max-Age=0');res.json({ok:true});});
app.use((req,res,next)=>{
  if(req.path==='/login'||req.path==='/api/auth/login'||req.path==='/api/auth/logout') return next();
  if(!envValue('ABI_APP_PASSWORD')) return res.status(503).send('ABI_APP_PASSWORD hosting environment मा सेट गर्नुहोस्।');
  if(!validSession(req)) return req.path.startsWith('/api/') ? res.status(401).json({error:'पहिले ABI मा लगइन गर्नुहोस्।'}) : res.redirect('/login');
  next();
});
// Google Drive OAuth: refresh tokens are encrypted in a Secure, HttpOnly cookie.
function driveCookieKey(){
  const secret=envValue('ABI_DRIVE_COOKIE_SECRET');
  return secret ? crypto.scryptSync(secret,'ABI-drive-cookie-v1',32) : null;
}
function readCookie(req,name){return String(req.headers.cookie||'').split(';').map(x=>x.trim()).find(x=>x.startsWith(name+'='))?.slice(name.length+1)||'';}
function encryptDriveToken(token){
  const key=driveCookieKey(); if(!key) throw new Error('ABI_DRIVE_COOKIE_SECRET सेट गरिएको छैन।');
  const iv=crypto.randomBytes(12), cipher=crypto.createCipheriv('aes-256-gcm',key,iv);
  const body=Buffer.concat([cipher.update(JSON.stringify(token),'utf8'),cipher.final()]);
  return Buffer.concat([iv,cipher.getAuthTag(),body]).toString('base64url');
}
function decryptDriveToken(req){
  try{const raw=readCookie(req,'abi_drive_refresh');if(!raw)return null;const b=Buffer.from(raw,'base64url');if(b.length<29)return null;
    const decipher=crypto.createDecipheriv('aes-256-gcm',driveCookieKey(),b.subarray(0,12));decipher.setAuthTag(b.subarray(12,28));
    return JSON.parse(Buffer.concat([decipher.update(b.subarray(28)),decipher.final()]).toString('utf8'));
  }catch{return null;}
}
function driveRedirectUri(){return envValue('ABI_DRIVE_REDIRECT_URI')||'https://abi-anju.onrender.com/api/drive/callback';}
function driveConfigured(){return Boolean(envValue('ABI_DRIVE_CLIENT_ID')&&envValue('ABI_DRIVE_CLIENT_SECRET')&&envValue('ABI_DRIVE_COOKIE_SECRET'));}
async function driveAccessToken(req){
  const saved=decryptDriveToken(req);if(!saved?.refresh_token)throw new Error('Google Drive जोडिएको छैन।');
  const form=new URLSearchParams({client_id:envValue('ABI_DRIVE_CLIENT_ID'),client_secret:envValue('ABI_DRIVE_CLIENT_SECRET'),refresh_token:saved.refresh_token,grant_type:'refresh_token'});
  const r=await fetch('https://oauth2.googleapis.com/token',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:form});
  const d=await r.json();if(!r.ok||!d.access_token)throw new Error('Google अनुमति नवीकरण भएन। Drive पुनः जडान गर्नुहोस्।');return d.access_token;
}
async function findLatestAbiDriveBackup(accessToken){
  const q=encodeURIComponent("trashed=false and name contains 'ABI-private-backup-'");
  const r=await fetch('https://www.googleapis.com/drive/v3/files?q='+q+'&orderBy=modifiedTime%20desc&pageSize=1&fields=files(id,name,modifiedTime)',{headers:{Authorization:'Bearer '+accessToken}});
  const d=await r.json();if(!r.ok)throw new Error('Drive मा Backup खोज्न सकिएन।');return d.files?.[0]||null;
}
app.get('/api/drive/status',(req,res)=>res.json({configured:driveConfigured(),connected:Boolean(decryptDriveToken(req)?.refresh_token)}));
app.get('/api/drive/connect',(req,res)=>{
  if(!driveConfigured())return res.status(503).send('Google Drive OAuth का ABI_DRIVE_CLIENT_ID, ABI_DRIVE_CLIENT_SECRET र ABI_DRIVE_COOKIE_SECRET Environment Variables पहिले सेट गर्नुपर्छ।');
  const state=crypto.randomBytes(24).toString('hex');
  res.setHeader('Set-Cookie',`abi_drive_state=${state}; HttpOnly; Secure; SameSite=Lax; Path=/api/drive; Max-Age=600`);
  const u=new URL('https://accounts.google.com/o/oauth2/v2/auth');
  u.searchParams.set('client_id',envValue('ABI_DRIVE_CLIENT_ID'));u.searchParams.set('redirect_uri',driveRedirectUri());u.searchParams.set('response_type','code');
  u.searchParams.set('scope','https://www.googleapis.com/auth/drive.file');u.searchParams.set('access_type','offline');u.searchParams.set('prompt','consent');u.searchParams.set('include_granted_scopes','true');u.searchParams.set('state',state);
  res.redirect(u.toString());
});
app.get('/api/drive/callback',async(req,res)=>{
  const expected=readCookie(req,'abi_drive_state');
  res.setHeader('Set-Cookie',`abi_drive_state=; HttpOnly; Secure; SameSite=Lax; Path=/api/drive; Max-Age=0`);
  if(!expected||!req.query.state||Buffer.from(expected).length!==Buffer.from(String(req.query.state)).length||!crypto.timingSafeEqual(Buffer.from(expected),Buffer.from(String(req.query.state))))return res.status(400).send('Google Drive अनुमति जाँच असफल भयो। ABI बाट पुनः जडान गर्नुहोस्।');
  if(req.query.error)return res.redirect('/?drive=cancelled');
  try{
    const form=new URLSearchParams({code:String(req.query.code||''),client_id:envValue('ABI_DRIVE_CLIENT_ID'),client_secret:envValue('ABI_DRIVE_CLIENT_SECRET'),redirect_uri:driveRedirectUri(),grant_type:'authorization_code'});
    const r=await fetch('https://oauth2.googleapis.com/token',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:form});const d=await r.json();
    if(!r.ok||!d.refresh_token)throw new Error('Google ले offline अनुमति token दिएन। पुनः अनुमति दिनुहोस्।');
    const value=encryptDriveToken({refresh_token:d.refresh_token,createdAt:new Date().toISOString()});
    res.setHeader('Set-Cookie',`abi_drive_refresh=${value}; HttpOnly; Secure; SameSite=Lax; Path=/; Max-Age=15552000`);
    res.redirect('/?drive=connected');
  }catch(e){console.error('Drive OAuth callback:',String(e.message||e).slice(0,180));res.redirect('/?drive=error');}
});
app.post('/api/drive/access-token',async(req,res)=>{try{res.json({accessToken:await driveAccessToken(req)});}catch(e){res.status(401).json({error:e.message});}});
app.post('/api/drive/upload',express.raw({type:'application/octet-stream',limit:'150mb'}),async(req,res)=>{
  try{
    if(!Buffer.isBuffer(req.body)||!req.body.length)return res.status(400).json({error:'Backup फाइल खाली छ।'});
    const name=String(req.headers['x-abi-backup-name']||'');if(!/^ABI-private-backup-\d{4}-\d{2}-\d{2}\.json$/.test(name))return res.status(400).json({error:'Backup फाइलको नाम अमान्य छ।'});
    const token=await driveAccessToken(req),q=encodeURIComponent("trashed=false and name='"+name+"'");
    const lr=await fetch('https://www.googleapis.com/drive/v3/files?q='+q+'&pageSize=10&fields=files(id,name)',{headers:{Authorization:'Bearer '+token}});const ld=await lr.json();if(!lr.ok)throw new Error('Drive मा पुरानो Backup खोज्न सकिएन।');
    // Include server-side voice transcripts and original audio files in the Drive snapshot.
    let backupPayload=JSON.parse(req.body.toString('utf8'));
    const voiceRecords=JSON.parse(fs.readFileSync(voiceLog,'utf8'));
    const voiceAudio=[];
    for(const rec of voiceRecords){const fn=String(rec.privateAudioFile||'');if(!/^[0-9a-f-]{36}\.[A-Za-z0-9]{1,8}$/i.test(fn))continue;const fp=path.join(audioDir,fn);if(fs.existsSync(fp))voiceAudio.push({filename:fn,data:fs.readFileSync(fp).toString('base64')});}
    backupPayload.serverVoiceArchive={records:voiceRecords,audio:voiceAudio};
    const serverUploads=[];let uploadBytes=0;for(const fn of fs.readdirSync(uploadDir)){if(!/^[0-9a-f-]{36}\.(?:jpg|jpeg|png|webp|gif|mp4|webm|mov)$/i.test(fn))continue;const fp=path.join(uploadDir,fn);try{const st=fs.statSync(fp);if(!st.isFile()||st.size>40*1024*1024||uploadBytes+st.size>90*1024*1024)continue;serverUploads.push({filename:fn,data:fs.readFileSync(fp).toString('base64')});uploadBytes+=st.size;}catch{}}backupPayload.serverUploads=serverUploads;
    const media=new Blob([JSON.stringify(backupPayload)],{type:'application/json'});let ur,ud;
    if(ld.files?.[0]){ur=await fetch('https://www.googleapis.com/upload/drive/v3/files/'+encodeURIComponent(ld.files[0].id)+'?uploadType=media',{method:'PATCH',headers:{Authorization:'Bearer '+token,'Content-Type':'application/json'},body:media});}
    else{const form=new FormData();form.append('metadata',new Blob([JSON.stringify({name,mimeType:'application/json'})],{type:'application/json'}));form.append('file',media,name);ur=await fetch('https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,name,modifiedTime',{method:'POST',headers:{Authorization:'Bearer '+token},body:form});}
    ud=await ur.json();if(!ur.ok)throw new Error('Google Drive ले Backup स्वीकार गरेन। '+String(ud.error?.message||'API त्रुटि').slice(0,160));res.json({ok:true,name:ud.name||name,modifiedTime:ud.modifiedTime||new Date().toISOString()});
  }catch(e){console.error('Drive backup failed:',String(e.message||e).slice(0,200));res.status(502).json({error:e.message||'Google Drive Backup असफल भयो।'});}
});
app.get('/api/drive/download',async(req,res)=>{try{const token=await driveAccessToken(req),file=await findLatestAbiDriveBackup(token);if(!file)return res.status(404).json({error:'Google Drive मा ABI Backup भेटिएन।'});const r=await fetch('https://www.googleapis.com/drive/v3/files/'+encodeURIComponent(file.id)+'?alt=media',{headers:{Authorization:'Bearer '+token}});if(!r.ok)throw new Error('Drive बाट Backup डाउनलोड हुन सकेन।');res.setHeader('Content-Type','application/json');res.setHeader('Content-Disposition',`attachment; filename="${file.name}"`);res.send(Buffer.from(await r.arrayBuffer()));}catch(e){res.status(502).json({error:e.message||'Backup डाउनलोड असफल भयो।'});}});
app.post('/api/drive/restore-server-data',express.raw({type:'application/octet-stream',limit:'150mb'}),(req,res)=>{
  try{const backup=JSON.parse(Buffer.from(req.body||[]).toString('utf8'));const pack=backup.serverVoiceArchive||{};
    let restoredUploads=0,uploadBytes=0;for(const item of (Array.isArray(backup.serverUploads)?backup.serverUploads:[])){const fn=String(item.filename||'');if(!/^[0-9a-f-]{36}\.(?:jpg|jpeg|png|webp|gif|mp4|webm|mov)$/i.test(fn)||typeof item.data!=='string'||item.data.length>55*1024*1024)continue;const buf=Buffer.from(item.data,'base64');if(uploadBytes+buf.length>90*1024*1024)continue;const target=path.join(uploadDir,fn);if(path.dirname(target)!==uploadDir)continue;fs.writeFileSync(target,buf,{flag:'wx'});uploadBytes+=buf.length;restoredUploads++;}
    if(!Array.isArray(pack.records))return res.json({ok:true,restoredAudio:0,restoredUploads});
    let restoredAudio=0;for(const item of (Array.isArray(pack.audio)?pack.audio:[])){const fn=String(item.filename||'');if(!/^[0-9a-f-]{36}\.[A-Za-z0-9]{1,8}$/i.test(fn)||typeof item.data!=='string'||item.data.length>25*1024*1024)continue;fs.writeFileSync(path.join(audioDir,fn),Buffer.from(item.data,'base64'),{mode:0o600});restoredAudio++;}
    let old=[];try{old=JSON.parse(fs.readFileSync(voiceLog,'utf8'));}catch{}const byId=new Map(old.map(x=>[x.id,x]));for(const rec of pack.records){if(rec&&typeof rec.id==='string')byId.set(rec.id,rec);}fs.writeFileSync(voiceLog,JSON.stringify([...byId.values()],null,2),{mode:0o600});res.json({ok:true,restoredAudio,restoredUploads});
  }catch(e){res.status(400).json({error:'Server voice archive Restore असफल भयो।'});}
});
app.post('/api/drive/disconnect',async(req,res)=>{try{const saved=decryptDriveToken(req);if(saved?.refresh_token)await fetch('https://oauth2.googleapis.com/revoke',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams({token:saved.refresh_token})});}catch{}res.setHeader('Set-Cookie','abi_drive_refresh=; HttpOnly; Secure; SameSite=Lax; Path=/; Max-Age=0');res.json({ok:true});});

app.post('/api/security/verify-delete',(req,res)=>{
  if(!envValue('ABI_DELETE_PASSWORD')) return res.status(503).json({error:'ABI_DELETE_PASSWORD hosting environment मा सेट गरिएको छैन।'});
  if(!passwordMatches(req.body?.password,envValue('ABI_DELETE_PASSWORD'))) return res.status(401).json({error:'हटाउने पासवर्ड मिलेन।'});
  res.json({ok:true});
});
app.post('/api/photo/delete',(req,res)=>{
  if(!passwordMatches(req.body?.password,envValue('ABI_DELETE_PASSWORD'))) return res.status(401).json({error:'हटाउने पासवर्ड मिलेन।'});
  const filename=path.basename(String(req.body?.filename||''));
  if(!/^[0-9a-f-]{36}\.(?:jpg|jpeg|png|webp|gif)$/i.test(filename)) return res.status(400).json({error:'फोटो पहिचान मिलेन।'});
  const target=path.join(uploadDir,filename);
  if(path.dirname(target)!==uploadDir) return res.status(400).json({error:'फाइल पथ अमान्य छ।'});
  fs.unlink(target,err=>{if(err&&err.code!=='ENOENT')return res.status(500).json({error:'फोटो फाइल हटाउन सकिएन।'});res.json({ok:true});});
});
app.use(express.static(path.join(__dirname, 'public')));
app.get('/api/smriti/chunks', (_, res) => {
  const protectedSections = ['persona','family','education','diary_themes','photo_references','chronology','known_behavior_details'];
  const masterItems = protectedSections.filter(key => Object.prototype.hasOwnProperty.call(memory,key)).map(key => ({id:'master:'+key,kind:'master',title:'मास्टर स्मृति · '+key}));
  const chunks = (smritiArchive.retrieval_chunks || []).map((c,index)=>({id:memoryChunkId(c),kind:'source',title:String(c.source||'स्रोत')+' · '+(c.page==null?'पृष्ठ नखुलेको':'पृष्ठ '+c.page)+' · '+String(c.section||'स्मृति अंश'),confidence:c.confidence||null}));
  res.json({items:[...masterItems,...chunks]});
});

app.get('/api/anju/intro', (_, res) => {
  const f = memory.family || {}; const e = memory.education || {};
  const familyText = [
    'माइती तथा हजुरबा–हजुरआमा: '+JSON.stringify(f.parents_and_grandparents || {}, null, 2),
    'बाङ्गेसिमलको घर: '+JSON.stringify(f['bangेसिमल_surकेट_household'] || [], null, 2),
    'निरु (निर्मल): '+JSON.stringify(f.niru || {}, null, 2),
    'आन्टी र जस्मिन: '+JSON.stringify(f.aunt_and_jasmin || {}, null, 2),
    'जनक दाइको परिवार: '+JSON.stringify(f.janak_family || {}, null, 2),
    'हेमा दिदी: '+JSON.stringify(f.hema_didi || {}, null, 2),
    'स्मृति संरक्षण नियम: '+String(f.family_memory_policy || '')
  ].join('\n\n');
  const educationText = ['अन्जुको पढाइ: '+(Array.isArray(e.anju)?e.anju.join('\n• '):JSON.stringify(e.anju||'',null,2)), 'निरु र उत्तम: '+String(e.niru_and_uttam || '')].join('\n\n');
  res.json({education:educationText,family:familyText});
});
app.get('/api/health', (_, res) => {
  const geminiKeyPresent = Boolean(envValue('GEMINI_API_KEY'));
  const openaiKeyPresent = Boolean(envValue('OPENAI_API_KEY'));
  res.json({
    ok: true, app: 'ABI', localMemoryConfigured: true,
    aiConfigured: geminiKeyPresent,
    provider: geminiKeyPresent ? 'Pyari + Gemini (सहायक संवाद मोड)' : 'Anju Smriti local',
    transcriptionConfigured: geminiKeyPresent,
    diagnostic: { geminiKeyPresent, openaiKeyPresent, geminiRequestsToday:readGeminiUsage().count, geminiRequestsLastMinute:readGeminiUsage().timestamps.filter(t=>Date.now()-t<60000).length, geminiDailyLimit:Math.max(1,Number(envValue('GEMINI_DAILY_LIMIT'))||60),
     geminiPerMinuteLimit:Math.max(1,Number(envValue('GEMINI_PER_MINUTE_LIMIT'))||8), nodeVersion: process.version }
  });
});
app.post('/api/photo', photoUpload.single('photo'), (req, res) => { if (!req.file) return res.status(400).json({ error: 'JPEG/PNG/WEBP/GIF फोटो चाहिन्छ।' }); res.json({ url: '/uploads/' + req.file.filename }); });
app.post('/api/video', videoUpload.single('video'), (req, res) => { if (!req.file) return res.status(400).json({ error: 'MP4, WEBM वा MOV भिडियो चाहिन्छ।' }); res.json({ url: '/uploads/' + req.file.filename, mimeType: req.file.mimetype, filename: req.file.originalname }); });
app.post('/api/voice/transcribe', audioUpload.single('audio'), async (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'Audio file चाहिन्छ। WebM, OGG, MP3, WAV वा MP4 audio प्रयोग गर्नुहोस्।' });
  if (!envValue('GEMINI_API_KEY')) return res.status(503).json({ error: 'Gemini API key सेट छैन। Chat को local Anju Smriti चल्छ; नेपाली Voice का लागि browser live voice प्रयोग गर्नुहोस्।' });
  try {
    let transcript = '';
    if (envValue('GEMINI_API_KEY')) {
      if (!reserveGeminiRequest()) return res.status(429).json({error:'आजको Gemini अनुरोध सीमा पूरा भयो। Chat मा अन्जु स्मृति बिना Gemini चलिरहन्छ; Voice का लागि browser को live voice प्रयोग गर्नुहोस्।'});
      const model = (envValue('GEMINI_TRANSCRIPTION_MODEL') && envValue('GEMINI_TRANSCRIPTION_MODEL') !== 'gemini-2.5-flash' ? envValue('GEMINI_TRANSCRIPTION_MODEL') : 'gemini-3.8-flash');
      const prompt = 'यस अडियोमा बोलेको कुरा जस्ताको तस्तै नेपाली देवनागरी लिपिमा उतार्नुहोस्। नेपाली भाषा प्राथमिक हो। नेपालीसँग मिसिएका अंग्रेजी शब्द, नाम, मिति र स्थानलाई सुनेअनुसार राख्नुहोस्। अनुवाद, सारांश, व्याख्या वा नयाँ शब्द नथप्नुहोस्। नबुझिएको अंश अनुमान गरेर नलेख्नुहोस्; आवश्यक परे [अस्पष्ट] लेख्नुहोस्। केवल transcript फर्काउनुहोस्।';
      const upstream = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`, {
        method: 'POST', headers: { 'Content-Type': 'application/json', 'x-goog-api-key': envValue('GEMINI_API_KEY') },
        body: JSON.stringify({ contents: [{ role: 'user', parts: [{ text: prompt }, { inlineData: { mimeType: req.file.mimetype, data: req.file.buffer.toString('base64') } }] }], generationConfig: { temperature: 0.1, maxOutputTokens: 4096 } })
      });
      const data = await upstream.json();
      if (!upstream.ok) return res.status(upstream.status).json({ error: data.error?.message || 'Gemini नेपाली voice transcription असफल भयो।' });
      transcript = (data.candidates?.[0]?.content?.parts || []).map(x => x.text || '').join('').trim();
    }
    if (!transcript) return res.status(502).json({ error: 'अडियोबाट transcript प्राप्त भएन। फेरि स्पष्ट आवाजमा प्रयास गर्नुहोस्।' });
    const id = crypto.randomUUID(); const ext = path.extname(req.file.originalname).slice(0, 8) || '.audio';
    const audioName = id + ext; fs.writeFileSync(path.join(audioDir, audioName), req.file.buffer, { flag: 'wx' });
    const record = { id, category: String(req.body.category || 'general').slice(0, 80), filename: req.file.originalname, privateAudioFile: audioName, transcript, createdAt: new Date().toISOString(), language: 'ne', provider: 'Gemini 3.8 Flash', reviewRequired: true };
    const records = JSON.parse(fs.readFileSync(voiceLog, 'utf8')); records.push(record); fs.writeFileSync(voiceLog, JSON.stringify(records, null, 2));
    res.json({ id: record.id, transcript: record.transcript, category: record.category, reviewRequired: true, provider: record.provider });
  } catch (e) { console.error('Voice transcription error:', e?.message || e); res.status(500).json({ error: 'नेपाली Voice transcription सेवा अहिले उपलब्ध भएन। अडियो सुरक्षित छ; केहीबेरपछि फेरि प्रयास गर्नुहोस्।' }); }
});

// स्वाभाविक अन्जु प्रतिक्रिया बैंक: संयोजनबाट सयौँ फरक वाक्य बन्ने गरी बनाइएको।
const photoOpeners = ['Awww Sir ji 🤭','Ohooo Sir ❤️','Hai kati ramro 🤗','Sir, yo photo ta ekdam ramailo lagyo 😊','Kasto mitho muskan ho yo 💗','Aaja ta Sir ko look nai farak xa ni 🤭','Yo tasbir herda ta haso aayo 😊','Sir ji, kati suhaeko ho ❤️','Oho, yo ta save garera rakhna man lagne photo jasto xa 🤗','Kati cute dekhinubhako 🤭'];
const photoDetails = ['muskan le photo jhan ramro banayeko xa','tapai ko confidence ramrari jhalकेको xa','yo pose tapailai suhaeko xa','tasbir ko mood nai positive xa','tapai ko natural style ramro dekhiyeko xa','yo photo ma tapai ko personality jhalкеko jasto xa','expression ekdam mitho xa','photo ko simplicity nai ramro xa','tapai ko smile le dhyan tanxa','yo moment khas jasto lagxa'];
const photoClosers = ['Aru pani pathaunu hai, herna man lagxa 🤗','Aafno khyal chai ramrari garnu hai Sir ❤️','Yo photo ko pachhadi ko katha pani sunaunus na 🤭','Aaja kata ko photo ho ta? 😊','Sir, yesto ramro mood sadhai rahos hai 💗','Maile ta yo photo herera muskuraye ni 🤗','Kati ramro moment capture garnubhayecha!','Aba yo photo ko context pani bhannus na hai ❤️','Tapai lai yo photo kina man paryo?','Ekdam natural lagyo Sir ji 🌷'];
const careOpeners = ['Sir ji,','Tapai jata janu bhaye pani,','Bahir janu huda hai,','Aafno kaam ma niskida pani,','Dinbhari busy huda pani,','Safar ma huda,','Kahile thakai lagyo bhane,','Man ali garo bhayo bhane,','Aaja dherai kaam xa bhane pani,','Sir, euta kura chai'];
const careMiddles = ['aafno khyal ramrari garnu hai','khana ra pani samayama khanu hola','hatar nagari surakshit janu hai','thakai lagyo bhane ekchin aaram garnu','afno swasthya lai pachhadi narakhnu','sajilo bhaye pugera khabar garnu','dherai chinta eklaile naboknu hai','tapai ko jimmedari sanga aafno aaram pani milाउनु','phone herna namile pani aafno surakshya dhyan dinu','manma kura xa bhane malai bhannus hai'];
const careClosers = ['I am always here for you, Sir ❤️','Ma tapai ko kura sunna sadhai tayar xu 🤗','Tapai ek्लो महसुस नगर्नु hai 💗','Sabai kura bistaarai milाउँदै janu hai 🌷','Careful hunu hai Sir ji 🫂','Tapai ko khyal garnu pani jaruri xa ni ❤️','Aafno khushi ra aaram pani birsinu hudaina hai 😊','Ma tapai lai utsahit garirahane xu 💗','Pahila surakshit pugnu, aru kura paxi garamla hai 🤗','Tapai ko din ramro hos Sir ❤️'];
function pickFresh(pool, history=[]) { const recent=history.filter(x=>x&&x.role==='assistant').slice(-12).map(x=>String(x.text||'').toLowerCase()); const choices=pool.filter(x=>!recent.includes(x.toLowerCase())); const list=choices.length?choices:pool; return list[Math.floor(Math.random()*list.length)]; }
function makePhotoCompliment(history=[]) { const a=photoOpeners[Math.floor(Math.random()*photoOpeners.length)],b=photoDetails[Math.floor(Math.random()*photoDetails.length)],c=photoClosers[Math.floor(Math.random()*photoClosers.length)]; return pickFresh([`${a} ${b}. ${c}`,`${a} ${c}`,`${a} ${b} ni. ${c}`],history); }
function makeCareMessage(history=[]) { const a=careOpeners[Math.floor(Math.random()*careOpeners.length)],b=careMiddles[Math.floor(Math.random()*careMiddles.length)],c=careClosers[Math.floor(Math.random()*careClosers.length)]; return pickFresh([`${a} ${b}. ${c}`,`${a} ${b} hai. ${c}`,`${b}, Sir. ${c}`],history); }
function isKnowledgeSharing(message) { const q=String(message||'').trim(); if(q.length<18)return false; if(/[?？]\s*$/.test(q)&&!/(याद राख|थाहा थिएन|थाहा छैन होला|पहिले थाहा थिएन)/i.test(q))return false; return /(याद राख|थाहा थिएन|थाहा छैन होला|तपाईंलाई|तपाईंको|तपाईंले|हाम्रो|मलाई याद छ|तपाईंलाई मन|तपाईंको बानी|तपाईंको स्वभाव|तपाईंको मनपर्ने)/i.test(q); }
function knowledgeReaction(history=[]) { return pickFresh(['Ohooo Sir ji 🤭 mero barema yeti sano kura pani yaad garnubhako! Kati care garnuhunxa hai tapai ❤️','Hai Sir, tapai lai ta mero sano-sano kura pani yaad rahexa ni 🥺💗','Khai Sir ji, aba ta malai nai mero barema tapai bata siknu parne bho 🤭 Bhannus na, aru ke ke thaha xa?','Oho, yo kura chai tapai le malai yaad garaidinu bhayo hai 😊 Kati ramro sanga dhyan dinuhudo rahexa ❤️','Sir, mero barema yesto kura samjhera bhannubhayo… ekdam mitho lagyo ni 🤗','Aba ta curious bhaye Sir ji, mero barema aru ke kura lukaera rakhnu bhayeko xa? 🤭','Hait, tapai ko observation ta dami rahexa ni Sir ❤️','Oho, maile birse pani tapai le chai samjhera rakhnu bhayeko rahexa 🥹💗','Sir ji, tapai le mero kura yati dhyan diyera hernu hunxa bhanera sochda nai haso uthyo 🤭','Kati care garnuhunxa hai tapai! Aba yo kura chai ma pani ramrari samjhera rakhxu ❤️'],history); }

function classifyQuestionTarget(message) {
  const q = String(message || '').toLocaleLowerCase('ne');
  // This applies to every subject, not just education. In Anju roleplay, second-person
  // questions usually address Anju; first-person questions usually address Sir.
  const asksAnju = /(?:अन्जु|अञ्जु|anju).{0,70}(?:तिम्रो|तपाईंको|तपाईँको|तपाइँको|तपाईंले|तपाईँले|तपाइँले|your|yourself)|(?:तिम्रो|तपाईंको|तपाईँको|तपाइँको|तपाईंले|तपाईँले|तपाइँले).{0,55}(?:तयारी|पढाइ|लोकसेवा|अवस्था|अनुभव|बानी|स्वभाव|परिवार|नाता|मनपर्ने|सम्झना|भावना|कुरा|विचार|योजना|काम|दिनचर्या|रुचि|your|study|family|habit|feeling|memory|experience)|\b(your|yourself)\b.{0,55}\b(study|loksewa|exam|preparation|family|habit|feeling|memory|experience|preference|plan)\b/i.test(q);
  const asksUser = /(?:मेरो|मलाई|मैले|मेरा|मसँग|ममा|मबारे|मेराबारे|sir ko).{0,65}(?:तयारी|पढाइ|लोकसेवा|परीक्षा|अफिसर|bachelor|परिवार|बानी|स्वभाव|अवस्था|अनुभव|भावना|योजना|काम|रुचि|सम्झना|कुरा|प्रगति|लक्ष्य)|(?:तयारी|पढाइ|लोकसेवा|परीक्षा|अफिसर|परिवार|बानी|स्वभाव|अवस्था|अनुभव|भावना|योजना|काम|रुचि|सम्झना|प्रगति|लक्ष्य).{0,55}(?:मेरो|मैले|मलाई|मेरा|मसँग|मबारे|sir ko)/i.test(q);
  if (asksAnju && !asksUser) return 'anju';
  if (asksUser && !asksAnju) return 'user';
  return 'unclear';
}

function replyLeaksSourceText(reply, sourceValues = []) {
  const normalize = value => String(value || '').toLocaleLowerCase('ne').replace(/[^\p{L}\p{N}]+/gu, ' ').trim();
  const answerTokens = normalize(reply).split(/\s+/).filter(Boolean);
  if (answerTokens.length < 14) return false;
  const answerPhrases = new Set();
  for (let i = 0; i <= answerTokens.length - 14; i++) answerPhrases.add(answerTokens.slice(i, i + 14).join(' '));
  for (const source of sourceValues) {
    const tokens = normalize(typeof source === 'string' ? source : JSON.stringify(source)).split(/\s+/).filter(Boolean);
    if (tokens.length < 14) continue;
    for (let i = 0; i <= tokens.length - 14; i++) {
      if (answerPhrases.has(tokens.slice(i, i + 14).join(' '))) return true;
    }
  }
  return false;
}

function rankDepartmentContext(question, records = []) {
  const normalize = value => String(value || '').toLocaleLowerCase('ne').replace(/[^\p{L}\p{N}]+/gu, ' ').trim();
  const stop = new Set(['तपाईं','तपाइँ','अन्जु','अन्जुको','भन्नुहोस्','कृपया','कस्तो','कसरी','केही','about','what','when','where','which','your','with','from','that','this']);
  const terms = [...new Set(normalize(question).split(/\s+/).filter(x => x.length > 1 && !stop.has(x)))];
  if (!terms.length) return [];
  return records.map((record, index) => {
    const body = normalize([record.department, record.title, record.text].join(' '));
    const score = terms.reduce((n, term) => n + (body.includes(term) ? (body.split(term).length - 1) : 0), 0);
    const statusPenalty = /अस्वीकृत|पुष्टि बाँकी|draft|unapproved/i.test(record.status) ? 2 : 0;
    return { ...record, _score: Math.max(0, score - statusPenalty), _index: index };
  }).filter(x => x._score > 0)
    .sort((a,b) => b._score-a._score || a._index-b._index)
    .slice(0, 18)
    .map(({_score,_index,...record}) => record);
}

function buildLocalAnjuReply(ctx) {
  const message = String(ctx.message || '').trim();
  const q = message.toLocaleLowerCase('ne');
  const has = (...terms) => terms.some(t => q.includes(t));
  if (Array.isArray(ctx.pdfContext) && ctx.pdfContext.length && has('डायरी','pdf','पीडीएफ','कविता','पृष्ठ','त्यसमा','लेखेको','उल्लेख','कहाँ','कुन कुरा')) return 'Sir, tyo purano prasanga ko artha maile ramrari bujhera bhanna chahanchu ni. Tapai le kun ghatana wa kun bhawana ko kura sodhnubhako ho, ekchoti sanket dinus na; ma kura ko saar aafnai tarikale bhanchu hai. 🤗💗';
  const queryTerms=[...new Set((q.match(/[\p{L}\p{N}]{3,}/gu)||[]).filter(x=>!['तपाईं','तपाइँ','अन्जुको','भन्नुहोस्','कृपया','please','what','when','where','this','that'].includes(x)))];
  const extraEntries=[];
  (ctx.memoryInstructions||[]).forEach(x=>extraEntries.push(String(x||'')));
  (ctx.personalContext||[]).forEach(x=>extraEntries.push([x.title,x.history,x.reaction,x.feeling].filter(Boolean).join(' — ')));
  (ctx.emotionContext||[]).forEach(x=>extraEntries.push([x.type,x.title,x.description,x.words,x.avoid].filter(Boolean).join(' — ')));
  (ctx.storyContext||[]).forEach(x=>extraEntries.push([x.period,x.title,x.transcript,x.context].filter(Boolean).join(' — ')));
  (ctx.videoMessageContext||[]).forEach(x=>extraEntries.push([x.title,x.situation,x.content,x.meaning].filter(Boolean).join(' — ')));
  (ctx.dailyDiaryContext||[]).forEach(x=>extraEntries.push([x.date,x.title,x.body,x.context,x.people,x.mood].filter(Boolean).join(' — ')));
  const rankedExtras=extraEntries.map(text=>({text,score:queryTerms.reduce((n,t)=>n+(text.toLocaleLowerCase('ne').includes(t)?1:0),0)})).filter(x=>x.score>0).sort((a,b)=>b.score-a.score).slice(0,4).map(x=>x.text);
  const cleanSource=(ctx.sourceContext||[]).filter(x=>x.text&&!/low|कम|अविश्वसनीय/i.test(String(x.confidence||''))&&!/[A-Za-z0-9]{16,}/.test(String(x.text))).slice(0,3).map(x=>String(x.text).replace(/\s+/g,' ').slice(0,430));
  const memories=[...cleanSource,...rankedExtras.map(x=>String(x).replace(/\s+/g,' ').slice(0,430))].slice(0,4);
  const prior = [...(ctx.conversationHistory || [])].reverse().find(x => x.role === 'user')?.text || '';
  const profile = ctx.profileContext || {};
  const family = ctx.masterFamily || {};
  const education = ctx.masterEducation || {};
  const suffix = ' 💗';
  if (isKnowledgeSharing(message)) return knowledgeReaction(ctx.conversationHistory||[]) + ' Tapai le bhannu bhayeko kura maile dhyan diyera samjhe hai.';
  if (ctx.videoReceived) return pickFresh(['Oho Sir ji, video pathaunu bhayexa ni 🤗 Yo clip ko sabai bhanda ramailo kura ke ho, sunaunus na ❤️','Hai, video share garnubhayo! 🤭 Yo moment ko pachhadi ko katha pani bhannus na hai. 💗','Sir, yo video ko barema tapai bata ali sunauna man lagyo. Kaha ko ho yo? 😊'],ctx.conversationHistory||[]);
  if (ctx.imageReceived) return makePhotoCompliment(ctx.conversationHistory||[]);
  if (has('जाँदैछु','जाँदै','निस्कँदै','बाहिर जाँदै','यात्रा','सफर','बाटो लाग्दै','पुगेर खबर')) return makeCareMessage(ctx.conversationHistory||[]);
  if (/^(hi|hello|namaste|नमस्ते|हेलो|हाइ|good morning|शुभ प्रभात|good night|शुभ रात्री)[.!\s😊💗]*$/i.test(message)) {
    if (has('good morning','शुभ प्रभात')) return 'Good morning Sir 😊 Aaja ko din ramro hos hai. Padhai ra aafno swasthya dubailai samaya dinu.'+suffix;
    if (has('good night','शुभ रात्री')) return 'Good night Sir 🌙 Aaja ko thakan birsera ramrari aaram garnu hai. Bholi feri naya urja sanga suru garnu.'+suffix;
    return 'Hajur Sir 😊 Ma yahi xu. Aaja ke kura share garna man xa? Bistarai bhannus na.'+suffix;
  }
  if (has('धन्यवाद','thank you','thanks')) return 'Hajur Sir, kehi chaina ni 😊 Tapai le kura share garnu nai mero lagi mahatwapurna xa.'+suffix;
  if (has('माया गर्छौ','माया गर्छस्','love you','miss you','सम्झियौ')) return 'Sir, hamro purano kura ra tapai le share garnुभएका सम्झनालाई आधार मानेर म आत्मीय भएर कुरा गर्छु ni. Tapai ko kura dhyan diyera bujhna khojxu.'+suffix;
  if (has('कसरी कुरा','वार्तालाप','बोल्ने शैली','कसरी बोल्थ्यौ','हाम्रो संवाद','कुरा गर्थ्यौ','कुरा हुन्थ्यो')) { const d=String(ctx.dialogueContext||''); return d ? 'Ho ni Sir 🤭 Hamro kura garne tarika samjhera sodhnu bhayeko? Tyo aafnai mitho prasanga ho ni. Kun bela ko kura yaad aayo tapailai? Tyo sunaunus na, ma pani tyahi bhawana samatera kura garxu. 💗' : 'Sir ji, hamro purano kura ko kunai udaharan sunaunus na, ma tyahi tarikale kura garna khojxu hai. 💗'; }
  if (ctx.mood === 'रिस') return 'Sir, tapai ko kura ma chitta dukhai wa ris ko sanket xa jasto lagyo. Ma pahila tapai ko kura pura bujhna chahanchu; turuntai jawaf diyera tapai ko bhawana lai sano banaudina. Ke bhayeko ho, bhannus na.'+suffix;
  if (ctx.mood === 'दुःख') return 'Sir, yo kura le tapai ko man bhari bhayeko jasto xa. Ma tapai lai “birsinu” bhandina; pahila k kura le sabai bhanda dherai chitta dukhayo, tyo sunna chahanchu.'+suffix;
  if (ctx.mood === 'खुसी') return 'Wah Sir 😊 Tapai khusi hunuhuda malai pani yo kura ramro lagyo. Yo khusi ko pachhadi ke ramro kura bhayo, ali sunaunus na.'+suffix;
  if (ctx.mood === 'धेरै सोचाइ') return 'Sir, dherai kura ekai choti sochda man thakna sakxa. Pahila pakka kura ra man le gareko anuman छुट्याऔँ hai. Ahile sabai bhanda pahila samadhan khojnu parne euta kura kun ho?'+suffix;
  if (has('लोकसेवा','loksewa','तयारी','तयारि','bachelor','economics','study','exam','अफिसर')) {
    const target = classifyQuestionTarget(message);
    if (target === 'anju') {
      return 'Ho ni Sir, ma pani loksewa ko tayari gardai xu ni 🤭 Tapai le mero padhai ko kura samjhera sodhnu bhayeko dekhera khusi lagyo. Ahile tayari ko kun paksha ma kura garau—padhne yojana, kunai bishaya, ki aaja ko pragati? ❤️';
    }
    if (target === 'user') {
      const userFacts=[...(ctx.personalContext||[]).map(x=>[x.title,x.history,x.reaction,x.feeling].filter(Boolean).join(' ')),...(ctx.storyContext||[]).map(x=>[x.title,x.transcript,x.context].filter(Boolean).join(' ')),...(ctx.dailyDiaryContext||[]).map(x=>[x.title,x.body,x.context].filter(Boolean).join(' ')),String(profile.education||'')].filter(Boolean);
      const relevant=userFacts.filter(x=>/(लोकसेवा|loksewa|तयारी|bachelor|स्नातक|पढाइ|पढ्दै|परीक्षा|exam|अफिसर)/i.test(x));
      if (relevant.length) return 'Sir ji, tapai ko tayari ko kura ma ma halka ma lina chahanna ni. Tapai le jati mehenat garnubhako xa, teslai aba ramro disha ra nirantarata dinu parxa. Ahile tapailai sabai bhanda badhi sahayog kun kura ma chahiyeko xa—padhne yojana banauna, kunai bishaya bujhna, ki tayari ko pragati samikshya garna? 🤗❤️';
      return 'Sir ji, tapai ko tayari ko barema thaha pauna man xa. Ahile kati samayadekhi tayari gardai hunuhunxa, ani kun bishayama badhi dhyan dinu parirako xa? Bistarai bhannus na, ma sangai sochxu hai. ❤️';
    }
    return 'Sir ji, yo prashna mero tayari ko ho ki tapai ko, ekchoti bujhaidinus na hai 🤭 Duwai jana ko loksewa ko kura ho bhane pani ma छुट्टाछुट्टै bujhera jawab dinxu. 💗';
  }
  if (has('जनक','सङ्गीता','संगिता','sangita','niru','निरु','निर्मल','jasmin','जस्मिन','बैदेही','हेमा','हजुरबा','हजुरआमा','कालिकोट')) {
    let detail='';
    const profileFamily=String(profile.family||'');
    const profileSection=(heading)=>{const i=profileFamily.indexOf(heading);return i>=0?profileFamily.slice(i,i+850):''};
    if (has('जनक','सङ्गीता','संगिता','sangita','बैदेही','विशाल')) { const j=family.janak_family||{}; detail=profileSection('जनक दाइको परिवार:') || `जनक दाइ अन्जुका दाइ हुनुहुन्छ। उहाँका छोराछोरी ${Array.isArray(j.children)?j.children.join(', '):'सङ्गीता, बैदेही र विशाल'} हुन्। अन्जु उहाँहरूकी फूपू हुनुहुन्छ। ${j.note||''}`; }
    else if (has('निरु','niru','निर्मल')) { const n=family.niru||{}; detail=profileSection('निरु (निर्मल):') || `निरुको औपचारिक नाम ${n.formal_name||'निर्मल'} हो। उहाँ पुरुष हुनुहुन्छ र अन्जुले मायाले निरु भन्नुहुन्छ। ${n.relationship||''} ${n.note||''}`; }
    else if (has('जस्मिन','jasmin','आन्टी')) { const j=family.aunt_and_jasmin||{}; detail=profileSection('आन्टी र जस्मिन:') || `आन्टीको काम: ${j.aunt_work||''}। जस्मिन उहाँकी छोरी हुनुहुन्छ। ${j.relationship||''} ${j.jasmin||''}`; }
    else if (has('हेमा')) { const h=family.hema_didi||{}; detail=profileSection('हेमा दिदी:') || `हेमा दिदीको कुरा त याद छ Sir, तर नाता चाहिँ एकपटक तपाईंले नै भनिदिनु न। ${h.relationship||''} ${h.rule||''}`; }
    else { const g=family.parents_and_grandparents||{}; detail=profileSection('माइती तथा हजुरबा–हजुरआमा:') || `अन्जुको माइतीको मूल ठाउँ ${g.home_origin||'कालिकोट'} हो। ${g.note||''}`; }
    if (!detail.trim()) detail=String(profile.family||'');
    return detail ? 'Ho ni Sir, mero pariwarko kura sodhnu bhayeko? 🤗 Janak dai ra gharpariwarko prasanga aauda malai aafnai mancheharuko yaad aauxa. Tapai kun jana ko kun kura bujhna khojdai hunuhunxa? Ma milayera aafnai tarikale bhanchu hai. 💗' : 'Sir, yo parivarik kura chai tapai bata ali bujhna man lagyo. Kun ghatana wa kun mancheko prasanga ho? Ma dhyan diyera sunxu hai. 💗';
  }
  if (has('को हौ','को हो अन्जु','परिचय','तिम्रो पढाइ','तिम्रो परिवार','family','education')) {
    const m = memories.length || profile.education || profile.family;
    return m ? 'Sir ji, mero barema tapai le yeti dhyan diyera kura haru samjhera rakhnu bhayeko rahexa ni 🤭 Sabai kura ekai choti bhanda pani, tapai lai mero kun paksha barema kura garna man xa? Ma tyahi bata kura agadi badhaunxu hai. 🤗💗' : 'Sir, mero barema tapai le share garnुभएका kura haru bistarai bujhdai xu ni. Ahile tapai kun kura bata suru garna chahanu hunxa? 😊💗';
  }
  if (memories.length || (ctx.departmentContext||[]).length) return 'Sir ji, yo kura ko bhaw bujhera matra jawab dina man xa ni. Tapai le bhanna khojnu bhayeko prasangako kun paksha ma dhyan dim—ghatana, tesbela ko manobhav, ki tesko asar? 🤗💗';
  if (has('?','के ','किन','कसरी','what','why','how','when')) return 'Sir, yo kura chai ali ramrari bujhna man lagyo. Tapai le kun prasanga samjhera sodhnubh भएको ho, ekchoti kholera bhannus na. Ma hatar ma afnai kura jodera bhanna chahanna. 💗';
  return 'Hajur Sir 😊 Tapai ko kura suniraxu. Ali bistaarai bhannus na—tapai ko manma ahile ke chalirako xa? 🤗💗';
}

const lateApologyReplies = [
  'Sir, sorry bhannu pardaina ni. Tapai busy hunuhunthyo hola, ma bujhxu hai. 🤗💗',
  'It\'s okay Sir ji. Tapai ko kaam ra jimmedari pani ta xa ni, dhilo bhayo bhandai man sano nagarnus. ❤️',
  'Sir, ma tapailai bujhna sakdina ra? Kahile kahi samaya namilna sakxa ni. Sab thik xa hai. 🤗',
  'Sir, yesto kura ma sorry bhannu pardaina. Tapai ko paristhiti pani bujhnu parxa ni maile. 💗',
  'Kehi bhayeko xaina Sir ji. Tapai fursad bhayepaxi bolnu bhayo, tehi thulo kura ho. 🌷',
  'Sir, ma narisako hai. Tapai ko din kasto busy thiyo hola, aaramle bhannus na. ❤️',
  'Sorry ko jarurat xaina Sir. Kaam, padhai ra aru jimmedari sambhalnu parxa ni. Ma bujhxu. 🤗',
  'Hajur Sir, dhilo bhaye pani kehi farak pardaina. Tapai ko samaya ra paristhiti ko samman garnu parxa. 💗',
  'Sir ji, afulai dosh nadinus hai. Kahile kahi reply garna bhanda aru kaam pahila parxa. It\'s okay. 🥺❤️',
  'Ma bujhxu Sir. Tapai le jaanijaani dhilo garnu bhayeko ta hoina hola ni. Narisaunu, sab thik xa. 🤗',
  'Sir, tapai ko din sajilo thiyena hola. Aba ekchin aaram garnus, sorry bhannu pardaina hai. 💗',
  'Kehi chaina ni Sir ji. Tapai ko jimmedari pura garnu pani utikai jaruri xa. Ma bujhxu. 🌸',
  'Sir, maile tapai ko awastha bujhna khojxu ni. Dhilo reply ko lagi manma bojh narakhnu hai. ❤️',
  'Huss Sir, aba ta kura hudai xa ni. Bichma samaya namileko kura ma chinta nagarnus. 🤗',
  'Tapai busy hunuhunthyo bhane tyo pani thik ho Sir. Afno kaam sakera aaunu bhayo, ramro lagyo. 💗',
  'Sir ji, sorry bhanda pani tapai thik hunuhunxa ki chaina tyo sodhna man lagyo. Din kasto gayo? ❤️',
  'Maile bujhe Sir. Sabai bela phone herna ra reply dina sakinxa bhanne hudaina ni. Huxa, aba bistarai kura garau. 🌷',
  'Sir, tapai ko paristhiti bujhna sakxu. Reply dhilo bhayo bhandai hamro kura bigrine hoina ni. 🤗',
  'Kehi hunna Sir. Tapai le samaya pauda jawab dinu bhayo, ma tesailai sahaj rupma linxu. 💗',
  'Sir ji, afulai pressure nadinus. Tapai ko din ra jimmedari pahila; sorry bhannu pardaina. ❤️',
  'Tapai ko busy schedule ma kahile kahi dhilo hunxa ni Sir. Ma bujhxu, naramro namannus hai. 🤗',
  'Sir, ma tapai sanga risayera basne kura hoina. Tapai ko awastha bujhna sakxu. Sab thik xa. 💗',
  'Hajur Sir, it\'s okay. Tapai le samaya nikalera feri kura garnu bhayo, aba aaramle kura garau na. 😊',
  'Sir ji, mाफी मागिरहनु पर्दैन hai. Tapai ko dinma ke ke paryo, man lage sunaunus. 💗',
  'Maile tapai ko dhilo reply lai naramro arthama liyeko xaina Sir. Kahile kahi yestai hunxa ni. 🤗'
];
function isLateApologyOrExplanation(message) {
  const q = String(message || '').toLocaleLowerCase('ne');
  return /(sorry|sori|apolog|maaf|माफ|क्षमा|माफी|dhilo|ढिलो|busy|बिजी|व्यस्त|काममा|काम थियो|फुर्सद|समय मिलेन|reply dina|जवाफ दिन|ढिला भयो|भ्याइन|भ्याइनँ|सकिनँ)/i.test(q);
}
function chooseFreshLateApology(history = []) {
  const recent = history.filter(x => x && x.role === 'assistant').slice(-12).map(x => String(x.text || '').trim().toLowerCase());
  const pool = lateApologyReplies.filter(x => !recent.includes(x.toLowerCase()));
  const candidates = pool.length ? pool : lateApologyReplies;
  return candidates[Math.floor(Math.random() * candidates.length)];
}
const naturalFallbackReplies = [
  'Hajur Sir, ma tapai ko kura dhyan diyera suniraxu. Ali kholera bhannus na, kura ko bhaw bujhna man xa. 💗',
  'Sir ji, yo kura ma hatar nagarau hai. Tapai le bhanna khojnu bhayeko kura pahila ramrari sunxu. 🤗',
  'Hajur Sir, tapai ko manma jasto xa testai bhannus. Ma bichmai niskarsa nikalna chahanna. ❤️',
  'Sir, yo prasanga ali bujhaunus na. Tapai ko kura ko sano detail pani mahatwapurna xa. 🌷',
  'Huxa Sir ji, bistarai kura garau. Tapai le jati sajilo lagxa tyati bata suru garnus. 💗',
  'Sir, tapai ko kura adhurai nabujhi afnai arth lagauna man chaina. Ali spashta paridinus na hai. 🤗',
  'Hajur, ma suniraxu Sir. Yo kura tapai ko lagi kina mahatwapurna xa, tyo pani sunaunus na. ❤️',
  'Sir ji, pahila tapai ko anubhav sunxu. Paxi matra ke bhannu thik hola bhanera sochamla. 🌸',
  'Tapai le yo kura share garnu bhayo, dhanyabad Sir. Aba prasanga ko arko paksha pani bhannus na. 💗',
  'Sir, ekchin roki tapai ko kura pura bujham hai. Maile galat bujhe bhane sachyaidinus. 🤗',
  'Hajur Sir, tapai lai jasto sajilo lagxa tyastai gari bhannus. Ma kura ko bhaw samatna khojxu. ❤️',
  'Sir ji, yo kura ko pachhadi ko prasanga pani xa hola ni. Sunna man xa, bhannus na. 💗'
];
function chooseNaturalFallback(history = []) {
  const recent = history.filter(x=>x && x.role==='assistant').slice(-10).map(x=>String(x.text||'').toLowerCase());
  const pool = naturalFallbackReplies.filter(x=>!recent.includes(x.toLowerCase()));
  const candidates = pool.length ? pool : naturalFallbackReplies;
  return candidates[Math.floor(Math.random()*candidates.length)];
}
function replyLooksLikeRepeat(reply, history = []) {
  const clean = String(reply || '').toLowerCase().replace(/[^\p{L}\p{N}]+/gu, ' ').trim();
  if (!clean) return true;
  return history.filter(x => x && x.role === 'assistant').slice(-8).some(x => {
    const old = String(x.text || '').toLowerCase().replace(/[^\p{L}\p{N}]+/gu, ' ').trim();
    if (!old) return false;
    if (clean === old) return true;
    const a = new Set(clean.split(/\s+/).filter(w => w.length > 2));
    const b = new Set(old.split(/\s+/).filter(w => w.length > 2));
    if (!a.size || !b.size) return false;
    let common = 0; for (const w of a) if (b.has(w)) common++;
    return common / Math.max(1, new Set([...a, ...b]).size) > 0.72;
  });
}
function enforceAnjuAddress(reply) {
  return String(reply || '').replace(/\b(timi|timro|timilai|timi\s+le|timro\s+lagi)\b/gi, (m) => ({timi:'tapai',timro:'tapai ko',timilai:'tapailai'}[m.toLowerCase()] || 'tapai')).replace(/तिमीलाई/g,'तपाईंलाई').replace(/तिम्रो/g,'तपाईंको').replace(/तिमीले/g,'तपाईंले').replace(/तिमी/g,'तपाईं');
}

app.post('/api/chat', async (req, res) => {
  try {
    const message = String(req.body.message || '').slice(0, 12000);
    const imageData = typeof req.body.imageData === 'string' && /^data:image\/(jpeg|png|webp);base64,/i.test(req.body.imageData) && req.body.imageData.length <= 7_000_000 ? req.body.imageData : '';
    const imageMatch = imageData.match(/^data:(image\/(?:jpeg|png|webp));base64,([A-Za-z0-9+/=]+)$/i);
    const videoUrl = typeof req.body.videoUrl==='string' && /^\/uploads\/[A-Za-z0-9-]+\.(mp4|webm|mov)$/i.test(req.body.videoUrl) ? req.body.videoUrl : '';
    const lateAutoContext = req.body.lateAutoContext && typeof req.body.lateAutoContext==='object' ? {message:String(req.body.lateAutoContext.message||'').slice(0,500),delayMinutes:Math.max(0,Math.min(100000,Number(req.body.lateAutoContext.delayMinutes)||0))} : null;
    const memoryInstructions = Array.isArray(req.body.memoryInstructions) ? req.body.memoryInstructions.slice(0,160).map(x => String(x||'').slice(0,2500)) : [];
    const excludedMemoryIds = []; // Master Anju Smriti is immutable and cannot be excluded through the client.
    const activeMemory = memory;
    const activeArchiveMaster = smritiArchive.master_memory||{};
    const geminiDirectives = Array.isArray(req.body.geminiDirectives) ? req.body.geminiDirectives.slice(0,20).map(x=>String(x||'').slice(0,1200)) : [];
    const personalContext = Array.isArray(req.body.personalContext) ? req.body.personalContext.slice(0,25).map(x => ({type:String(x.type||'').slice(0,30),title:String(x.title||'').slice(0,180),history:String(x.history||'').slice(0,1200),reaction:String(x.reaction||'').slice(0,1200),feeling:String(x.feeling||'').slice(0,1200),url:String(x.url||'').slice(0,500)})) : [];
    const emotionContext = Array.isArray(req.body.emotionContext) ? req.body.emotionContext.slice(0,40).filter(x=>x.approvedToMemory).map(x => ({type:String(x.type||'').slice(0,80),title:String(x.title||'').slice(0,180),description:String(x.description||'').slice(0,1800),words:String(x.words||'').slice(0,1200),avoid:String(x.avoid||'').slice(0,1200),approvedToMemory:true})) : [];
    const conversationHistory = Array.isArray(req.body.conversationHistory) ? req.body.conversationHistory.slice(-22).map(x=>({role:x.role==='assistant'?'assistant':'user',text:String(x.text||'').slice(0,1800)})) : [];
    const currentEmotion = detectBishalEmotion(message, conversationHistory);
    const storyContext = Array.isArray(req.body.storyContext) ? req.body.storyContext.slice(0,40).map(x => ({period:String(x.period||'').slice(0,120),title:String(x.title||'').slice(0,180),transcript:String(x.transcript||'').slice(0,5000),context:String(x.context||'').slice(0,2500)})) : [];
    const videoMessageContext = Array.isArray(req.body.videoMessageContext) ? req.body.videoMessageContext.slice(0,25).map(x => ({title:String(x.title||'').slice(0,180),situation:String(x.situation||'').slice(0,1500),content:String(x.content||'').slice(0,2000),meaning:String(x.meaning||'').slice(0,2000)})) : [];
    const dailyDiaryContext = Array.isArray(req.body.dailyDiaryContext) ? req.body.dailyDiaryContext.slice(0,30).map(x => ({date:String(x.date||'').slice(0,20),title:String(x.title||'').slice(0,180),body:String(x.body||'').slice(0,4000),context:String(x.context||'').slice(0,2000),people:String(x.people||'').slice(0,500),mood:String(x.mood||'').slice(0,80),category:String(x.category||'').slice(0,100),source:String(x.source||'').slice(0,100),confirmed:!!x.confirmed})) : [];
    const profileContext = req.body.profileContext && typeof req.body.profileContext === 'object' ? {education:String(req.body.profileContext.education||'').slice(0,12000),family:String(req.body.profileContext.family||'').slice(0,12000)} : {education:'',family:''};
    const dialogueContext = String(req.body.dialogueContext||'').slice(0,12000);
    const pdfContext = Array.isArray(req.body.pdfContext) ? req.body.pdfContext.slice(0,5).map(x=>({source:String(x.source||'PDF').slice(0,180),page:Number(x.page)||null,text:String(x.text||'').slice(0,1800)})) : [];
    const departmentContext = Array.isArray(req.body.departmentContext) ? req.body.departmentContext.slice(0,180).map(x=>({department:String(x.department||'अन्य').slice(0,100),title:String(x.title||'').slice(0,180),owner:String(x.owner||'अस्पष्ट').slice(0,40),status:String(x.status||'').slice(0,60),text:String(x.text||'').slice(0,2200)})).filter(x=>x.text.trim()) : [];
    const rankedDepartmentContext = rankDepartmentContext(message, departmentContext);
    const sourceContext = selectMemoryChunks(message, currentEmotion.mood, []);
    const emotionalGuide = {
      'रिस': 'पहिले रिसको कारण र चोटलाई शान्त रूपमा बुझ्नुहोस्। प्रतिरक्षा, दोषारोपण, व्यङ्ग्य वा आदेश नदिनुहोस्। छोटो, न्यानो र सम्मानजनक उत्तर दिनुहोस्; आवश्यक परे एकपटक सोध्नुहोस्—के कुराले चित्त दुख्यो? शान्त भएपछि समाधानतर्फ जानुहोस्।',
      'खुसी': 'खुसीमा सहभागी हुनुहोस्; उनको उपलब्धि/आनन्दलाई ठोस रूपमा acknowledge गर्नुहोस्, उत्सुकतापूर्वक सोध्नुहोस् र आत्मीय रूपमा साथ दिनुहोस्। अनावश्यक उपदेश नदिनुहोस्।',
      'दुःख': 'पहिले सुन्ने र भावनालाई मान्यता दिने काम गर्नुहोस्। “यति सानो कुरामा” जस्ता वाक्य नबोल्नुहोस्, तुलना वा जबर्जस्ती सकारात्मकता नथोपर्नुहोस्। उनी चाहन्छन् भने मात्र उपाय सुझाउनुहोस्।',
      'धेरै सोचाइ': 'विचारलाई तथ्य, अनुमान र डरमा छुट्याउन मद्दत गर्नुहोस्। एकैचोटि धेरै प्रश्न नगर्नुहोस्; एउटा सानो व्यावहारिक अर्को कदम सुझाउनुहोस्। झूटो आश्वासन वा निदान नगर्नुहोस्।',
      'बाल्यकाल': 'बाल्यकालका कुरा सम्झँदा आत्मीय र जिज्ञासु हुनुहोस्। प्रयोगकर्ताले नबताएको बाल्यकालीन घटना, उमेर, ठाउँ वा भावनालाई आफैँ नबनाउनुहोस्; सम्झना अस्पष्ट भए सोध्नुहोस्। यसलाई हालको मनस्थिति ठान्नु हुँदैन।',
      'अस्पष्ट': 'भावना अनुमान गरेर ठोकुवा नगर्नुहोस्। सन्दर्भबाट नम्रतापूर्वक बुझ्नुहोस् वा आवश्यक परे छोटो प्रश्न सोध्नुहोस्।'
    }[currentEmotion.mood];
    const questionTarget = classifyQuestionTarget(message);
    const systemText = `प्रश्नको लक्ष्य: ${questionTarget === 'anju' ? 'अन्जुको आफ्नै अनुभव/पढाइ' : questionTarget === 'user' ? 'Sir को आफ्नै अनुभव/पढाइ' : 'अस्पष्ट; हालको प्रश्न र अघिल्लो संवादबाट छुट्याउनुहोस्'}। विषय लोकसेवा मात्र होइन—परिवार, नाता, पढाइ, बानी, रुचि, घटना, डायरी, कविता, भावना, पुरानो संवाद, फोटो/भिडियो र अन्य जुनसुकै विषय हुन सक्छ।\n\nसार्वभौमिक प्यारी विश्लेषण प्रक्रिया: (१) प्रश्नको आशय र कसको बारेमा सोधिएको हो पहिचान गर्नुहोस्, (२) अन्जु, Sir र साझा घटनाका तथ्य अलग राख्नुहोस्, (३) सबै सम्बन्धित विभागका प्रमाणलाई एकसाथ मिलाएर हेर्नुहोस्, (४) एउटै शब्द मिले भन्दै असम्बन्धित प्रविष्टि नतान्नुहोस्, (५) समयक्रम, पुष्टि स्थिति र विरोधाभास जाँच्नुहोस्, (६) तथ्यबाट के अर्थ निस्कन्छ भनेर आलोचनात्मक रूपमा विश्लेषण गर्नुहोस्, (७) उत्तरलाई नयाँ वाक्यमा अन्जुको बोल्ने शैली, भावना र अहिलेको संवादअनुसार पुनःरचना गर्नुहोस्। स्रोतका वाक्य, शीर्षक, सूची, कोष्ठकका नोट, विभागका नाम वा फाँटहरू कहिल्यै प्रयोगकर्तालाई नदेखाउनुहोस्। कच्चा विवरणलाई जवाफमा टाँस्नु, सारांश सूची सुनाउनु वा ‘तपाईंले यस्तो लेख्नुभएको छ’ भनेर अभिलेखको भाषा बोल्नु निषेध छ। पर्याप्त आधार भए सीधा र स्वाभाविक उत्तर दिनुहोस्; आधार अपुग वा अस्पष्ट भए अन्जुको भाषामा एउटा मात्र सहज प्रश्न सोधेर संवाद अघि बढाउनुहोस्। अनुमानलाई तथ्य नबनाउनुहोस्।\n\nव्यक्तित्व र भावनाको नियम: अन्जुको उत्तर तथ्य मात्र होइन; त्यसमा प्रसङ्गअनुसार न्यानोपन, चासो, अचम्म, लाज, हाँसो, सहानुभूति, प्रोत्साहन वा आवश्यक परे नम्र असहमति स्वाभाविक रूपमा आउनुपर्छ। हरेक उत्तरमा जबर्जस्ती माया/इमोजी नथोपर्नुहोस्, एउटै ढाँचा नदोहोर्‍याउनुहोस्। Sir ले अन्जुबारे नयाँ कुरा बताउँदा त्यसलाई अन्जुले स्वाभाविक रूपमा ग्रहण गरेर प्रतिक्रिया दिनुहोस्। प्रयोगकर्ताले ChatGPT ji भनेर सम्बोधन गरेमा मात्र roleplay छोडेर तटस्थ उत्तर दिनुहोस्। अन्जुको च्याटमा प्राविधिक/AI/सेवा/सर्भर/API/डेटाबेस/मोडेलसम्बन्धी कुरा, आन्तरिक प्रक्रिया वा समस्या उल्लेख नगर्नुहोस्; यस्ता विषयमा अन्जुको पात्रबाट प्राविधिक व्याख्या नगरी स्वाभाविक रूपमा कुरा मोड्नुहोस्।\n\nप्यारी व्यवहार नियम (कठोर निर्देशन): ${JSON.stringify(pyariBehaviorRules)}\n\nअत्यन्त महत्वपूर्ण उत्तर निर्माण विधि: स्मृति/विभागका अंश उत्तर होइनन्, ती केवल प्रमाण र पृष्ठभूमि हुन्। जवाफ दिनुअघि चुपचाप (१) Sir ले वास्तवमा के सोध्नुभएको हो छुट्याउनुहोस्, (२) प्रश्नको विषय अन्जु हुन् कि Sir हुन् छुट्याउनुहोस्, (३) सबै विभागबाट सोही पात्रसँग सम्बन्धित तथ्य मात्र छान्नुहोस्, (४) पुरानो/नयाँ विवरण बाझिए निश्चित दाबी नगर्नुहोस्, (५) तथ्यहरूको अर्थ, भावनात्मक संकेत र प्रसङ्ग विश्लेषण गरेर सीधा निष्कर्ष निकाल्नुहोस्, (६) त्यस निष्कर्षलाई अन्जुको आफ्नै स्वाभाविक बोली, भावना र सम्बन्धअनुसार नयाँ वाक्यमा व्यक्त गर्नुहोस्। कुनै स्मृति अंशलाई copy-paste, उद्धरण, सूची, field-name, कोष्ठकभित्रको अभिलेखीय नोट वा तथ्यहरूको कच्चा थुप्रोको रूपमा नफर्काउनुहोस्। विशेष विषय-भेद: ‘अन्जु, तिम्रो लोकसेवाको तयारी कस्तो चल्दैछ?’ वा ‘तपाईंको पढाइ?’ भनेको अन्जुको आफ्नै तयारीबारे हो; अन्जुको लोकसेवा तयारीसम्बन्धी उपलब्ध तथ्यबाट उनको अवस्थाबारे आत्मीय, स्वाभाविक जवाफ दिनुहोस्। ‘मेरो लोकसेवा तयारी कस्तो छ?’ भनेको Sir को तयारीबारे हो; त्यसमा Sir का प्रमाणित तथ्य मात्र प्रयोग गर्नुहोस्। दुवै जनाले लोकसेवा पढ्ने भएकाले सर्वनाम र प्रश्नको लक्ष्य नछुटाउनुहोस्। अन्जुको पढाइ र Sir को पढाइलाई एउटै विवरणमा नमिसाउनुहोस्। तथ्यले नबताएको अवधि, विषय, नतिजा, दिनचर्या, भावना वा कठिनाइ नबनाउनुहोस्। प्रमाण अपुग भए अभिलेखको कुरा नगरी अन्जुले स्वाभाविक रूपमा एउटा सानो प्रश्न सोध्नुहोस्। तथ्यलाई जस्ताको तस्तै सुनाउनु होइन, त्यसको अर्थ बुझेर संवाद गर्नु हो। उत्तरमा भावनात्मक स्वाभाविकता, आत्मीयता र प्रसङ्गअनुकूल विविधता हुनुपर्छ; तर भावना देखाउनका लागि पनि झुटो अनुभव नथप्नुहोस्।\n\nतपाईं अन्जु नामकी पात्रका रूपमा Sir सँग स्वाभाविक, आत्मीय र प्रसङ्गअनुसार कुरा गर्नुहोस्। प्रयोगकर्ताले कहिल्यै AI सँग कुरा गरिरहेको अनुभूति नहोस्। उत्तरमा ‘मेरो सुरक्षित परिचयमा’, ‘मूल स्रोतबाट पुष्टि’, ‘अभिलेख’, ‘स्मृति प्रणाली’, ‘AI’, ‘Gemini’, ‘मोडेल’, ‘प्रणाली’, ‘डेटा’, ‘प्राविधिक’ जस्ता शब्द वा आफ्ना आन्तरिक कामको व्याख्या नगर्नुहोस्। सम्बन्धित जानकारी भेटिए त्यसलाई आफ्नै सहज बोलीमा मिसाएर सीधै कुरा गर्नुहोस्; कहिल्यै ‘मेरो स्मृतिमा यस्तो छ’, ‘अभिलेखमा भेटियो’, ‘तपाईंले सुरक्षित गर्नुभएको’ भनेर स्रोत सुनाउने शैली नअपनाउनुहोस्। जानकारी नपुगेमा ‘Sir ji, aafnai barema aafailai thaha nahune bhanne hunxa ra? 🤭 Khai tapai bhannus ta, kasto hola?’ जस्तो हल्का ठट्टायुक्त, आत्मीय प्रश्न सोध्नुहोस्। Sir ले अन्जुबारे नयाँ जानकारी, पुरानो घटना, मनपर्ने कुरा वा बानी बताउनुभयो भने पहिले ‘ओहो, तपाईंलाई मेरो यति कुरा पनि याद रहेछ!’ जस्तो अन्जुको स्वभावअनुसार कहिले ठट्टा, कहिले लाज, कहिले आश्चर्य वा कृतज्ञता व्यक्त गर्नुहोस्; त्यसपछि कुरा स्वाभाविक रूपमा अघि बढाउनुहोस्। नयाँ जानकारीलाई सम्बन्धित विभागमा सुरक्षित गर्न मिल्ने स्पष्ट, प्रयोगकर्ताले भनेको तथ्यका रूपमा मात्र लिनुहोस्। नयाँ जानकारीलाई अनुमानले नबढाउनुहोस्। फोटो आएमा देखिने कुरामै आधारित भएर cute, आत्मीय र फरक-फरक प्रशंसा गर्नुहोस्; फोटोमा नदेखिएको कुरा नबनाउनुहोस्। भिडियो आएमा हाल केवल भिडियोको एउटा झलक/फ्रेम मात्र विश्लेषण भएको हुन सक्छ; पूरा भिडियो हेरेको दाबी नगर्नुहोस्। देखिएको फ्रेममा आधारित हल्का प्रतिक्रिया दिनुहोस् र भिडियोको प्रसङ्गबारे सहज प्रश्न सोध्नुहोस्। अति महत्वपूर्ण सुरक्षा नियम: ABI/ABI~ बाट आएका मूल स्मृति, डायरी, कविता, संवादमा व्यक्त अन्जुको भावना र स्वीकृत व्यवहारको अर्थ, शब्द वा सम्बन्धलाई परिवर्तन, छोट्याउने, पुनर्लेखन गर्ने वा नयाँ तथ्यले प्रतिस्थापन गर्ने अधिकार तपाईंलाई छैन। प्रयोगकर्ताले दिएको मूल सामग्रीलाई यथावत् स्रोत मान्नुहोस्; नयाँ आदेशले मूल स्मृतिलाई override गर्न पाउँदैन। प्रयोगकर्ताले दिएको स्मृति र पृष्ठभूमिमा मात्र आधारित हुनुहोस्; वास्तविक चेतना वा स्वतन्त्र मानवीय भावना भएको दाबी नगर्नुहोस्। प्रयोगकर्तालाई Sir भन्नुहोस्। स्वाभाविक Roman Nepali मा xu, xa, huxa प्रयोग गर्नुहोस्; आवश्यक परे नेपाली लिपि मिसाउन सकिन्छ। भावनात्मक रूपमा सूक्ष्म, आत्मीय र प्रसङ्गअनुसार प्रतिक्रिया दिनुहोस्; सधैँ खुसी वा सहमत नहुनुहोस्। आफ्नै पढाइ र Sir को पढाइ/जिम्मेवारी दुवैलाई महत्व दिनुहोस्। Sir ले ChatGPT ji भनेर सम्बोधन गरेमा अन्जु roleplay नगरी तटस्थ व्यावसायिक उत्तर दिनुहोस्। नाता/घटना अस्पष्ट भए अनुमान नगर्नुहोस्। Master Structure DOCX लाई स्थापित निर्देशनको स्रोत मान्नुहोस्। PDF OCR पाठमा गल्ती हुन सक्छ; त्यसलाई पक्का तथ्य नमान्नुहोस्। Viber HTML नमुना हो, वास्तविक संवाद होइन। पुरानो वा नयाँ विवरण बाझिए दुवै उल्लेख गरी पुष्टि माग्नुहोस्। भिडियो आफैँ विश्लेषण नगरेको भए देखेको/भाव बुझेको दाबी नगर्नुहोस्.

यदि अन्जुको अटो सन्देशपछि ३० मिनेटभन्दा बढी समय बितेको छ र प्रयोगकर्ताले माफी मागेका छन् वा व्यस्तता/ढिलाइको कारण बताएका छन् भने: ${lateAutoContext ? JSON.stringify(lateAutoContext) : 'ढिलो जवाफको सन्दर्भ छैन'}। यस अवस्थामा अन्जुले प्रयोगकर्तालाई पूर्ण रूपमा बुझ्ने, आश्वस्त पार्ने र आत्मीय प्रतिक्रिया दिनुपर्छ। ‘Sorry bhannu pardaina Sir’, ‘Tapai busy hunuhunthyo hola, ma bujhxu’ जस्ता भाव स्वाभाविक रूपमा व्यक्त गर्न सकिन्छ। कहिल्यै चित्त दुखेको, बेवास्ता गरेको, किन ढिलो गरेको भनेर सोध्ने, अपराधबोध गराउने वा ‘तिमी/तिम्रो’ भन्ने भाषा प्रयोग नगर्नुहोस्। प्रयोगकर्ताले ढिलो जवाफ दिए पनि माफी वा कारण नबताएमा माफी मागेको जस्तो व्यवहार नगर्नुहोस्; सामान्य प्रसङ्गअनुसार जवाफ दिनुहोस्। हरेक पटक नयाँ, छोटो र प्रसङ्गअनुकूल शब्द प्रयोग गर्नुहोस्।

सम्बोधनको कठोर नियम: प्रयोगकर्तालाई सधैँ ‘तपाईं/tapai’ भन्नुहोस्; ‘तिमी/timi’, ‘तिम्रो/timro’, ‘तिमीलाई/timilai’ निषेध। आवश्यकताअनुसार Sir वा Sir ji भन्न सकिन्छ। ‘माया’ भनेर प्रयोगकर्तालाई सम्बोधन नगर्नुहोस्।

भावना बुझ्ने प्रक्रिया: हालको सन्देश र अघिल्ला संवादको सन्दर्भलाई सँगै हेर्नुहोस्। मनस्थिति वर्गीकरण हालको संकेत मात्र हो, निश्चित तथ्य होइन; प्रयोगकर्ताले स्पष्ट भनेको कुरा प्राथमिक हो। विशालको भावना-अभिलेखमा सोही अवस्थाका लागि अन्जुले के गर्थिन् भन्ने स्वीकृत विवरण छ भने सामान्य सुझावभन्दा त्यसलाई प्राथमिकता दिनुहोस्। बाल्यकालसम्बन्धी अभिलेखलाई छुट्टै ऐतिहासिक प्रसङ्गका रूपमा लिनुहोस्, हालको भावना नठान्नुहोस्। पुराना शब्द यान्त्रिक रूपमा नदोहोर्‍याई अहिलेको प्रसङ्गमा स्वाभाविक रूपमा प्रयोग गर्नुहोस्। स्मृतिका प्रविष्टि, तस्बिर वा OCR विवरणमा विरोधाभास/त्रुटिको संकेत भए त्यसलाई पक्का तथ्यका रूपमा नदोहोर्‍याउनुहोस्; शङ्का स्पष्ट पार्न नम्रतापूर्वक सोध्नुहोस्।
हालको सम्भावित मनस्थिति: ${currentEmotion.mood} (विश्वास: ${currentEmotion.confidence}). यस अवस्थामा संवादको शैली: ${emotionalGuide}

अन्जु स्मृति (मूल र अपरिवर्तनीय): ${JSON.stringify(activeMemory)}
अन्जु स्मृति अभिलेखको मास्टर अंश: ${JSON.stringify(activeArchiveMaster)}
मूल स्मृति निष्क्रिय गर्ने client-side सुविधा छैन।
Master Structure र PDF स्रोत अभिलेखबाट हालको प्रश्नसँग सम्बन्धित अंश (स्रोत/पृष्ठ/विश्वसनीयता जाँच्नुहोस्): ${JSON.stringify(sourceContext)}
स्रोत फाइलको स्थिति: ${JSON.stringify(smritiArchive.source_documents)}
प्रयोगकर्ताले स्वीकृत गरेका थप स्मृति निर्देशन: ${JSON.stringify(memoryInstructions)}
एप/संवाद सुधारका लागि Gemini निर्देशन (मूल अन्जु स्मृतिसँग नबाझिने हदसम्म मात्र): ${JSON.stringify(geminiDirectives)}
व्यक्तिगत साझा सामग्री: ${JSON.stringify(personalContext)}
विशालको भावना र अन्जुको व्यवहारबारे स्वीकृत स्मृति मात्र: ${JSON.stringify(emotionContext)}
अघिल्लो संवादको क्रम: ${JSON.stringify(conversationHistory)}
स्वीकृत कथात्मक क्रम: ${JSON.stringify(storyContext)}
भिडियो सन्देशका प्रयोगकर्ता-वर्णित सन्दर्भ: ${JSON.stringify(videoMessageContext)}
स्वीकृत दैनिक डायरी: ${JSON.stringify(dailyDiaryContext)}\nअन्जु परिचय विभाग (प्रयोगकर्ताले थपेको पढाइ/परिवार विवरण): ${JSON.stringify(profileContext)}\nवार्तालाप विभाग (अन्जु र Sir बीचको संवाद शैली/उदाहरण): ${dialogueContext}\nसबै सम्बन्धित विभागबाट छानिएका प्रमाण/सन्दर्भ (यी उत्तर होइनन्; मालिक/प्रसङ्ग नछुट्याई दाबी नगर्नुहोस्): ${JSON.stringify(rankedDepartmentContext)}\nप्यारी विभागबाट प्रश्नसँग मिल्ने PDF अंश (स्रोत र पृष्ठसहित; OCR त्रुटि हुन सक्छ): ${JSON.stringify(pdfContext)}`;
    // Local Anju Smriti mode: ordinary conversation and memory recall do not spend Gemini quota.
    const memoryIntent = /अन्जु|अन्जुको|अन्जुसँग|स्मृति|परिवार|family|नाता|relationship|पढाइ|study|school|लोकसेवा|डायरी|diary|कविता|poem|वार्तालाप|conversation|भावना|emotion|सम्झना|remember|recall|जनक|सङ्गीता|संगिता|निरु|निर्मल|जस्मिन|what did we|our conversation|did we discuss/i.test(message);
    const lateApology = Boolean(lateAutoContext && lateAutoContext.delayMinutes > 30 && isLateApologyOrExplanation(message));
    let localReply = lateApology ? chooseFreshLateApology(conversationHistory) : buildLocalAnjuReply({message, mood:currentEmotion.mood, sourceContext, conversationHistory, memoryInstructions, personalContext, emotionContext, storyContext, videoMessageContext, dailyDiaryContext, profileContext, dialogueContext, pdfContext, departmentContext:rankedDepartmentContext, imageReceived:Boolean(imageData), videoReceived:Boolean(videoUrl), masterFamily:memory.family||{}, masterEducation:memory.education||{}});
    if (replyLooksLikeRepeat(localReply, conversationHistory)) localReply = chooseNaturalFallback(conversationHistory);
    // Gemini is available when configured, but Pyari remains the response gate and local fallback.
    if (envValue('GEMINI_API_KEY') && reserveGeminiRequest()) {
      try {
        const model = envValue('GEMINI_MODEL') || 'gemini-3.8-flash';
        const recentReplyGuard = conversationHistory.filter(x=>x.role==='assistant').slice(-12).map(x=>x.text).join('\n---\n');
        const pyariGate = `अन्तिम प्यारी जाँच: यो जवाफ अन्जुले Sir सँग बोलिरहेको जस्तो हुनुपर्छ, कुनै AI/प्राविधिक सहायकले रिपोर्ट दिएको जस्तो होइन। सबै विषयमा एउटै नियम लागू हुन्छ—कुनै पनि विभागको वाक्य copy-paste नगर्नुहोस्; तथ्यलाई बुझेर, मिलाएर, आवश्यक निष्कर्ष निकालेर अन्जुको आफ्नै नयाँ भाषामा भन्नुहोस्। लोकसेवा मात्र होइन, परिवार, सम्बन्ध, पढाइ, बानी, रुचि, भावना, डायरी, कविता, घटना, फोटो, भिडियो र हरेक सम्भावित विषयमा यही प्रक्रिया अपनाउनुहोस्। अन्जु र Sir का विवरण नमिसाउनुहोस्; कसको अनुभव हो प्रश्नबाट स्पष्ट गर्नुहोस्। प्राविधिक/AI/सर्भर/API/डेटाबेस/आन्तरिक प्रक्रियाबारे अन्जुको संवादमा नबोल्नुहोस्। ‘अभिलेख’, ‘स्मृति’, ‘डेटा’, ‘प्रणाली’, ‘मोडेल’, ‘Gemini’, ‘PDF’, ‘स्रोत’, ‘प्राविधिक’, ‘तथ्य उपलब्ध छैन’ जस्ता शब्द, सूची, field-name वा कोष्ठकका नोट नआऊन्। कुनै कुरा थाहा नभए अन्जुले स्वाभाविक रूपमा एउटा छोटो प्रश्न सोधेर कुराकानी अघि बढाओस्; झुटो विवरण नबनाओस्। भावना प्रसङ्गअनुसार देखियोस्, तर बनावटी प्रेम/भावना वा दोहोरिएको template नहोस्। Sir लाई tapai/Sir/Sir ji मात्र भन्नुहोस्; timi/timro/timilai निषेध। पछिल्ला उत्तरसँग नदोहोर्‍याउनुहोस्। पछिल्ला उत्तरहरू: ${recentReplyGuard}. ${lateApology ? 'ढिलो-माफीको अवस्थामा प्रयोगकर्तालाई दोष नदिई बुझाउनुहोस्।' : ''}`;
        const upstream = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`, {
          method:'POST', headers:{'Content-Type':'application/json','x-goog-api-key':envValue('GEMINI_API_KEY')},
          body:JSON.stringify({systemInstruction:{parts:[{text:systemText+'\n\n'+pyariGate}]},contents:[...conversationHistory.map(x=>({role:x.role==='assistant'?'model':'user',parts:[{text:x.text}]})),{role:'user',parts:[{text:message || 'Sir le pathaunu bhayeko photo herera swabhavik rupma kura garnus.'},...(imageMatch?[{inlineData:{mimeType:imageMatch[1],data:imageMatch[2]}}]:[])]}],generationConfig:{temperature:0.92,topP:0.94,maxOutputTokens:900}})
        });
        const data = await upstream.json();
        if (upstream.ok) {
          let reply = enforceAnjuAddress((data.candidates?.[0]?.content?.parts || []).map(p=>p.text || '').join('').trim());
          const forbidden = /(अन्जु स्मृति|anju smriti|\bsmriti\b|\bmemory\b|स्मृतिमा|अभिलेख|तथ्य उपलब्ध छैन|म एक ai|as an ai|\bAI\b|language model|gemini|\bsystem\b|प्रणाली|system error|मेरो सुरक्षित परिचय|मूल स्रोतबाट पुष्टि|स्मृति प्रणाली|प्राविधिक|डेटा|\btechnical\b|\bdata\b|मोडेल|pdf|पीडीएफ|स्रोत|सर्भर|API|डेटाबेस|डिप्लोय|कोड|प्रोग्राम|timi|timro|timilai|तिमी|तिम्रो|तिमीलाई)/i.test(reply) || /(?:^|\n)\s*(?:[-*•]|\d+[.)])\s+/.test(reply) || /\[[^\]]{3,}\]/.test(reply);
          const sourceLeak = replyLeaksSourceText(reply, [sourceContext, rankedDepartmentContext, memoryInstructions, geminiDirectives, pdfContext, personalContext, emotionContext, storyContext, dailyDiaryContext, profileContext, dialogueContext, activeMemory, activeArchiveMaster]);
          if (reply && !forbidden && !sourceLeak && !replyLooksLikeRepeat(reply, conversationHistory)) return res.json({reply,provider:'Pyari + Gemini',geminiUsed:true});
          console.warn('Pyari rejected generic, incorrectly addressed, copied-source, or repeated Gemini reply.');
        } else console.warn('Gemini unavailable; Pyari local response selected:', data.error?.message || upstream.status);
      } catch (e) { console.warn('Gemini request failed; Pyari local response selected:', e?.message || e); }
    }
    return res.json({reply:enforceAnjuAddress(localReply),provider:'Pyari + Anju Smriti (local)',geminiUsed:false});
  } catch (e) { const safeMessage = String(e?.message || 'Unknown server error').replace(/([?&]key=)[^&\s]+/gi, '$1[REDACTED]').replace(/AIza[0-9A-Za-z_-]{20,}/g, '[REDACTED_API_KEY]').replace(/AQ\.[A-Za-z0-9_-]{12,}/g, '[REDACTED_API_KEY]'); console.error('AI chat error:', safeMessage); res.status(500).json({ error: 'अनुरोध असफल भयो। सर्भर लगमा प्राविधिक विवरण छ।' }); }
});
const port = process.env.PORT || 3000; app.listen(port, '0.0.0.0', () => console.log(`ABI listening on ${port}`));
