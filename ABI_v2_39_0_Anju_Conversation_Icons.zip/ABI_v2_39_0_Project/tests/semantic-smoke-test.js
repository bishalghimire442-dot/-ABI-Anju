const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const server = fs.readFileSync(path.join(root, 'server.js'), 'utf8');
const client = fs.readFileSync(path.join(root, 'public', 'app.js'), 'utf8');

function extractFunction(name, nextName) {
  const start = server.indexOf(`function ${name}(`);
  assert.notEqual(start, -1, `missing function ${name}`);
  const end = server.indexOf(`\nfunction ${nextName}(`, start);
  return server.slice(start, end === -1 ? server.length : end);
}
const exposed = {};
const helpers = [
  extractFunction('classifyQuestionTarget', 'replyLeaksSourceText'),
  extractFunction('rankDepartmentContext', 'buildLocalAnjuReply'),
  'this.api = { classifyQuestionTarget, rankDepartmentContext };'
].join('\n');
vm.runInNewContext(helpers, exposed);

const targetCases = [
  ['अन्जु तिम्रो लोकसेवा तयारी कस्तो चल्दैछ?', 'anju'],
  ['मेरो लोकसेवा तयारी कस्तो छ?', 'user'],
  ['अन्जु, तिम्रो परिवारको कुरा सुनाऊ न', 'anju'],
  ['मेरो परिवारको बारेमा के थाहा छ?', 'user'],
  ['तपाईंको बानी कस्तो छ अन्जु?', 'anju'],
  ['मलाई मेरो पढाइमा के सुधार गर्नुपर्ला?', 'user']
];
for (const [question, expected] of targetCases) {
  assert.equal(exposed.api.classifyQuestionTarget(question), expected, question);
}

const ranked = exposed.api.rankDepartmentContext('सङ्गीता को हुन्?', [
  { department: 'कविता', title: 'प्रेम कविता', owner: 'अस्पष्ट', text: 'माया र मनका शब्द' },
  { department: 'परिवार तथा नाता', title: 'सङ्गीता', owner: 'अन्जुको परिवार', text: 'जनक दाइकी छोरी' }
]);
assert.equal(ranked[0].title, 'सङ्गीता');

for (const marker of [
  'buildDepartmentContextForChat', 'दैनिक डायरी', 'समयक्रम कहानी', 'अन्जु भावना',
  'Sir को भावना र अन्जुको प्रतिक्रिया', 'भिडियो सन्देश', 'मेरो संसार', 'कविता',
  'परिवार तथा नाता', 'प्यारी हौसला', 'ABI Instructions Department', 'अन्जु परिचय', 'वार्तालाप शैली'
]) assert.ok(client.includes(marker), `missing department context: ${marker}`);
assert.match(server, /प्राविधिक\/AI\/सर्भर\/API\/डेटाबेस/);
assert.match(server, /replyLeaksSourceText\(reply, \[sourceContext, rankedDepartmentContext, memoryInstructions/);
assert.match(server, /प्रयोगकर्ताले लेखेको ‘सम्झनैपर्ने विषय’/);
assert.match(server, /context:String\(x.context/);
assert.match(server, /सामान्य संवादमा स्रोतको चर्चा नगर्नुहोस्/);
assert.match(fs.readFileSync(path.join(root, 'public', 'sw.js'), 'utf8'), /abi-v2\.39\.0-static/);
const html = fs.readFileSync(path.join(root, 'public', 'index.html'), 'utf8');
assert.match(html, /सम्झनैपर्ने विषय/);
assert.match(html, /pdfRememberInput/);
assert.match(html, /सम्बन्धित मिति \/ विषय/);
assert.doesNotMatch(client, /profile\.src=b\.dataset\.photo/);
assert.doesNotMatch(html, /data-photo=/);
assert.match(client, /state\.mood=b\.dataset\.mood/);
for (const section of ['प्यारी','ABI Instructions Department','अन्जु परिचय','वार्तालाप','हाम्रो संसार','मेरो संसार','डायरी','कविता','अन्जु स्मृति','भावना','आदेश','Voice अभिलेख','कहानी अभिलेख','Cloud Backup','सामग्री व्यवस्थापन','खोज तथा आइकन मार्गदर्शिका']) assert.ok(html.includes(section), `missing preserved section: ${section}`);
assert.match(html, /प्यारी हौसला उपविभाग/);
assert.match(html, /हौसला सुरक्षित गर्नुहोस्/);
assert.match(html, /ABI Instructions Department/);
assert.match(html, /chatVoiceMessageBtn/);
assert.match(html, /chatFileBtn/);
assert.match(html, /fileManagerList/);
assert.match(server, /app\.post\('\/api\/voice\/message'/);
assert.match(server, /app\.get\('\/api\/files\/list'/);
assert.match(server, /app\.post\('\/api\/file'/);
assert.doesNotMatch(fs.readFileSync(path.join(root, 'public', 'login.html'), 'utf8'), /निजी अभिलेख सुरक्षित राख्न पासवर्ड प्रविष्ट/);
const pyariPane = html.slice(html.indexOf('<section id="pyari"'), html.indexOf('<section id="abiInstructions"'));
assert.ok(!pyariPane.includes('निर्देशन'), 'Pyari pane must use हौसला terminology only');
assert.match(pyariPane, /प्यारी हौसला उपविभाग/);
assert.match(html, /अटो सन्देश निर्देशन/);
assert.match(client, /प्यारी विभागको निर्देशन/);
assert.doesNotMatch(client, /प्यारी विभागको हौसला/);
console.log(`ABI v2.38.0 semantic smoke tests passed (${targetCases.length} target tests + relevance + department coverage + guard checks).`);
