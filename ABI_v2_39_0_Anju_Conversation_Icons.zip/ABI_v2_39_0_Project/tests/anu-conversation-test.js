const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const server = fs.readFileSync(path.join(root, 'server.js'), 'utf8');
const start = server.indexOf('// ABI v2.39.0: expanded natural Anju-to-Sir everyday dialogue recognition.');
const end = server.indexOf('\nfunction buildLocalAnjuReply(ctx)', start);
assert.ok(start >= 0 && end > start, 'conversation phrase registry and detector must exist');
const buildStart = server.indexOf('function buildLocalAnjuReply(ctx)', end);
const buildEnd = server.indexOf('\nfunction ', buildStart + 10);
assert.ok(buildStart >= 0 && buildEnd > buildStart, 'local Anju reply function must exist');
const source = server.slice(start, end) + '\n' + server.slice(buildStart, buildEnd) + '\nthis.api={ANJU_CASUAL_PHRASE_MAP,detectAnjuCasualIntent,buildAnjuCasualReply,buildLocalAnjuReply};';
const sandbox = {};
vm.runInNewContext(source, sandbox);
assert.ok(sandbox.api.ANJU_CASUAL_PHRASE_MAP.size > 1000, 'must generate over 1,000 phrase combinations');
for (const [message, intent] of [
  ['अन्जु', 'hello'], ['अञ्जु', 'hello'], ['Anju', 'hello'],
  ['हजुर अन्जु, के गर्दै हुनुहुन्छ?', 'activity'],
  ['अन्जु खाना खानुभयो?', 'food'], ['अन्जु कहाँ हुनुहुन्छ?', 'location'],
  ['अन्जु सन्चै हुनुहुन्छ?', 'wellbeing'], ['अन्जु पढाइ कस्तो हुँदैछ?', 'study'],
  ['अन्जु मलाई सम्झिनुभयो?', 'affection'], ['अन्जु मन कस्तो छ?', 'mood']
]) assert.equal(sandbox.api.detectAnjuCasualIntent(message), intent, message);
const first = sandbox.api.buildAnjuCasualReply('hello', []);
assert.ok(first && first.length > 12);
for (const greeting of ['अन्जु','अञ्जु','Anju']) {
  const answer = sandbox.api.buildLocalAnjuReply({message:greeting,conversationHistory:[]});
  assert.ok(answer && /Sir|sir/i.test(answer), `one-word greeting must trigger Anju conversation: ${greeting}`);
}
const html = fs.readFileSync(path.join(root, 'public', 'index.html'), 'utf8');
for (const id of ['chatVoiceBtn','chatVoiceMessageBtn','chatPhotoBtn','chatVideoBtn','chatFileBtn']) assert.match(html, new RegExp('id="'+id+'"'));
assert.match(html, /<svg viewBox="0 0 24 24"/);
const css = fs.readFileSync(path.join(root, 'public', 'style.css'), 'utf8');
assert.match(css, /v2\.39\.0: quiet, consistent outline icons/);
console.log(`ABI v2.39.0 Anju conversation tests passed (${sandbox.api.ANJU_CASUAL_PHRASE_MAP.size.toLocaleString()} generated phrase combinations + greeting/intent/icon checks).`);
