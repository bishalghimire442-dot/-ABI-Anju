# ABI Anju v2.40.0 — Release Candidate

## Included
- Seven main departments and 18 mapped panes retained.
- Context-aware short-reply handling and 160 varied proactive message examples.
- Per-answer user review, message edit history and conversation branch preservation.
- PDF upload capacity: 50 MB per file and up to 400 pages.
- Full-page Nepali+English OCR path with page-level checkpoints every three pages; interrupted OCR can resume from saved OCR pages.
- PDF text/OCR pages remain in browser IndexedDB with the source PDF; they are not automatically synchronized to Google Drive.
- Recycle Bin and recovery safeguards retained.

## Verification
- `npm test` passes all five test groups.
- `node --check server.js`, `node --check public/app.js`, and `node --check public/sw.js` pass.
- Source PDF metadata checked separately: `(ABI)~.pdf` is 338 pages (32,613,360 bytes); `@ABI.pdf` is 99 pages (23,436,261 bytes).
- Local OCR spot-check on page 2 of the 338-page PDF produced readable Nepali text. This is a spot-check only, not certification of all pages.

## Not certified / requires user environment or credentials
- Full 338-page OCR completion and review in the target browser/device.
- Live Gemini response (the previously observed Free Tier quota issue remains unresolved).
- Google Drive OAuth, backup and restore end-to-end.
- Browser push notifications while app is closed (requires user permission and push configuration).
- Android/Desktop interaction, file manager bulk operations and cross-device persistence.
- Production deployment. No GitHub push or Render deployment was performed.

This is a release candidate, not a production sign-off. The two original PDFs are not bundled into the app ZIP and must be retained separately.

### Gallery persistence correction (2026-11-18)
- New Gallery uploads are stored as Blob records in the existing IndexedDB media store; `localStorage` keeps only a small `abi-photo:<id>` reference.
- Gallery reload resolves those references from IndexedDB and displays the stored image.
- Existing `data:image/...` Gallery entries are migrated to IndexedDB on startup, one by one; a failed migration leaves the original entry intact.
- Existing ABI backup export and restore include the IndexedDB photo blobs through the shared attachments collection.
- This browser-side persistence depends on the browser's site data remaining available. Clearing browser storage can still remove local photos unless an ABI backup is kept.
