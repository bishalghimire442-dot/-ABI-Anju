ABI v2.14

यो ABI नामको PWA starter package हो। लोगो र Home Screen नाममा ABI मात्र राखिएको छ। संसार पृष्ठमा राधाकृष्ण भगवानको भक्तिमय चित्र छ।

Android Home Screen install गर्न HTTPS hosting आवश्यक हुन्छ। Node.js 20+ server मा project upload गरी npm install र npm start चलाउनुहोस्। वास्तविक AI chat का लागि सुरक्षित server-side API key र deployment configuration आवश्यक हुन्छ।

परिवार स्मृतिमा उपलब्ध प्रमाणित नाता राखिएको छ। हेमा दिदी लगायतका नाम सुरक्षित छन्; पुष्टि नभएका नाता वा विवरण अनुमान गरिएको छैन। सबै परिवार सदस्यका विवरण थपिँदै जाँदा master memory मा राख्नुहोस्।

मूल PDF हरू यो ZIP मा समावेश वा परिवर्तन गरिएको छैन। PDF प्रयोगकर्ताले छुट्टै थप्न सक्छन्। परिचयपत्र/नागरिकता फोटो समावेश गरिएको छैन। Browser storage सामग्री स्वतः अर्को उपकरणमा sync हुँदैन; नियमित backup गर्नुहोस्। यो production-security-audited hosting होइन।


ABI v2.8 — Voice capture update
- Main navigation now shows Chat and Settings only. Family, diary, poems, instructions, voice archive, photo uploads, app-improvement requests and cloud setup are inside Settings.
- Three voice categories: pre-diary context; Anju habits/outside-diary details; diary period 2083 Baisakh 1 to Asoj 2. Diary category accepts multiple audio parts.
- Audio transcription requires OPENAI_API_KEY and TRANSCRIPTION_MODEL. Original audio is saved outside the public web folder in private_data/audio/; transcripts and metadata are saved in private_data/voice_transcripts.json. Use a persistent private disk on hosting and restrict server access; this starter does not encrypt files at rest or provide a user-facing audio download/restore screen yet.
- Photo uploads are stored under public/uploads; do not upload identity documents or sensitive personal records.
- Architecture instructions are saved as proposals; code changes require a reviewed new build.
- Google Drive OAuth/automatic sync is NOT yet connected.


ABI v2.9 — Interface refresh and separated workspaces
- Refreshed mobile-first interface with premium purple/lilac palette, refined spacing, cards, message bubbles, responsive navigation and accessible touch targets.
- Renamed the two work areas to “अन्जु स्मृति” and “अबि सुधार”.
- App improvement requests now use a separate improvementRequests list instead of being mixed into Anju memory instructions. Existing user data keys remain intact.
- This remains a starter build: server-side AI, secure authentication, persistent database, Google Drive OAuth, encryption at rest, and release automation still require implementation and testing before production use.


नयाँ सुविधा v2.10 — मेरो संसार
- मनपर्ने गीत तथा Music app का link/playlist, Facebook post, YouTube video र अन्जुसम्बन्धी अन्य फाइल राख्ने छुट्टै विभाग।
- प्रत्येक सामग्रीसँग इतिहास/पठाउनुअघिको प्रसङ्ग, प्रयोगकर्ताले सम्झेको अन्जुको प्रतिक्रिया, र प्रयोगकर्ताको भावना छुट्टाछुट्टै राख्न मिल्ने।
- YouTube र Spotify का समर्थित link ABI भित्र embed भएर चल्न सक्छन्; अन्य music provider आधिकारिक app/site मा खुल्छन्। Facebook post को embed/login/privacy प्रतिबन्धका कारण link बाहिर खोलिन सक्छ।
- आफ्नै वा अनुमति प्राप्त audio/video/image/document attachment browser को IndexedDB मा स्थानीय रूपमा राखिन्छ। Browser data हटेमा स्थानीय attachment हराउन सक्छ; cloud backup अहिले जडान भएको छैन।
- Chat API मा सामग्रीका शीर्षक र प्रयोगकर्ताले लेखेका सन्दर्भ पठाइन्छन् ताकि AI ले रुचि बुझेर संवाद गर्न सकोस्। पुरानो प्रतिक्रिया user recollection हो, AI ले वास्तविक घटना भनेर दाबी गर्नु हुँदैन।
- Copyrighted streaming गीत app बाट copy/download हुँदैन; provider link/official embed प्रयोग हुन्छ।
- “च्याटसँगै सुन्नुहोस्” mini-player: समर्थित YouTube/Spotify embed वा आफ्नै audio/video फाइल छुट्टै floating player मा खुल्छ र Chat पृष्ठमा जाँदा पनि player देखिइरहन्छ। अन्य provider ले आधिकारिक app मा खोल्न सक्छ।


ABI v2.12 थपिएका कुरा:
- सेटिङमा 🔎 आइकन मार्गदर्शिका: मुख्य मेनु, sub-icon र तिनको कामको व्याख्या।
- लेख्ने/छान्ने text fields का drafts browser localStorage मा स्वतः सुरक्षित हुन्छन्।
- Binary files र audio का लागि छुट्टै upload/save प्रक्रिया आवश्यक हुन्छ; browser storage/cloud backup स्वतः सुनिश्चित हुँदैन।
- अन्जु भावना, अन्जु स्मृति र अबि सुधार अलग उद्देश्यका क्षेत्र हुन्।

v2.13 — कहानी अभिलेख र भिडियो सन्देश
- तीन समयखण्ड: २०८१ पुस १–२०८२ असार १; २०८२ असार २–कार्तिक २२; २०८३ बैशाख १–असोज २।
- नेपाली voice रेकर्ड/अपलोड, Speech-to-Text, editable transcript र प्रयोगकर्ताले “हुन्छ, सुरक्षित गर” गरेपछि मात्र अभिलेख।
- स्वीकृत कहानी र प्रयोगकर्ताले लेखेको परिस्थिति/व्यवहार विवरण Chat सन्दर्भमा पठाइन्छ।
- अन्जुले पठाएका भिडियो सन्देशका लागि video file, परिस्थिति, देखिएको/सुनिएको सामग्री र प्रयोगकर्ताको व्याख्या अलग-अलग सुरक्षित हुन्छ।
- भिडियो स्थानीय IndexedDB मा रहन्छ; हाल AI ले भिडियोको दृश्य वा आवाज स्वतः विश्लेषण गर्दैन। विवरण मात्र Chat सन्दर्भमा जान्छ।
- नेपाली transcription र AI Chat का लागि hosting मा OPENAI_API_KEY आवश्यक छ; API key नहुँदा स्थानीय fallback चल्छ।


ABI v2.14 — नेपाली मिति डायरी र एकीकृत अभिलेख खोज
- २०८३ बैशाख १ देखि असोज २ सम्मको क्लिक गर्न मिल्ने नेपाली पात्रो। महिनाका दिन संख्या र साताका सुरुका दिन २०८३ को प्रकाशित पात्रोअनुसार राखिएका छन्; असोज १ र २ मात्र यो डायरी दायरामा देखिन्छन्।
- प्रत्येक दिनको entry छुट्टै YYYY-MM-DD BS key मा सुरक्षित हुन्छ। अर्को मितिको लेखाइमा मिसिँदैन। लेख्दा स्थानीय मस्यौदा स्वतः सुरक्षित हुन्छ; अन्तिम अभिलेखका लागि स्पष्ट Save बटन चाहिन्छ।
- शीर्षक, पाठ, प्रसङ्ग, व्यक्ति, भावना, वर्ग, स्रोत र प्रयोगकर्ताको पुष्टि स्थिति छुट्टाछुट्टै metadata का रूपमा राखिन्छ। मिति/शब्द/व्यक्ति/प्रसङ्ग खोज र सबै विभागको एकीकृत खोज उपलब्ध।
- सुरक्षित दैनिक डायरीका अन्तिम ३० प्रविष्टि API chat context मा metadata सहित पठाइन्छन्। अपुष्ट प्रविष्टि अपुष्ट नै चिनिन्छ; AI ले अनुमानलाई प्रमाणित तथ्य मान्नु हुँदैन।
- पुराना PDF library बाट अलग्गै देखाइन्छन्; मूल PDF वा पुरानो स्मृति मेटिएको/overwrite गरिएको छैन।
- सबै डेटा अझै यस browser को localStorage/IndexedDB मा निर्भर छ। Cloud sync, multi-device database, login/authentication, encryption-at-rest र पूर्ण production security लागू भएको छैन। Backup नियमित निकाल्नुहोस्।
- पात्रोको BS महिना-दिन/weekday reference: EnglishToNepali 2083 calendar, Calendaw 2083, Nepali Calendar PDF (स्रोतहरू build notes मा जाँचिएका)।
