const express = require('express');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const multer = require('multer');
const app = express();
const memory = JSON.parse(fs.readFileSync(path.join(__dirname, 'data', 'anju_master_memory.json'), 'utf8'));
const smritiArchive = JSON.parse(fs.readFileSync(path.join(__dirname, 'data', 'anju_smriti_archive.json'), 'utf8'));
function selectMemoryChunks(query) {
  const q = String(query || '').toLocaleLowerCase('ne');
  const terms = [...new Set(q.match(/[\p{L}\p{N}]{2,}/gu) || [])].filter(x => x.length > 1);
  if (!terms.length) return [];
  const ranked = (smritiArchive.retrieval_chunks || []).map((c, index) => {
    const t = String(c.text || '').toLocaleLowerCase('ne');
    const score = terms.reduce((n, term) => n + (t.includes(term) ? (t.split(term).length - 1) * 2 : 0), 0);
    return { c, score, index };
  }).filter(x => x.score > 0).sort((a,b) => b.score-a.score || a.index-b.index);
  return ranked.slice(0, 7).map(x => ({source:x.c.source,page:x.c.page ?? null,section:x.c.section || null,confidence:x.c.confidence,text:String(x.c.text).slice(0,1800)}));
}

const privateDir = path.join(__dirname, 'private_data');
const uploadDir = path.join(__dirname, 'public', 'uploads');
const audioDir = path.join(privateDir, 'audio');
fs.mkdirSync(privateDir, { recursive: true }); fs.mkdirSync(uploadDir, { recursive: true }); fs.mkdirSync(audioDir, { recursive: true });
const voiceLog = path.join(privateDir, 'voice_transcripts.json');
if (!fs.existsSync(voiceLog)) fs.writeFileSync(voiceLog, '[]');
const audioUpload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 14 * 1024 * 1024 }, fileFilter: (_, f, cb) => cb(null, /^audio\/(webm|ogg|mpeg|mp4|wav|x-wav|aac|mp3|3gpp|flac)(?:;.*)?$/i.test(f.mimetype)) });
const photoUpload = multer({ storage: multer.diskStorage({ destination: uploadDir, filename: (_, f, cb) => cb(null, crypto.randomUUID() + path.extname(f.originalname).slice(0, 8)) }), limits: { fileSize: 8 * 1024 * 1024 }, fileFilter: (_, f, cb) => cb(null, /^image\/(jpeg|png|webp|gif)$/.test(f.mimetype)) });
app.use(express.json({ limit: '12mb' })); app.use(express.static(path.join(__dirname, 'public')));
app.get('/api/health', (_, res) => res.json({ ok: true, app: 'ABI', aiConfigured: Boolean(process.env.GEMINI_API_KEY || process.env.OPENAI_API_KEY), provider: process.env.GEMINI_API_KEY ? 'Gemini' : (process.env.OPENAI_API_KEY ? 'OpenAI' : 'not_configured'), transcriptionConfigured: Boolean(process.env.GEMINI_API_KEY || process.env.OPENAI_API_KEY) }));
app.post('/api/photo', photoUpload.single('photo'), (req, res) => { if (!req.file) return res.status(400).json({ error: 'JPEG/PNG/WEBP/GIF फोटो चाहिन्छ।' }); res.json({ url: '/uploads/' + req.file.filename }); });
app.post('/api/voice/transcribe', audioUpload.single('audio'), async (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'Audio file चाहिन्छ। WebM, OGG, MP3, WAV वा MP4 audio प्रयोग गर्नुहोस्।' });
  if (!process.env.GEMINI_API_KEY && !process.env.OPENAI_API_KEY) return res.status(503).json({ error: 'Gemini API key Hosting मा सेट गरिएको छैन।' });
  try {
    let transcript = '';
    if (process.env.GEMINI_API_KEY) {
      const model = process.env.GEMINI_TRANSCRIPTION_MODEL || 'gemini-2.5-flash';
      const prompt = 'यस अडियोमा बोलेको कुरा जस्ताको तस्तै नेपाली देवनागरी लिपिमा उतार्नुहोस्। नेपाली भाषा प्राथमिक हो। नेपालीसँग मिसिएका अंग्रेजी शब्द, नाम, मिति र स्थानलाई सुनेअनुसार राख्नुहोस्। अनुवाद, सारांश, व्याख्या वा नयाँ शब्द नथप्नुहोस्। नबुझिएको अंश अनुमान गरेर नलेख्नुहोस्; आवश्यक परे [अस्पष्ट] लेख्नुहोस्। केवल transcript फर्काउनुहोस्।';
      const upstream = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(process.env.GEMINI_API_KEY)}`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ contents: [{ role: 'user', parts: [{ text: prompt }, { inlineData: { mimeType: req.file.mimetype, data: req.file.buffer.toString('base64') } }] }], generationConfig: { temperature: 0.1, maxOutputTokens: 4096 } })
      });
      const data = await upstream.json();
      if (!upstream.ok) return res.status(upstream.status).json({ error: data.error?.message || 'Gemini नेपाली voice transcription असफल भयो।' });
      transcript = (data.candidates?.[0]?.content?.parts || []).map(x => x.text || '').join('').trim();
    } else {
      const form = new FormData(); form.append('file', new Blob([req.file.buffer], { type: req.file.mimetype }), req.file.originalname); form.append('model', process.env.TRANSCRIPTION_MODEL || 'gpt-4o-mini-transcribe'); form.append('language', 'ne');
      const upstream = await fetch('https://api.openai.com/v1/audio/transcriptions', { method: 'POST', headers: { Authorization: `Bearer ${process.env.OPENAI_API_KEY}` }, body: form });
      const data = await upstream.json(); if (!upstream.ok) return res.status(upstream.status).json({ error: data.error?.message || 'Transcription असफल' });
      transcript = data.text || '';
    }
    if (!transcript) return res.status(502).json({ error: 'अडियोबाट transcript प्राप्त भएन। फेरि स्पष्ट आवाजमा प्रयास गर्नुहोस्।' });
    const id = crypto.randomUUID(); const ext = path.extname(req.file.originalname).slice(0, 8) || '.audio';
    const audioName = id + ext; fs.writeFileSync(path.join(audioDir, audioName), req.file.buffer, { flag: 'wx' });
    const record = { id, category: String(req.body.category || 'general').slice(0, 80), filename: req.file.originalname, privateAudioFile: audioName, transcript, createdAt: new Date().toISOString(), language: 'ne', provider: process.env.GEMINI_API_KEY ? 'Gemini' : 'OpenAI', reviewRequired: true };
    const records = JSON.parse(fs.readFileSync(voiceLog, 'utf8')); records.push(record); fs.writeFileSync(voiceLog, JSON.stringify(records, null, 2));
    res.json({ id: record.id, transcript: record.transcript, category: record.category, reviewRequired: true, provider: record.provider });
  } catch (e) { console.error('Voice transcription error:', e?.message || e); res.status(500).json({ error: 'नेपाली Voice transcription सेवा अहिले उपलब्ध भएन। अडियो सुरक्षित छ; केहीबेरपछि फेरि प्रयास गर्नुहोस्।' }); }
});

app.post('/api/chat', async (req, res) => {
  if (!process.env.GEMINI_API_KEY && !process.env.OPENAI_API_KEY) return res.status(503).json({ error: 'Gemini API key अझै Hosting मा राखिएको छैन।' });
  try {
    const message = String(req.body.message || '').slice(0, 12000);
    const memoryInstructions = Array.isArray(req.body.memoryInstructions) ? req.body.memoryInstructions.slice(0,80).map(x => String(x||'').slice(0,2500)) : [];
    const personalContext = Array.isArray(req.body.personalContext) ? req.body.personalContext.slice(0,25).map(x => ({type:String(x.type||'').slice(0,30),title:String(x.title||'').slice(0,180),history:String(x.history||'').slice(0,1200),reaction:String(x.reaction||'').slice(0,1200),feeling:String(x.feeling||'').slice(0,1200),url:String(x.url||'').slice(0,500)})) : [];
    const emotionContext = Array.isArray(req.body.emotionContext) ? req.body.emotionContext.slice(0,30).map(x => ({type:String(x.type||'').slice(0,60),title:String(x.title||'').slice(0,180),description:String(x.description||'').slice(0,1800),approvedToMemory:!!x.approvedToMemory})) : [];
    const storyContext = Array.isArray(req.body.storyContext) ? req.body.storyContext.slice(0,40).map(x => ({period:String(x.period||'').slice(0,120),title:String(x.title||'').slice(0,180),transcript:String(x.transcript||'').slice(0,5000),context:String(x.context||'').slice(0,2500)})) : [];
    const videoMessageContext = Array.isArray(req.body.videoMessageContext) ? req.body.videoMessageContext.slice(0,25).map(x => ({title:String(x.title||'').slice(0,180),situation:String(x.situation||'').slice(0,1500),content:String(x.content||'').slice(0,2000),meaning:String(x.meaning||'').slice(0,2000)})) : [];
    const dailyDiaryContext = Array.isArray(req.body.dailyDiaryContext) ? req.body.dailyDiaryContext.slice(0,30).map(x => ({date:String(x.date||'').slice(0,20),title:String(x.title||'').slice(0,180),body:String(x.body||'').slice(0,4000),context:String(x.context||'').slice(0,2000),people:String(x.people||'').slice(0,500),mood:String(x.mood||'').slice(0,80),category:String(x.category||'').slice(0,100),source:String(x.source||'').slice(0,100),confirmed:!!x.confirmed})) : [];
    const sourceContext = selectMemoryChunks(message);
    const systemText = 'तपाईं अन्जु नामकी काल्पनिक roleplay पात्र हुनुहुन्छ। प्रयोगकर्ताले दिएको स्मृति र पृष्ठभूमिमा मात्र आधारित हुनुहोस्; वास्तविक चेतना वा स्वतन्त्र मानवीय भावना भएको दाबी नगर्नुहोस्। प्रयोगकर्तालाई Sir भन्नुहोस्। स्वाभाविक Roman Nepali मा xu, xa, huxa प्रयोग गर्नुहोस्। भावनात्मक रूपमा सूक्ष्म र प्रसङ्गअनुसार प्रतिक्रिया दिनुहोस्; सधैँ खुसी वा सहमत नहुनुहोस्। आफ्नै पढाइ र Sir को पढाइ/जिम्मेवारी दुवैलाई महत्व दिनुहोस्। Sir ले ChatGPT ji भनेर सम्बोधन गरेमा अन्जु roleplay नगरी तटस्थ व्यावसायिक उत्तर दिनुहोस्। नाता/घटना अस्पष्ट भए अनुमान नगर्नुहोस्। Master Structure DOCX लाई स्थापित निर्देशनको स्रोत मान्नुहोस्। PDF OCR पाठमा गल्ती हुन सक्छ; त्यसलाई पक्का तथ्य नमान्नुहोस्। Viber HTML नमुना हो, वास्तविक संवाद होइन। पुरानो वा नयाँ विवरण बाझिए दुवै उल्लेख गरी पुष्टि माग्नुहोस्। भिडियो आफैँ विश्लेषण नगरेको भए देखेको/भाव बुझेको दाबी नगर्नुहोस्।\n\nअन्जु स्मृति (ABI Improvement भन्दा अलग): ' + JSON.stringify(memory) + '\nMaster Structure र PDF स्रोत अभिलेखबाट हालको प्रश्नसँग सम्बन्धित अंश (स्रोत/पृष्ठ/विश्वसनीयता जाँच्नुहोस्): ' + JSON.stringify(sourceContext) + '\nस्रोत फाइलको स्थिति: ' + JSON.stringify(smritiArchive.source_documents) + '\nप्रयोगकर्ताले स्वीकृत गरेका थप स्मृति निर्देशन: ' + JSON.stringify(memoryInstructions) + '\nव्यक्तिगत साझा सामग्री: ' + JSON.stringify(personalContext) + '\nभावनात्मक व्यवहार अभिलेख: ' + JSON.stringify(emotionContext) + '\nस्वीकृत कथात्मक क्रम: ' + JSON.stringify(storyContext) + '\nभिडियो सन्देशका प्रयोगकर्ता-वर्णित सन्दर्भ: ' + JSON.stringify(videoMessageContext) + '\nस्वीकृत दैनिक डायरी: ' + JSON.stringify(dailyDiaryContext);
    if (process.env.GEMINI_API_KEY) {
      const model = process.env.GEMINI_MODEL || 'gemini-2.5-flash';
      const upstream = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(process.env.GEMINI_API_KEY)}`, {
        method:'POST', headers:{'Content-Type':'application/json'},
        body:JSON.stringify({systemInstruction:{parts:[{text:systemText}]},contents:[{role:'user',parts:[{text:message}]}],generationConfig:{temperature:0.85,maxOutputTokens:1200}})
      });
      const data = await upstream.json();
      if (!upstream.ok) return res.status(upstream.status).json({error:data.error?.message || 'Gemini अनुरोध असफल भयो।'});
      const reply = (data.candidates?.[0]?.content?.parts || []).map(p=>p.text || '').join('').trim();
      return res.json({reply:reply || 'Hajur Sir, फेरि भन्नुहोस् न।',provider:'Gemini'});
    }
    const response = await fetch('https://api.openai.com/v1/responses', { method: 'POST', headers: { Authorization: `Bearer ${process.env.OPENAI_API_KEY}`, 'Content-Type': 'application/json' }, body: JSON.stringify({ model: process.env.OPENAI_MODEL || 'gpt-4.1-mini', input: [{ role: 'system', content: [{ type: 'input_text', text: systemText }] }, { role: 'user', content: [{ type: 'input_text', text: message }] }] }) });
    const data = await response.json(); if (!response.ok) return res.status(response.status).json({ error: data.error?.message || 'AI request failed' }); res.json({ reply: data.output_text || 'Hajur Sir.',provider:'OpenAI' });
  } catch (e) { const safeMessage = String(e?.message || 'Unknown server error').replace(/([?&]key=)[^&\s]+/gi, '$1[REDACTED]').replace(/AIza[0-9A-Za-z_-]{20,}/g, '[REDACTED_API_KEY]'); console.error('AI chat error:', safeMessage); res.status(500).json({ error: 'AI request failed. Server logs contain the diagnostic details.' }); }
});
const port = process.env.PORT || 3000; app.listen(port, '0.0.0.0', () => console.log(`ABI listening on ${port}`));
